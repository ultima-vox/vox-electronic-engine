import { create } from "zustand";
import { KIND_NAMES, KIND_SHORT } from "./audio/samples";

export type FilterType = "lp24" | "lp12" | "hp24" | "hp12" | "bp";
export const FILTER_LABELS: Record<FilterType, string> = {
  lp24: "Low Pass 24 dB",
  lp12: "Low Pass 12 dB",
  hp24: "High Pass 24 dB",
  hp12: "High Pass 12 dB",
  bp: "Band Pass",
};

export type TabId = "sound" | "pattern" | "mixer" | "routing" | "zones" | "macros" | "advanced";
export const TABS: { id: TabId; label: string }[] = [
  { id: "sound", label: "SOUND" },
  { id: "pattern", label: "PATTERN" },
  { id: "mixer", label: "MIXER" },
  { id: "routing", label: "ROUTING" },
  { id: "zones", label: "ZONES" },
  { id: "macros", label: "MACROS" },
  { id: "advanced", label: "ADVANCED" },
];

export interface Pad {
  name: string;
  short: string;
  note: string;
  midi: number;
  kind: number;
  variant: number;
  reverse: boolean;
  normalize: boolean;
  mode: "oneshot" | "loop";
  env: { a: number; d: number; s: number; r: number };
  filterOn: boolean;
  filterType: FilterType;
  cutoff: number;
  res: number;
  transOn: boolean;
  attack: number;
  sustain: number;
  pitchOn: boolean;
  tune: number;
  fine: number;
  pan: number;
  level: number;
  send1: number;
  send2: number;
  mute: boolean;
  solo: boolean;
  vel: number;
  prob: number;
  out: number;
  choke: number;
  velLo: number;
  velHi: number;
}

const NOTES = ["C1", "C#1", "D1", "D#1", "E1", "F1", "F#1", "G1"];
const NEG = -60;

type PadSeed = Partial<Pad> & { env: Pad["env"] };
const SEEDS: PadSeed[] = [
  { env: { a: 0.5, d: 120, s: 0, r: 250 }, filterType: "lp24", cutoff: 1200, res: 0.7, attack: -0.2, sustain: 0.3, send1: -12, send2: NEG, level: 0, vel: 0.78, prob: 100, out: 0 },
  { env: { a: 0.5, d: 260, s: 0, r: 200 }, pan: 0.05, level: -1.5, send1: -9, send2: -20, vel: 0.7, prob: 90, out: 0 },
  { env: { a: 1, d: 300, s: 0, r: 220 }, pan: 0.12, level: -3, send1: -6, send2: -18, vel: 0.62, prob: 75, out: 0 },
  { env: { a: 0.5, d: 90, s: 0, r: 80 }, filterType: "hp12", cutoff: 400, pan: 0.25, level: -6, send1: NEG, send2: NEG, vel: 0.82, prob: 80, out: 0, choke: 1 },
  { env: { a: 0.5, d: 420, s: 0, r: 200 }, filterType: "hp12", cutoff: 400, pan: -0.25, level: -7, send1: -14, send2: NEG, vel: 0.5, prob: 60, out: 0, choke: 1 },
  { env: { a: 0.5, d: 320, s: 0, r: 200 }, pan: -0.3, level: -4, send1: -10, send2: -14, vel: 0.62, prob: 70, out: 1 },
  { env: { a: 0.5, d: 240, s: 0, r: 180 }, pan: 0.3, level: -5, send1: -10, send2: -12, vel: 0.55, prob: 65, out: 1 },
  { env: { a: 0.3, d: 140, s: 0, r: 120 }, pan: 0.15, level: -6, send1: -12, send2: -16, vel: 0.48, prob: 50, out: 1 },
];

export function makePad(i: number, variant = 0): Pad {
  const s = SEEDS[i];
  return {
    name: KIND_NAMES[i],
    short: KIND_SHORT[i],
    note: NOTES[i],
    midi: 36 + i,
    kind: i,
    variant,
    reverse: false,
    normalize: false,
    mode: "oneshot",
    filterOn: true,
    filterType: "lp24",
    cutoff: 20000,
    res: 0.2,
    transOn: true,
    attack: 0,
    sustain: 0,
    pitchOn: true,
    tune: 0,
    fine: 0,
    pan: 0,
    level: 0,
    send1: NEG,
    send2: NEG,
    mute: false,
    solo: false,
    vel: 0.7,
    prob: 100,
    out: 0,
    choke: 0,
    velLo: 1,
    velHi: 127,
    ...s,
  };
}

// ---------- patterns ----------
export type Grid = number[][]; // [lane][step]
const STEPS = 16;
const parse = (rows: string[]): Grid =>
  Array.from({ length: 8 }, (_, l) => {
    const r = (rows[l] ?? "").padEnd(STEPS, ".");
    return Array.from({ length: STEPS }, (_, i) => ({ X: 1, x: 0.72, g: 0.4 } as Record<string, number>)[r[i]] ?? 0);
  });
const empty = (): Grid => parse([]);

const PATTERNS: Grid[] = [
  parse(["X...x.x.X..x.x..", "..X....x..X....x", "...x.......X....", "x.xgx.xgx.xgx.xg", "......x.......x.", "...x......x.....", "..g..x..g..x...g", ".x.....x...x...."]),
  parse(["X...X...X...X...", "....X.......X...", "....x.......x..g", "x.gxx.gxx.gxx.gx", "..X...X...X...X.", "......g.....g...", "...g...g...g...g", ".....x.....x...."]),
  parse(["X.....x...x..x..", "....X..g.g..X..x", "............x...", "x.x.x.x.x.x.x.xx", "..............X.", "........g...x...", "...x......x.....", "..x.....x......."]),
  parse(["X......x..x.....", "........X.......", "........x.......", "x.x.x.xxx.x.xxx.", "......X.........", "", "..........g.....", ""]),
  parse(["X...X...X...X...", "....x.......x...", "", "..x...x...x...x.", "......x.......X.", "g.....g...g.....", "..x.......x..x..", "x...........x..."]),
  empty(),
  empty(),
  empty(),
];

export const PRESETS = [
  { name: "Drums", kit: 0, pattern: 0, bpm: 124 },
  { name: "Deep House Kit", kit: 0, pattern: 1, bpm: 122 },
  { name: "Breakbeat Rider", kit: 1, pattern: 2, bpm: 136 },
  { name: "808 Trap", kit: 2, pattern: 3, bpm: 140 },
  { name: "Punch Techno", kit: 1, pattern: 4, bpm: 130 },
];
export const KITS = ["Factory Kit 01", "Factory Kit 02", "Factory Kit 03"];

export interface Snapshot {
  pattern: number;
  data: Grid;
}

interface State {
  pads: Pad[];
  sel: number;
  tab: TabId;
  powers: { bank: boolean; sample: boolean; env: boolean; perf: boolean };
  kit: number;
  patterns: Grid[];
  pattern: number;
  length: number;
  swing: number;
  humanize: number;
  prob: number;
  bpm: number;
  playing: boolean;
  playStep: number;
  fill: boolean;
  past: Snapshot[];
  clipboard: Grid | null;
  // header
  name: string;
  slot: number;
  channel: number;
  preset: number;
  favorites: boolean[];
  masterDb: number;
  macros: number[];
  outsDb: number[];
  returnsDb: number[];
  adv: { masterTune: number; velCurve: number; velSens: number; choke: boolean; reverbSize: number; delayDiv: number; delayFb: number };
  hint: string;
  // actions
  set: (p: Partial<State>) => void;
  patchPad: (i: number, p: Partial<Pad> | ((pad: Pad) => Partial<Pad>)) => void;
  patchAll: (fn: (pad: Pad, i: number) => Partial<Pad>) => void;
  setHint: (h: string) => void;
  flashHint: (h: string) => void;
  loadKit: (k: number) => void;
  loadPreset: (i: number) => void;
  setPattern: (i: number) => void;
  commit: () => void;
  setStep: (lane: number, step: number, v: number) => void;
  edit: (fn: (g: Grid) => Grid, msg?: string) => void;
  undo: () => void;
  resetPad: (i: number) => void;
}

let hintTimer: ReturnType<typeof setTimeout> | undefined;

export const useStore = create<State>((set, get) => ({
  pads: Array.from({ length: 8 }, (_, i) => makePad(i)),
  sel: 0,
  tab: "sound",
  powers: { bank: true, sample: true, env: true, perf: true },
  kit: 0,
  patterns: PATTERNS,
  pattern: 0,
  length: 16,
  swing: 12,
  humanize: 8,
  prob: 100,
  bpm: 124,
  playing: false,
  playStep: -1,
  fill: false,
  past: [],
  clipboard: null,
  name: "Drums",
  slot: 5,
  channel: 5,
  preset: 0,
  favorites: PRESETS.map(() => false),
  masterDb: -3,
  macros: [0, 0.5, 0, 0.5],
  outsDb: [0, 0, 0, 0],
  returnsDb: [-3, -3],
  adv: { masterTune: 0, velCurve: 1, velSens: 1, choke: true, reverbSize: 1.8, delayDiv: 1, delayFb: 0.4 },
  hint: "",

  set: (p) => set(p),
  patchPad: (i, p) =>
    set((s) => ({
      pads: s.pads.map((pad, k) => (k === i ? { ...pad, ...(typeof p === "function" ? p(pad) : p) } : pad)),
    })),
  patchAll: (fn) => set((s) => ({ pads: s.pads.map((pad, i) => ({ ...pad, ...fn(pad, i) })) })),
  setHint: (h) => set({ hint: h }),
  flashHint: (h) => {
    set({ hint: h });
    clearTimeout(hintTimer);
    hintTimer = setTimeout(() => set({ hint: "" }), 2600);
  },
  loadKit: (k) => set((s) => ({ kit: k, pads: s.pads.map((p) => ({ ...p, variant: k })) })),
  loadPreset: (i) => {
    const pr = PRESETS[i];
    const s = get();
    s.loadKit(pr.kit);
    set({ preset: i, pattern: pr.pattern, bpm: pr.bpm });
  },
  setPattern: (i) => set({ pattern: i }),
  commit: () =>
    set((s) => ({
      past: [...s.past.slice(-29), { pattern: s.pattern, data: s.patterns[s.pattern].map((r) => [...r]) }],
    })),
  setStep: (lane, step, v) =>
    set((s) => {
      if (s.patterns[s.pattern][lane][step] === v) return s;
      const patterns = s.patterns.slice();
      const g = patterns[s.pattern].map((r) => r.slice());
      g[lane][step] = v;
      patterns[s.pattern] = g;
      return { patterns };
    }),
  edit: (fn, msg) => {
    get().commit();
    set((s) => {
      const patterns = s.patterns.slice();
      patterns[s.pattern] = fn(s.patterns[s.pattern].map((r) => r.slice()));
      return { patterns };
    });
    if (msg) get().flashHint(`${msg}  ·  Ctrl+Z to undo`);
  },
  undo: () => {
    const { past } = get();
    if (!past.length) return get().flashHint("Nothing to undo");
    const last = past[past.length - 1];
    set((s) => {
      const patterns = s.patterns.slice();
      patterns[last.pattern] = last.data;
      return { patterns, past: s.past.slice(0, -1), pattern: last.pattern };
    });
    get().flashHint("Undo");
  },
  resetPad: (i) => set((s) => ({ pads: s.pads.map((p, k) => (k === i ? { ...makePad(i, s.kit), name: p.name } : p)) })),
}));
