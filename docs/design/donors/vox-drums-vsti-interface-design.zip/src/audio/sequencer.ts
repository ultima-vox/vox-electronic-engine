import { engine } from "./engine";
import { useStore } from "../store";
import { clamp } from "../utils/math";

let timer: ReturnType<typeof setInterval> | null = null;
let nextTime = 0;
let stepIdx = 0;
let queue: { step: number; time: number }[] = [];
let raf = 0;

const LOOKAHEAD = 0.14;

function scheduleStep(idx: number, at: number) {
  const s = useStore.getState();
  const len = clamp(s.length, 1, 16);
  const step = idx % len;
  const stepDur = 60 / s.bpm / 4;
  const swingOffset = step % 2 === 1 ? (s.swing / 100) * stepDur * 0.66 : 0;
  const grid = s.patterns[s.pattern];
  const h = s.humanize / 100;
  const fillZone = s.fill && step >= len - 4;

  for (let lane = 0; lane < 8; lane++) {
    let val = grid[lane][step];
    if (!val && fillZone && (lane === 1 || lane === 5 || lane === 6) && Math.random() < 0.5) val = 0.6;
    if (!val) continue;
    const pad = s.pads[lane];
    if (Math.random() * 100 >= (pad.prob * s.prob) / 100) continue;
    const jitter = (Math.random() - 0.5) * 2 * h * 0.02;
    const vel = clamp(val * (pad.vel + 0.25) * (1 + (Math.random() - 0.5) * h * 0.7), 0.02, 1);
    engine.trigger(lane, vel, at + swingOffset + jitter);
  }
  queue.push({ step, time: at + swingOffset });
}

function tick() {
  const ctx = engine.ctx;
  if (!ctx) return;
  while (nextTime < ctx.currentTime + LOOKAHEAD) {
    scheduleStep(stepIdx, nextTime);
    nextTime += 60 / useStore.getState().bpm / 4;
    stepIdx++;
  }
}

function uiLoop() {
  const ctx = engine.ctx;
  if (ctx && useStore.getState().playing) {
    let cur = -1;
    while (queue.length && queue[0].time <= ctx.currentTime) cur = queue.shift()!.step;
    if (cur >= 0 && cur !== useStore.getState().playStep) useStore.setState({ playStep: cur });
    raf = requestAnimationFrame(uiLoop);
  }
}

export function startSequencer() {
  const ctx = engine.ensure();
  if (timer) return;
  stepIdx = 0;
  queue = [];
  nextTime = ctx.currentTime + 0.06;
  timer = setInterval(tick, 25);
  useStore.setState({ playing: true });
  raf = requestAnimationFrame(uiLoop);
}

export function stopSequencer() {
  if (timer) clearInterval(timer);
  timer = null;
  cancelAnimationFrame(raf);
  queue = [];
  useStore.setState({ playing: false, playStep: -1 });
}

export function toggleSequencer() {
  if (useStore.getState().playing) stopSequencer();
  else startSequencer();
}
