import { useStore, type Pad } from "../store";
import { getProcessed, SR } from "./samples";
import { clamp, dbToGain } from "../utils/math";

export interface Flash {
  t: number; // performance.now() timestamp when the hit becomes audible
  v: number; // peak level
  dur: number; // ms length of the hit
}

interface Voice {
  src: AudioBufferSourceNode;
  env: GainNode;
}

export const DELAY_DIVS = [
  { label: "1/8", beats: 0.5 },
  { label: "1/8 dotted", beats: 0.75 },
  { label: "1/4", beats: 1 },
  { label: "1/16", beats: 0.25 },
];

class DrumEngine {
  ctx: AudioContext | null = null;
  private master!: GainNode;
  private outs: GainNode[] = [];
  private send1!: GainNode;
  private send2!: GainNode;
  private revRet!: GainNode;
  private delRet!: GainNode;
  private convolver!: ConvolverNode;
  private delay!: DelayNode;
  private fb!: GainNode;
  private anL!: AnalyserNode;
  private anR!: AnalyserNode;
  private bufCache = new Map<string, AudioBuffer>();
  private voices: Set<Voice>[] = Array.from({ length: 8 }, () => new Set());
  private lastReverb = 0;
  flash: (Flash | null)[] = Array(8).fill(null);
  activeVoices = 0;

  ensure(): AudioContext {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return this.ctx;
    }
    const ctx = new AudioContext({ latencyHint: "interactive" });
    this.ctx = ctx;
    this.master = ctx.createGain();
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -8;
    comp.knee.value = 6;
    comp.ratio.value = 8;
    comp.attack.value = 0.003;
    comp.release.value = 0.12;
    this.master.connect(comp);
    comp.connect(ctx.destination);
    const split = ctx.createChannelSplitter(2);
    comp.connect(split);
    this.anL = ctx.createAnalyser();
    this.anR = ctx.createAnalyser();
    this.anL.fftSize = this.anR.fftSize = 512;
    split.connect(this.anL, 0);
    split.connect(this.anR, 1);

    this.outs = Array.from({ length: 4 }, () => {
      const g = ctx.createGain();
      g.connect(this.master);
      return g;
    });

    // Send 1 – reverb
    this.send1 = ctx.createGain();
    this.convolver = ctx.createConvolver();
    this.revRet = ctx.createGain();
    this.send1.connect(this.convolver);
    this.convolver.connect(this.revRet);
    this.revRet.connect(this.master);

    // Send 2 – feedback delay
    this.send2 = ctx.createGain();
    this.delay = ctx.createDelay(2);
    this.fb = ctx.createGain();
    const damp = ctx.createBiquadFilter();
    damp.type = "lowpass";
    damp.frequency.value = 3800;
    this.delRet = ctx.createGain();
    this.send2.connect(this.delay);
    this.delay.connect(damp);
    damp.connect(this.fb);
    this.fb.connect(this.delay);
    damp.connect(this.delRet);
    this.delRet.connect(this.master);

    this.apply();
    useStore.subscribe(() => this.apply());
    return ctx;
  }

  private buildReverb(size: number) {
    const ctx = this.ctx!;
    const len = Math.floor(SR * size);
    const ir = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = ir.getChannelData(c);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.2);
    }
    this.convolver.buffer = ir;
    this.lastReverb = size;
  }

  /** Sync engine parameters with the store */
  apply() {
    if (!this.ctx) return;
    const s = useStore.getState();
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(dbToGain(s.masterDb), t, 0.02);
    s.outsDb.forEach((db, i) => this.outs[i].gain.setTargetAtTime(dbToGain(db), t, 0.02));
    this.revRet.gain.setTargetAtTime(dbToGain(s.returnsDb[0]), t, 0.02);
    this.delRet.gain.setTargetAtTime(dbToGain(s.returnsDb[1]), t, 0.02);
    this.fb.gain.setTargetAtTime(s.adv.delayFb, t, 0.02);
    const beat = 60 / s.bpm;
    this.delay.delayTime.setTargetAtTime(clamp(beat * DELAY_DIVS[s.adv.delayDiv].beats, 0.02, 1.9), t, 0.05);
    if (s.adv.reverbSize !== this.lastReverb) this.buildReverb(s.adv.reverbSize);
  }

  private audible(pads: Pad[], i: number) {
    const anySolo = pads.some((p) => p.solo);
    return anySolo ? pads[i].solo : !pads[i].mute;
  }

  private getBuffer(p: Pad): AudioBuffer {
    const key = `${p.kind}:${p.variant}:${p.reverse}:${p.normalize}`;
    let b = this.bufCache.get(key);
    if (!b) {
      const data = getProcessed(p.kind, p.variant, p.reverse, p.normalize);
      b = this.ctx!.createBuffer(1, data.length, SR);
      b.copyToChannel(data as Float32Array<ArrayBuffer>, 0);
      this.bufCache.set(key, b);
    }
    return b;
  }

  private kill(i: number, when: number) {
    this.voices[i].forEach((v) => {
      v.env.gain.cancelScheduledValues(when);
      v.env.gain.setTargetAtTime(0, when, 0.004);
      try {
        v.src.stop(when + 0.04);
      } catch {
        /* already stopped */
      }
    });
  }

  trigger(i: number, vel: number, when?: number) {
    const ctx = this.ensure();
    const s = useStore.getState();
    const p = s.pads[i];
    if (!s.powers.bank || !s.powers.sample || !this.audible(s.pads, i)) return;
    const v127 = Math.round(vel * 127);
    if (v127 < p.velLo || v127 > p.velHi) return;

    const now = ctx.currentTime;
    const t = Math.max(when ?? now, now);
    const { adv, macros } = s;
    const [punch, tone, space, decay] = macros;

    // velocity shaping
    let v = Math.pow(clamp(vel, 0, 1), [0.6, 1, 1.7][adv.velCurve]);
    v = clamp(1 - adv.velSens + adv.velSens * v, 0, 1.1);

    // choke groups
    if (adv.choke && p.choke > 0) s.pads.forEach((o, j) => j !== i && o.choke === p.choke && this.kill(j, t));

    const buf = this.getBuffer(p);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.loop = p.mode === "loop";
    const semis = (p.pitchOn ? p.tune + p.fine / 100 : 0) + adv.masterTune / 100;
    const rate = Math.pow(2, semis / 12);
    src.playbackRate.value = rate;

    const nodes: AudioNode[] = [src];
    let last: AudioNode = src;
    const chain = (n: AudioNode) => {
      last.connect(n);
      last = n;
      nodes.push(n);
    };

    // Filter
    const toneOct = (tone - 0.5) * 6;
    if (p.filterOn || Math.abs(toneOct) > 0.05) {
      const type = p.filterOn ? p.filterType : "lp12";
      const isHp = type.startsWith("hp");
      const base = p.filterOn ? p.cutoff : 20000;
      const fc = clamp(base * Math.pow(2, isHp ? -toneOct : toneOct), 20, 20000);
      const stages = type.endsWith("24") ? 2 : 1;
      for (let k = 0; k < stages; k++) {
        const f = ctx.createBiquadFilter();
        f.type = type === "bp" ? "bandpass" : isHp ? "highpass" : "lowpass";
        f.frequency.value = fc;
        f.Q.value = type === "bp" ? 0.5 + p.res * 9 : p.res * 8;
        chain(f);
      }
    }

    // Transient shaper
    const att = (p.transOn ? p.attack : 0) + punch * 0.6;
    if (Math.abs(att) > 0.01) {
      const tg = ctx.createGain();
      tg.gain.setValueAtTime(att >= 0 ? 1 + att * 1.0 : 1 + att * 0.85, t);
      tg.gain.setTargetAtTime(1, t + 0.004, 0.02);
      chain(tg);
    }
    const sustMult = (p.transOn ? Math.pow(2, p.sustain * 1.5) : 1) * Math.pow(2, (decay - 0.5) * 2);

    // Amp envelope
    const eg = ctx.createGain();
    chain(eg);
    let hold = p.mode === "loop" ? 0.6 : buf.duration / rate;
    let stopAt: number;
    if (s.powers.env) {
      const a = Math.max(p.env.a / 1000, 0.0004);
      const tau = Math.max((p.env.d / 1000) * sustMult, 0.003) / 2.5;
      const S = p.env.s;
      const r = Math.max(p.env.r / 1000, 0.003);
      hold = Math.max(hold, a + 0.01);
      eg.gain.setValueAtTime(0, t);
      eg.gain.linearRampToValueAtTime(v, t + a);
      eg.gain.setTargetAtTime(v * S, t + a, tau);
      const atOff = v * (S + (1 - S) * Math.exp(-(hold - a) / tau));
      eg.gain.setValueAtTime(atOff, t + hold);
      eg.gain.setTargetAtTime(0, t + hold, r / 3);
      stopAt = t + hold + r * 1.3 + 0.05;
    } else {
      eg.gain.setValueAtTime(v, t);
      stopAt = t + hold;
    }

    // Performance section
    const perf = s.powers.perf;
    const pan = ctx.createStereoPanner();
    pan.pan.value = perf ? p.pan : 0;
    chain(pan);
    const lvl = ctx.createGain();
    lvl.gain.value = perf ? dbToGain(p.level) : 1;
    chain(lvl);
    lvl.connect(this.outs[p.out]);
    const s1 = (perf ? dbToGain(p.send1) : 0) + space * 0.45;
    const s2 = (perf ? dbToGain(p.send2) : 0) + space * 0.3;
    if (s1 > 0.002) {
      const g = ctx.createGain();
      g.gain.value = s1;
      lvl.connect(g);
      g.connect(this.send1);
      nodes.push(g);
    }
    if (s2 > 0.002) {
      const g = ctx.createGain();
      g.gain.value = s2;
      lvl.connect(g);
      g.connect(this.send2);
      nodes.push(g);
    }

    const voice: Voice = { src, env: eg };
    this.voices[i].add(voice);
    this.activeVoices++;
    src.onended = () => {
      nodes.forEach((n) => n.disconnect());
      this.voices[i].delete(voice);
      this.activeVoices = Math.max(0, this.activeVoices - 1);
    };
    src.start(t);
    src.stop(stopAt);

    this.flash[i] = {
      t: performance.now() + (t - now) * 1000,
      v: clamp(v * (perf ? dbToGain(p.level) : 1), 0, 1),
      dur: (buf.duration / rate) * 1000,
    };
  }

  /** peak level 0..1 for L/R */
  meters(): [number, number] {
    if (!this.ctx) return [0, 0];
    const buf = new Float32Array(512);
    const peak = (an: AnalyserNode) => {
      an.getFloatTimeDomainData(buf);
      let m = 0;
      for (let i = 0; i < buf.length; i++) m = Math.max(m, Math.abs(buf[i]));
      return m;
    };
    return [peak(this.anL), peak(this.anR)];
  }

  /** decaying hit meter 0..1 for pad i */
  padLevel(i: number, decayMs = 220): number {
    const f = this.flash[i];
    if (!f) return 0;
    const dt = performance.now() - f.t;
    if (dt < 0) return 0;
    return f.v * Math.exp(-dt / decayMs);
  }
}

export const engine = new DrumEngine();
