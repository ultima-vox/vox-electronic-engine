import { useEffect, useLayoutEffect, useState } from "react";
import { useStore } from "./store";
import { engine } from "./audio/engine";
import { toggleSequencer } from "./audio/sequencer";
import { Header, StatusBar, Tabs } from "./components/Header";
import { SoundTab } from "./components/SoundTab";
import { Sequencer } from "./components/Sequencer";
import { TabContent } from "./components/Tabs";

const W = 1040;
const H = 828;
const KEYS = ["a", "s", "d", "f", "z", "x", "c", "v"];

function useScale() {
  const [s, setS] = useState(1);
  useLayoutEffect(() => {
    const f = () => setS(Math.min(window.innerWidth / W, window.innerHeight / H));
    f();
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, []);
  return s;
}

export default function App() {
  const scale = useScale();
  const tab = useStore((s) => s.tab);

  useEffect(() => {
    const held = new Set<string>();
    const down = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t.tagName === "INPUT" || t.tagName === "TEXTAREA") return;
      const k = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && k === "z") {
        e.preventDefault();
        return useStore.getState().undo();
      }
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (k === " " && t.tagName !== "BUTTON") {
        e.preventDefault();
        return toggleSequencer();
      }
      const i = KEYS.indexOf(k);
      if (i >= 0 && !held.has(k)) {
        held.add(k);
        useStore.getState().set({ sel: i });
        engine.trigger(i, 0.9);
      }
    };
    const up = (e: KeyboardEvent) => held.delete(e.key.toLowerCase());
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  return (
    <div className="flex h-full w-full items-center justify-center overflow-hidden">
      <div style={{ width: W * scale, height: H * scale }}>
        <main
          aria-label="Vox Drums instrument"
          className="flex flex-col gap-2 rounded-[14px] border border-[rgba(56,170,220,.35)] p-3"
          style={{
            width: W,
            height: H,
            transform: `scale(${scale})`,
            transformOrigin: "0 0",
            background: "linear-gradient(180deg,#071522 0%,#040c15 55%,#030810 100%)",
            boxShadow: "0 0 60px rgba(20,140,200,.25), inset 0 0 40px rgba(20,120,180,.08)",
          }}
        >
          <Header />
          <Tabs />
          {tab === "sound" ? <SoundTab /> : <TabContent tab={tab} />}
          <Sequencer />
          <StatusBar />
        </main>
      </div>
    </div>
  );
}
