export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

export const dbToGain = (db: number, floor = -60) => (db <= floor + 0.05 ? 0 : Math.pow(10, db / 20));

export const fmtHz = (v: number) => (v >= 1000 ? `${(v / 1000).toFixed(1)} kHz` : `${Math.round(v)} Hz`);

export const fmtMs = (v: number) =>
  v >= 1000 ? `${(v / 1000).toFixed(2)} s` : v < 10 ? `${v.toFixed(1)} ms` : `${Math.round(v)} ms`;

export const fmtDb = (digits = 1, floor = -60) => (v: number) =>
  v <= floor + 0.05 ? "-inf dB" : `${v.toFixed(digits)} dB`;

export const fmtPan = (v: number) => {
  const p = Math.round(Math.abs(v) * 100);
  return p === 0 ? "C" : v < 0 ? `L${p}` : `R${p}`;
};

export const fmtSigned = (digits = 2) => (v: number) => (v > 0 ? "+" : "") + v.toFixed(digits);

/** map real value -> 0..1 */
export function toNorm(v: number, min: number, max: number, log?: boolean) {
  if (log) return clamp(Math.log(v / min) / Math.log(max / min), 0, 1);
  return clamp((v - min) / (max - min), 0, 1);
}
/** map 0..1 -> real value */
export function fromNorm(n: number, min: number, max: number, log?: boolean) {
  n = clamp(n, 0, 1);
  return log ? min * Math.pow(max / min, n) : min + n * (max - min);
}
