import { memo, useCallback, useEffect, useRef, useState, type PointerEvent as RPE, type ReactNode } from "react";
import { ChevronDown, Dices, Hand, Play, Square } from "lucide-react";
import { useStore } from "../store";
import { engine } from "../audio/engine";
import { toggleSequencer } from "../audio/sequencer";
import { clamp } from "../utils/math";
import { DragValue, Next, Prev, Select, useFrame } from "./ui";

/* ---------------------------------------------------------------- icons */
export function LaneIcon({ kind, size = 17 }: { kind: number; size?: number }) {
  const p = { width: size, height: size, viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 1.3, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  switch (kind) {
    case 0:
      return (
        <svg {...p}>
          <circle cx="8" cy="8" r="5.8" />
          <circle cx="8" cy="8" r="2.3" />
        </svg>
      );
    case 1:
      return (
        <svg {...p}>
          <ellipse cx="8" cy="5" rx="6" ry="2.2" />
          <path d="M2 5v5.2c0 1.2 2.7 2.2 6 2.2s6-1 6-2.2V5M5 7.2l1.5 4.8M8 7.4v5M11 7.2L9.5 12" />
        </svg>
      );
    case 2:
      return <Hand size={size} strokeWidth={1.4} />;
    case 3:
      return (
        <svg {...p}>
          <ellipse cx="8" cy="6.2" rx="6.5" ry="1.5" />
          <ellipse cx="8" cy="8.2" rx="6.5" ry="1.5" />
          <path d="M8 9.8V14.5M5.5 14.5h5" />
        </svg>
      );
    case 4:
      return (
        <svg {...p}>
          <path d="M1.5 4.2C4 2.8 12 2.8 14.5 4.2 12 5.8 4 5.8 1.5 4.2z" />
          <ellipse cx="8" cy="9" rx="6.5" ry="1.5" />
          <path d="M8 10.5V15M5.5 15h5" />
        </svg>
      );
    case 5:
      return (
        <svg {...p}>
          <ellipse cx="8" cy="4.6" rx="5.5" ry="2" />
          <path d="M2.5 4.6v6.2c0 1.1 2.4 2 5.5 2s5.5-.9 5.5-2V4.6M2.5 7.6h11" />
        </svg>
      );
    case 6:
      return (
        <svg {...p}>
          <path d="M4.5 2.5h7l2 10.5h-11zM6.2 6.5h3.6" />
          <path d="M7 13v1.5h2V13" />
        </svg>
      );
    default:
      return (
        <svg {...p}>
          <path d="M2.5 13.5l8-8M5 3l8 8M10 4.2l2.3-1.7" />
          <circle cx="13" cy="3" r="1.2" />
        </svg>
      );
  }
}

/* ---------------------------------------------------------------- cell */
interface CellProps {
  lane: number;
  step: number;
  v: number;
  now: boolean;
  inLen: boolean;
  down: (lane: number, step: number, e: RPE<HTMLButtonElement>) => void;
  enter: (lane: number, step: number) => void;
  key2: (lane: number, step: number) => void;
}

const Cell = memo(function Cell({ lane, step, v, now, inLen, down, enter, key2 }: CellProps) {
  const on = v > 0;
  const accent = v >= 0.95;
  const ghost = on && v < 0.55;
  const alt = Math.floor(step / 4) % 2 === 1;
  let bg: string, shadow = "none", border = "rgba(56,170,220,.16)";
  if (on) {
    bg = accent
      ? "linear-gradient(180deg,#9df0ff,#38cdf8)"
      : ghost
        ? "linear-gradient(180deg,#1a86b4,#105f86)"
        : "linear-gradient(180deg,#43d2ff,#1696cc)";
    shadow = accent ? "0 0 10px rgba(110,230,255,.85)" : "0 0 7px rgba(39,198,255,.5)";
    border = accent ? "#d5f8ff" : "rgba(160,235,255,.5)";
  } else bg = alt ? "linear-gradient(180deg,#0f2233,#0a1826)" : "linear-gradient(180deg,#0b1a29,#07121d)";
  return (
    <button
      type="button"
      tabIndex={-1}
      aria-label={`Lane ${lane + 1} step ${step + 1} ${on ? (accent ? "accent" : ghost ? "ghost" : "on") : "off"}`}
      aria-pressed={on}
      disabled={!inLen}
      onPointerDown={(e) => down(lane, step, e)}
      onPointerEnter={() => enter(lane, step)}
      onClick={(e) => e.detail === 0 && key2(lane, step)}
      onContextMenu={(e) => e.preventDefault()}
      className="relative h-full min-w-0 rounded-[3px] border transition-[filter] duration-75"
      style={{
        background: bg,
        boxShadow: shadow,
        borderColor: now ? "#fff" : border,
        opacity: inLen ? 1 : 0.28,
        filter: now ? "brightness(1.55)" : undefined,
        outline: now ? "1px solid rgba(255,255,255,.55)" : undefined,
      }}
    />
  );
});

/* ---------------------------------------------------------------- row bits */
const COLS = "grid-cols-[112px_50px_minmax(0,1fr)_96px_46px_88px]";

function LaneLabel({ i }: { i: number }) {
  const pad = useStore((s) => s.pads[i]);
  const selected = useStore((s) => s.sel === i);
  const set = useStore((s) => s.set);
  const ref = useRef<HTMLDivElement>(null);
  useFrame(() => {
    if (ref.current) ref.current.style.opacity = String(Math.min(1, engine.padLevel(i, 130) * 1.6));
  });
  return (
    <button
      type="button"
      onClick={() => set({ sel: i })}
      aria-pressed={selected}
      title={`Edit ${pad.name} (selects the pad)`}
      className="relative flex h-full items-center gap-2 overflow-hidden rounded px-1.5 text-left text-[12px] transition"
      style={{ color: selected ? "#fff" : "#cfe8f5", background: selected ? "rgba(39,198,255,.16)" : "transparent", boxShadow: selected ? "inset 2px 0 0 #27c6ff" : "none" }}
    >
      <div ref={ref} className="pointer-events-none absolute inset-0 opacity-0" style={{ background: "linear-gradient(90deg,rgba(80,215,255,.5),transparent)" }} />
      <span className="relative text-accent-hi">
        <LaneIcon kind={pad.kind} />
      </span>
      <span className="relative truncate">{pad.name}</span>
    </button>
  );
}

function MS({ i }: { i: number }) {
  const pad = useStore((s) => s.pads[i]);
  const patch = useStore((s) => s.patchPad);
  const mk = (on: boolean, color: string) => ({
    borderColor: on ? color : "rgba(56,170,220,.35)",
    background: on ? color : "linear-gradient(180deg,#0e2438,#08151f)",
    color: on ? "#02121b" : "#b4def0",
    boxShadow: on ? `0 0 8px ${color}` : "none",
  });
  return (
    <div className="flex h-full gap-[3px]">
      <button className="w-1/2 rounded-[3px] border text-[10.5px] font-bold" aria-pressed={pad.mute} aria-label={`Mute ${pad.name}`} title="Mute" style={mk(pad.mute, "#f5a524")} onClick={() => patch(i, { mute: !pad.mute })}>
        M
      </button>
      <button className="w-1/2 rounded-[3px] border text-[10.5px] font-bold" aria-pressed={pad.solo} aria-label={`Solo ${pad.name}`} title="Solo" style={mk(pad.solo, "#2cc9ff")} onClick={() => patch(i, { solo: !pad.solo })}>
        S
      </button>
    </div>
  );
}

function VelBar({ i }: { i: number }) {
  const vel = useStore((s) => s.pads[i].vel);
  const patch = useStore((s) => s.patchPad);
  const drag = useRef(false);
  const upd = (e: RPE<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    patch(i, { vel: Math.round(clamp((e.clientX - r.left) / r.width, 0.02, 1) * 100) / 100 });
  };
  return (
    <div
      role="slider"
      tabIndex={0}
      aria-label={`${i + 1} lane velocity`}
      aria-valuenow={Math.round(vel * 127)}
      aria-valuemin={1}
      aria-valuemax={127}
      title="Lane velocity – drag, double-click to reset"
      className="relative flex h-full cursor-ew-resize touch-none items-center"
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        drag.current = true;
        upd(e);
      }}
      onPointerMove={(e) => drag.current && upd(e)}
      onPointerUp={() => (drag.current = false)}
      onDoubleClick={() => patch(i, { vel: 0.7 })}
      onKeyDown={(e) => {
        if (e.key === "ArrowRight" || e.key === "ArrowUp") patch(i, { vel: clamp(vel + 0.03, 0.02, 1) });
        if (e.key === "ArrowLeft" || e.key === "ArrowDown") patch(i, { vel: clamp(vel - 0.03, 0.02, 1) });
      }}
    >
      <div className="inset h-[9px] w-full overflow-hidden rounded-[3px]">
        <div className="h-full rounded-[2px]" style={{ width: `${vel * 100}%`, background: "linear-gradient(90deg,#0f8fc2,#3ad3ff)", boxShadow: "0 0 8px rgba(39,198,255,.6)" }} />
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- edit menu */
function EditMenu() {
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const edit = useStore((s) => s.edit);
  const set = useStore((s) => s.set);
  const flash = useStore((s) => s.flashHint);
  useEffect(() => {
    if (!open) return;
    const h = (e: PointerEvent) => !root.current?.contains(e.target as Node) && setOpen(false);
    document.addEventListener("pointerdown", h);
    return () => document.removeEventListener("pointerdown", h);
  }, [open]);
  const items: [string, () => void][] = [
    ["Shift left", () => edit((g) => g.map((r) => [...r.slice(1), r[0]]), "Pattern shifted left")],
    ["Shift right", () => edit((g) => g.map((r) => [r[15], ...r.slice(0, 15)]), "Pattern shifted right")],
    ["Double (copy 1–8 → 9–16)", () => edit((g) => g.map((r) => [...r.slice(0, 8), ...r.slice(0, 8)]), "Pattern doubled")],
    ["Reverse", () => edit((g) => g.map((r) => [...r].reverse()), "Pattern reversed")],
    ["Invert selected lane", () => edit((g) => g.map((r, l) => (l === useStore.getState().sel ? r.map((v) => (v ? 0 : 0.72)) : r)), "Lane inverted")],
    ["Copy pattern", () => (set({ clipboard: useStore.getState().patterns[useStore.getState().pattern].map((r) => [...r]) }), flash("Pattern copied"))],
    ["Paste pattern", () => (useStore.getState().clipboard ? edit(() => useStore.getState().clipboard!.map((r) => [...r]), "Pattern pasted") : flash("Clipboard is empty"))],
  ];
  return (
    <div ref={root} className="relative">
      <button className="btn !h-[26px] w-[40px] !px-0" aria-label="Pattern tools" aria-expanded={open} title="Pattern tools" onClick={() => setOpen((o) => !o)}>
        <ChevronDown size={15} />
      </button>
      {open && (
        <ul role="menu" className="absolute right-0 top-full z-[60] mt-1 w-[190px] rounded-md border border-[rgba(120,220,255,.5)] bg-[#061320] py-1 shadow-[0_8px_24px_rgba(0,0,0,.7)]">
          {items.map(([l, fn]) => (
            <li key={l}>
              <button
                role="menuitem"
                className="w-full px-3 py-[5px] text-left text-[12px] text-txt hover:bg-[rgba(39,198,255,.2)]"
                onClick={() => {
                  fn();
                  setOpen(false);
                }}
              >
                {l}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------- sequencer */
export function randomize(): number[][] {
  const dens = [0.28, 0.2, 0.12, 0.55, 0.14, 0.12, 0.14, 0.12];
  return dens.map((d, l) =>
    Array.from({ length: 16 }, (_, s) => {
      let p = d;
      if (l === 0) p = s % 4 === 0 ? 0.92 : 0.12;
      if (l === 1) p = s % 8 === 4 ? 0.95 : 0.1;
      if (l === 3) p = s % 2 === 0 ? 0.7 : 0.35;
      if (l === 4) p = s % 4 === 2 ? 0.45 : 0.04;
      return Math.random() < p ? (Math.random() < 0.2 ? 1 : Math.random() < 0.2 ? 0.4 : 0.72) : 0;
    }),
  );
}

export function Sequencer({ children }: { children?: ReactNode }) {
  const grid = useStore((s) => s.patterns[s.pattern]);
  const playStep = useStore((s) => s.playStep);
  const { length, swing, humanize, prob, bpm, playing, fill, pattern } = useStore();
  const set = useStore((s) => s.set);
  const setPattern = useStore((s) => s.setPattern);
  const commit = useStore((s) => s.commit);
  const setStep = useStore((s) => s.setStep);
  const edit = useStore((s) => s.edit);
  const paint = useRef<number | null>(null);
  const gridRef = useRef(grid);
  gridRef.current = grid;

  useEffect(() => {
    const up = () => (paint.current = null);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
  }, []);

  const down = useCallback(
    (lane: number, step: number, e: RPE<HTMLButtonElement>) => {
      e.preventDefault();
      const cur = gridRef.current[lane][step];
      commit();
      let val: number;
      if (e.shiftKey || e.button === 2) val = cur >= 0.95 ? 0.72 : 1;
      else val = cur > 0 ? 0 : 0.72;
      paint.current = val;
      setStep(lane, step, val);
      if (val > 0) engine.trigger(lane, val * 0.9);
    },
    [commit, setStep],
  );
  const enter = useCallback(
    (lane: number, step: number) => {
      if (paint.current !== null) setStep(lane, step, paint.current);
    },
    [setStep],
  );
  const key2 = useCallback(
    (lane: number, step: number) => {
      commit();
      setStep(lane, step, gridRef.current[lane][step] > 0 ? 0 : 0.72);
    },
    [commit, setStep],
  );

  return (
    <section className="panel flex flex-col px-3 pb-2" aria-label="Step sequencer">
      <div className="flex h-[46px] shrink-0 items-center gap-3">
        <div className="flex items-center gap-2">
          <svg width="18" height="18" viewBox="0 0 18 18" className="text-accent-hi" fill="currentColor" aria-hidden>
            {[0, 1, 2].map((r) => [0, 1, 2].map((c) => <rect key={`${r}${c}`} x={1 + c * 6} y={1 + r * 6} width="4.6" height="4.6" rx="1" opacity={(r + c) % 2 ? 0.5 : 1} />))}
          </svg>
          <h2 className="panel-title">STEP SEQUENCER</h2>
        </div>
        <button
          aria-pressed={playing}
          aria-label={playing ? "Stop" : "Play"}
          title="Play / Stop (Space)"
          onClick={toggleSequencer}
          className="btn !h-[28px] w-[38px] !px-0"
        >
          {playing ? <Square size={13} fill="currentColor" /> : <Play size={14} fill="currentColor" />}
        </button>
        <div className="flex items-center gap-1">
          <Select label="Pattern" className="w-[112px]" height={24} value={pattern} options={Array.from({ length: 8 }, (_, i) => ({ value: i, label: `Pattern ${String(i + 1).padStart(2, "0")}` }))} onChange={setPattern} />
          <Prev className="w-[22px] !h-[24px]" label="Previous pattern" onClick={() => setPattern((pattern + 7) % 8)} />
          <Next className="w-[22px] !h-[24px]" label="Next pattern" onClick={() => setPattern((pattern + 1) % 8)} />
        </div>
        <div className="flex flex-1 items-center justify-between">
          <DragValue label="Tempo" value={bpm} min={60} max={200} def={124} fmt={(v) => `${v}`} onChange={(v) => set({ bpm: v })} pxPerStep={3} />
          <DragValue label="Length" value={length} min={1} max={16} def={16} fmt={(v) => `${v}`} onChange={(v) => set({ length: v })} pxPerStep={8} />
          <DragValue label="Swing" value={swing} min={0} max={100} def={12} fmt={(v) => `${v}%`} onChange={(v) => set({ swing: v })} />
          <DragValue label="Humanize" value={humanize} min={0} max={100} def={8} fmt={(v) => `${v}%`} onChange={(v) => set({ humanize: v })} />
          <DragValue label="Probability" value={prob} min={0} max={100} def={100} fmt={(v) => `${v}%`} onChange={(v) => set({ prob: v })} />
          <button
            className="btn !h-[26px] w-[44px]"
            aria-pressed={fill}
            title="Hold to add fills to the last beat of the pattern"
            onPointerDown={() => set({ fill: true })}
            onPointerUp={() => set({ fill: false })}
            onPointerLeave={() => set({ fill: false })}
            onKeyDown={(e) => (e.key === " " || e.key === "Enter") && set({ fill: true })}
            onKeyUp={() => set({ fill: false })}
          >
            Fill
          </button>
          <button className="btn !h-[26px] w-[34px] !px-0" aria-label="Randomize pattern" title="Randomize pattern" onClick={() => edit(() => randomize(), "Pattern randomized")}>
            <Dices size={18} />
          </button>
          <button className="btn !h-[26px] w-[64px]" title="Clear pattern" onClick={() => edit((g) => g.map((r) => r.map(() => 0)), "Pattern cleared")}>
            Clear
          </button>
          <EditMenu />
        </div>
      </div>

      {children ?? (
        <>
          <div className={`mb-[3px] grid ${COLS} items-end gap-x-[7px] text-[10px] leading-none text-mute`}>
            <span />
            <span />
            <div className="grid grid-cols-16 gap-[3px] text-center tabular-nums">
              {Array.from({ length: 16 }, (_, i) => (
                <span key={i} className={i % 4 === 0 ? "text-accent-hi" : "opacity-60"}>
                  {i + 1}
                </span>
              ))}
            </div>
            <span className="text-center">Velocity</span>
            <span className="text-center">Prob</span>
            <span className="text-center">Output</span>
          </div>
          <div className="flex flex-col gap-[3px]">
            {grid.map((row, lane) => (
              <div key={lane} className={`grid h-[20px] ${COLS} items-center gap-x-[7px]`}>
                <LaneLabel i={lane} />
                <MS i={lane} />
                <div className="grid h-full grid-cols-16 gap-[3px]">
                  {row.map((v, step) => (
                    <Cell key={step} lane={lane} step={step} v={v} now={playStep === step} inLen={step < length} down={down} enter={enter} key2={key2} />
                  ))}
                </div>
                <VelBar i={lane} />
                <ProbCell i={lane} />
                <OutCell i={lane} />
              </div>
            ))}
          </div>
        </>
      )}
    </section>
  );
}

function ProbCell({ i }: { i: number }) {
  const prob = useStore((s) => s.pads[i].prob);
  const patch = useStore((s) => s.patchPad);
  return <DragValue className="!px-0" hideLabel label={`Probability lane ${i + 1}`} value={prob} min={0} max={100} step={5} def={100} fmt={(v) => `${v}%`} onChange={(v) => patch(i, { prob: v })} pxPerStep={3} />;
}

function OutCell({ i }: { i: number }) {
  const out = useStore((s) => s.pads[i].out);
  const patch = useStore((s) => s.patchPad);
  return (
    <Select up={i >= 4} label={`Output lane ${i + 1}`} height={20} value={out} options={[0, 1, 2, 3].map((o) => ({ value: o, label: `Out ${o + 1}` }))} onChange={(v) => patch(i, { out: v })} />
  );
}
