import { useRef, type ReactNode } from "react";
import { RotateCcw } from "lucide-react";
import { useStore, PRESETS } from "../store";
import { engine, DELAY_DIVS } from "../audio/engine";
import { clamp, dbToGain, fmtDb, fmtHz, fmtPan } from "../utils/math";
import { DragValue, Knob, Panel, Select, useFrame } from "./ui";
import { LaneIcon } from "./Sequencer";

const Body = ({ children, cols }: { children: ReactNode; cols: string }) => (
  <div className={`grid h-[400px] gap-2 ${cols}`}>{children}</div>
);

/* ================================================================== PATTERN */
function MiniPattern({ g, active }: { g: number[][]; active: boolean }) {
  return (
    <svg viewBox="0 0 32 16" className="h-full w-full" preserveAspectRatio="none">
      {g.map((row, l) =>
        row.map((v, s) =>
          v > 0 ? <rect key={`${l}-${s}`} x={s * 2 + 0.2} y={l * 2 + 0.2} width="1.6" height="1.6" fill={active ? "#bff3ff" : "#27c6ff"} opacity={0.45 + v * 0.55} /> : null,
        ),
      )}
    </svg>
  );
}

function PatternTab() {
  const patterns = useStore((s) => s.patterns);
  const pattern = useStore((s) => s.pattern);
  const setPattern = useStore((s) => s.setPattern);
  const sel = useStore((s) => s.sel);
  const pad = useStore((s) => s.pads[sel]);
  const set = useStore((s) => s.set);
  const grid = patterns[pattern];
  const length = useStore((s) => s.length);
  const playStep = useStore((s) => s.playStep);
  const setStep = useStore((s) => s.setStep);
  const commit = useStore((s) => s.commit);
  const drag = useRef(false);

  const edit = (e: React.PointerEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const step = clamp(Math.floor(((e.clientX - r.left) / r.width) * 16), 0, 15);
    const v = clamp(1 - (e.clientY - r.top) / r.height, 0.05, 1);
    setStep(sel, step, Math.round(v * 20) / 20);
  };

  return (
    <Body cols="grid-cols-[400px_1fr]">
      <Panel title="PATTERN BANK">
        <div className="grid h-full grid-cols-2 grid-rows-4 gap-2">
          {patterns.map((g, i) => {
            const on = i === pattern;
            const used = g.some((r) => r.some((v) => v > 0));
            return (
              <button
                key={i}
                aria-pressed={on}
                onClick={() => setPattern(i)}
                className="flex flex-col rounded-md border p-1.5 text-left transition"
                style={{
                  borderColor: on ? "#9eefff" : "rgba(56,170,220,.3)",
                  background: on ? "linear-gradient(180deg,#0f6e9c,#0a3d59)" : "linear-gradient(180deg,#0c1e2e,#07121c)",
                  boxShadow: on ? "0 0 14px rgba(39,198,255,.45)" : "none",
                }}
              >
                <span className="mb-1 flex items-center justify-between text-[11px] font-medium">
                  <span>Pattern {String(i + 1).padStart(2, "0")}</span>
                  <span className="text-[9px] text-mute">{used ? "" : "empty"}</span>
                </span>
                <span className="inset block min-h-0 flex-1 p-1">
                  <MiniPattern g={g} active={on} />
                </span>
              </button>
            );
          })}
        </div>
      </Panel>

      <Panel title="STEP VELOCITY" right={<span className="text-[11px] text-mute">Drag across the bars · full height = accent</span>}>
        <div className="mb-2 flex gap-1.5">
          {grid.map((_, l) => (
            <button key={l} className="btn !h-[26px] flex-1" aria-pressed={sel === l} onClick={() => set({ sel: l })}>
              <LaneIcon kind={l} size={14} />
            </button>
          ))}
        </div>
        <div
          className="inset relative h-[262px] touch-none cursor-crosshair"
          onPointerDown={(e) => {
            e.currentTarget.setPointerCapture(e.pointerId);
            drag.current = true;
            commit();
            edit(e);
          }}
          onPointerMove={(e) => drag.current && edit(e)}
          onPointerUp={() => (drag.current = false)}
        >
          {[0.25, 0.5, 0.75].map((g) => (
            <div key={g} className="pointer-events-none absolute inset-x-0 border-t border-[rgba(56,170,220,.12)]" style={{ top: `${g * 100}%` }} />
          ))}
          <div className="pointer-events-none absolute inset-0 grid grid-cols-16 gap-[4px] p-[5px]">
            {grid[sel].map((v, s) => (
              <div key={s} className="relative flex items-end" style={{ opacity: s < length ? 1 : 0.3 }}>
                <div className="absolute inset-x-0 bottom-0 top-0 rounded-[3px]" style={{ background: s % 8 < 4 ? "rgba(20,60,90,.28)" : "rgba(20,60,90,.12)" }} />
                <div
                  className="relative w-full rounded-[3px]"
                  style={{
                    height: v > 0 ? `${v * 100}%` : "3px",
                    background: v >= 0.95 ? "linear-gradient(180deg,#b4f4ff,#38cdf8)" : v > 0 ? "linear-gradient(180deg,#43d2ff,#126f9a)" : "rgba(56,170,220,.25)",
                    boxShadow: v > 0 ? "0 0 8px rgba(39,198,255,.5)" : "none",
                    outline: playStep === s ? "1px solid #fff" : "none",
                  }}
                />
              </div>
            ))}
          </div>
        </div>
        <div className="mt-1 grid grid-cols-16 gap-[4px] px-[5px] text-center text-[10px] text-mute">
          {Array.from({ length: 16 }, (_, i) => (
            <span key={i} className={i % 4 === 0 ? "text-accent-hi" : ""}>
              {i + 1}
            </span>
          ))}
        </div>
        <p className="mt-1 text-[10.5px] text-mute">Editing lane: <span className="text-accent-hi">{pad.name}</span> — bars set the velocity of each active step. Click an empty slot to add a step.</p>
      </Panel>
    </Body>
  );
}

/* ================================================================== MIXER */
function VFader({ db, onChange, def = 0, label, level }: { db: number; onChange: (v: number) => void; def?: number; label: string; level: () => number }) {
  const meter = useRef<HTMLDivElement>(null);
  const hold = useRef(0);
  const drag = useRef(false);
  const n = (db + 60) / 66;
  useFrame(() => {
    hold.current = Math.max(level(), hold.current * 0.92);
    const d = 20 * Math.log10(Math.max(hold.current, 1e-4));
    if (meter.current) meter.current.style.height = `${clamp((d + 48) / 48, 0, 1) * 100}%`;
  });
  const upd = (e: React.PointerEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    let v = -60 + clamp((r.bottom - 4 - e.clientY) / (r.height - 8), 0, 1) * 66;
    if (!e.shiftKey && Math.abs(v) < 1.2) v = 0;
    if (v < -58.5) v = -60;
    onChange(Math.round(v * 10) / 10);
  };
  return (
    <div className="flex h-full justify-center gap-1.5">
      <div
        role="slider"
        tabIndex={0}
        aria-label={label}
        aria-valuemin={-60}
        aria-valuemax={6}
        aria-valuenow={db}
        aria-valuetext={fmtDb(1)(db)}
        className="inset relative w-[22px] cursor-ns-resize touch-none"
        onPointerDown={(e) => {
          e.currentTarget.setPointerCapture(e.pointerId);
          drag.current = true;
          upd(e);
        }}
        onPointerMove={(e) => drag.current && upd(e)}
        onPointerUp={() => (drag.current = false)}
        onDoubleClick={() => onChange(def)}
        onKeyDown={(e) => {
          if (e.key === "ArrowUp") onChange(clamp(db + 1, -60, 6));
          if (e.key === "ArrowDown") onChange(clamp(db - 1, -60, 6));
        }}
      >
        <div className="pointer-events-none absolute inset-x-0 border-t border-[rgba(255,255,255,.2)]" style={{ bottom: `calc(4px + (100% - 8px) * ${60 / 66})` }} />
        <div className="pointer-events-none absolute left-1/2 top-1 bottom-1 w-[3px] -translate-x-1/2 rounded bg-[#020609]" />
        <div
          className="pointer-events-none absolute left-1/2 h-[14px] w-[20px] -translate-x-1/2 translate-y-1/2 rounded-[3px] border border-[#9eefff]"
          style={{ bottom: `calc(4px + (100% - 8px) * ${n})`, background: "linear-gradient(180deg,#3a6580,#12293a)", boxShadow: "0 0 8px rgba(39,198,255,.4)" }}
        >
          <div className="mt-[5px] h-px bg-accent-hi" />
        </div>
      </div>
      <div className="inset relative flex w-[7px] items-end overflow-hidden">
        <div ref={meter} className="w-full" style={{ height: 0, background: "linear-gradient(0deg,#0f8fc2 0%,#29c4ff 62%,#d9f6ff 84%,#ffb347 100%)" }} />
      </div>
    </div>
  );
}

function Strip({
  name,
  db,
  onDb,
  def = 0,
  level,
  pan,
  onPan,
  mute,
  solo,
  onMute,
  onSolo,
  accent,
  sub,
}: {
  name: string;
  db: number;
  onDb: (v: number) => void;
  def?: number;
  level: () => number;
  pan?: number;
  onPan?: (v: number) => void;
  mute?: boolean;
  solo?: boolean;
  onMute?: () => void;
  onSolo?: () => void;
  accent?: boolean;
  sub?: ReactNode;
}) {
  return (
    <div className="flex w-[62px] flex-col items-center rounded-md border border-[rgba(56,170,220,.2)] bg-[rgba(3,10,17,.5)] py-1.5" style={accent ? { borderColor: "rgba(120,220,255,.6)" } : undefined}>
      <div className="mb-1 flex h-[14px] items-center text-[10.5px] font-medium text-txt">{sub ?? name}</div>
      <div className="flex h-[48px] items-center">
        {onPan ? <Knob label="Pan" hideLabel bipolar size={34} value={pan ?? 0} min={-1} max={1} def={0} fmt={fmtPan} onChange={(v) => onPan(Math.round(v * 100) / 100)} /> : <span className="text-[9px] text-mute">{accent ? "" : "bus"}</span>}
      </div>
      <div className="mb-1.5 flex h-[18px] gap-[3px]">
        {onMute && (
          <>
            <button className="w-[20px] rounded-[3px] border text-[10px] font-bold" aria-pressed={mute} aria-label={`Mute ${name}`} style={{ borderColor: mute ? "#f5a524" : "rgba(56,170,220,.35)", background: mute ? "#f5a524" : "#08151f", color: mute ? "#02121b" : "#b4def0" }} onClick={onMute}>
              M
            </button>
            <button className="w-[20px] rounded-[3px] border text-[10px] font-bold" aria-pressed={solo} aria-label={`Solo ${name}`} style={{ borderColor: solo ? "#2cc9ff" : "rgba(56,170,220,.35)", background: solo ? "#2cc9ff" : "#08151f", color: solo ? "#02121b" : "#b4def0" }} onClick={onSolo}>
              S
            </button>
          </>
        )}
      </div>
      <div className="h-[196px] w-full">
        <VFader db={db} def={def} onChange={onDb} label={`${name} level`} level={level} />
      </div>
      <span className="mt-1.5 text-[10.5px] tabular-nums text-accent-hi">{db <= -59.9 ? "-inf" : db.toFixed(1)}</span>
      <span className="text-[9px] text-mute">dB</span>
    </div>
  );
}

function MixerTab() {
  const pads = useStore((s) => s.pads);
  const { outsDb, returnsDb, masterDb } = useStore();
  const patch = useStore((s) => s.patchPad);
  const set = useStore((s) => s.set);
  const Sep = () => <div className="mx-0.5 w-px self-stretch bg-line" />;
  return (
    <Panel title="MIXER" className="h-[400px]" right={<span className="text-[11px] text-mute">Shift = fine · double-click = reset</span>}>
      <div className="flex h-full items-start justify-between">
        {pads.map((p, i) => (
          <Strip
            key={i}
            name={p.short}
            db={p.level}
            onDb={(v) => patch(i, { level: v })}
            level={() => engine.padLevel(i)}
            pan={p.pan}
            onPan={(v) => patch(i, { pan: v })}
            mute={p.mute}
            solo={p.solo}
            onMute={() => patch(i, { mute: !p.mute })}
            onSolo={() => patch(i, { solo: !p.solo })}
          />
        ))}
        <Sep />
        {[0, 1].map((r) => (
          <Strip
            key={r}
            name={r ? "Delay" : "Reverb"}
            db={returnsDb[r]}
            def={-3}
            onDb={(v) => set({ returnsDb: returnsDb.map((x, k) => (k === r ? v : x)) })}
            level={() => {
              let m = 0;
              pads.forEach((p, i) => (m = Math.max(m, engine.padLevel(i, 700) * dbToGain(r ? p.send2 : p.send1) * 1.4)));
              return m * dbToGain(returnsDb[r]);
            }}
          />
        ))}
        <Sep />
        {outsDb.map((o, k) => (
          <Strip
            key={k}
            name={`Out ${k + 1}`}
            db={o}
            onDb={(v) => set({ outsDb: outsDb.map((x, j) => (j === k ? v : x)) })}
            level={() => {
              let m = 0;
              pads.forEach((p, i) => p.out === k && (m = Math.max(m, engine.padLevel(i))));
              return m * dbToGain(o);
            }}
          />
        ))}
        <Sep />
        <Strip name="Master" accent db={masterDb} def={-3} onDb={(v) => set({ masterDb: v })} level={() => Math.max(...engine.meters())} />
      </div>
    </Panel>
  );
}

/* ================================================================== ROUTING */
function FlowBlock({ label, on, detail }: { label: string; on: boolean; detail: string }) {
  return (
    <div className="flex items-center justify-between rounded-md border px-3 py-[7px] text-[12px]" style={{ borderColor: on ? "rgba(120,220,255,.6)" : "rgba(80,130,160,.3)", background: on ? "linear-gradient(180deg,#0d3550,#082234)" : "#07121b", opacity: on ? 1 : 0.55 }}>
      <span className="font-medium">{label}</span>
      <span className="text-[11px] text-accent-hi">{detail}</span>
    </div>
  );
}

function RoutingTab() {
  const pads = useStore((s) => s.pads);
  const powers = useStore((s) => s.powers);
  const sel = useStore((s) => s.sel);
  const patch = useStore((s) => s.patchPad);
  const set = useStore((s) => s.set);
  const p = pads[sel];
  const Arrow = () => <div className="mx-auto h-[8px] w-px bg-[rgba(120,220,255,.6)]" />;
  return (
    <Body cols="grid-cols-[1fr_330px]">
      <Panel title="OUTPUT & SEND ROUTING">
        <div className="grid grid-cols-[1.3fr_repeat(4,52px)_74px_74px_92px] items-center gap-x-2 gap-y-[5px] text-[12px]">
          <span className="text-[10.5px] text-mute">Pad</span>
          {[1, 2, 3, 4].map((o) => (
            <span key={o} className="text-center text-[10.5px] text-mute">
              Out {o}
            </span>
          ))}
          <span className="text-center text-[10.5px] text-mute">Send 1</span>
          <span className="text-center text-[10.5px] text-mute">Send 2</span>
          <span className="text-center text-[10.5px] text-mute">Choke group</span>
          {pads.map((pd, i) => (
            <div key={i} className="contents">
              <button className="flex items-center gap-2 rounded px-1.5 py-1 text-left" style={{ background: sel === i ? "rgba(39,198,255,.16)" : "transparent", boxShadow: sel === i ? "inset 2px 0 0 #27c6ff" : "none" }} onClick={() => set({ sel: i })}>
                <span className="text-accent-hi">
                  <LaneIcon kind={pd.kind} size={15} />
                </span>
                {pd.name}
              </button>
              {[0, 1, 2, 3].map((o) => (
                <button
                  key={o}
                  role="radio"
                  aria-checked={pd.out === o}
                  aria-label={`${pd.name} to Out ${o + 1}`}
                  onClick={() => patch(i, { out: o })}
                  className="mx-auto grid h-[20px] w-[20px] place-items-center rounded-full border transition"
                  style={{ borderColor: pd.out === o ? "#9eefff" : "rgba(56,170,220,.4)", background: "#050f17" }}
                >
                  {pd.out === o && <span className="h-[10px] w-[10px] rounded-full bg-accent" style={{ boxShadow: "0 0 8px #27c6ff" }} />}
                </button>
              ))}
              <DragValue hideLabel label={`${pd.name} send 1`} value={pd.send1} min={-60} max={0} step={1} def={-12} fmt={fmtDb(0)} onChange={(v) => patch(i, { send1: v })} pxPerStep={2} />
              <DragValue hideLabel label={`${pd.name} send 2`} value={pd.send2} min={-60} max={0} step={1} def={-60} fmt={fmtDb(0)} onChange={(v) => patch(i, { send2: v })} pxPerStep={2} />
              <Select up={i > 4} label={`${pd.name} choke group`} height={22} value={pd.choke} options={[0, 1, 2, 3, 4].map((c) => ({ value: c, label: c ? `Group ${c}` : "Off" }))} onChange={(v) => patch(i, { choke: v })} />
            </div>
          ))}
        </div>
        <p className="mt-3 text-[10.5px] leading-relaxed text-mute">
          Pads sharing a choke group cut each other off (e.g. Closed Hat ↔ Open Hat). Outputs are individually routed buses that appear in the Mixer tab. Send 1 = Reverb, Send 2 = Tempo-synced Delay.
        </p>
      </Panel>
      <Panel title="SIGNAL FLOW" right={<span className="rounded-full border border-line bg-[#06121d] px-2 py-[2px] text-[10px] text-accent-hi">{p.name}</span>}>
        <div className="flex flex-col gap-0">
          <FlowBlock label="Sample" on={powers.sample && powers.bank} detail={p.reverse ? "reversed" : p.mode === "loop" ? "loop" : "one shot"} />
          <Arrow />
          <FlowBlock label="Pitch" on={p.pitchOn} detail={`${p.tune > 0 ? "+" : ""}${p.tune} st`} />
          <Arrow />
          <FlowBlock label="Filter" on={p.filterOn} detail={`${p.filterType.toUpperCase()} · ${fmtHz(p.cutoff)}`} />
          <Arrow />
          <FlowBlock label="Transient" on={p.transOn} detail={`A ${p.attack.toFixed(2)} · S ${p.sustain.toFixed(2)}`} />
          <Arrow />
          <FlowBlock label="Amp Envelope" on={powers.env} detail={`D ${Math.round(p.env.d)} ms`} />
          <Arrow />
          <FlowBlock label="Pan / Level" on={powers.perf} detail={`${fmtPan(p.pan)} · ${p.level.toFixed(1)} dB`} />
          <Arrow />
          <div className="grid grid-cols-3 gap-1.5">
            <FlowBlock label="Out" on detail={`${p.out + 1}`} />
            <FlowBlock label="Rev" on={powers.perf && p.send1 > -59} detail="S1" />
            <FlowBlock label="Dly" on={powers.perf && p.send2 > -59} detail="S2" />
          </div>
        </div>
      </Panel>
    </Body>
  );
}

/* ================================================================== ZONES */
const WHITE = [0, 2, 4, 5, 7, 9, 11];
const NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];

function ZonesTab() {
  const pads = useStore((s) => s.pads);
  const sel = useStore((s) => s.sel);
  const set = useStore((s) => s.set);
  const patch = useStore((s) => s.patchPad);
  const notes = Array.from({ length: 36 }, (_, i) => 24 + i);
  const whites = notes.filter((n) => WHITE.includes(n % 12));
  const padFor = (n: number) => pads.findIndex((p) => p.midi === n);
  const wPct = 100 / whites.length;
  const play = (n: number) => {
    const i = padFor(n);
    if (i >= 0) {
      set({ sel: i });
      engine.trigger(i, 0.9);
    }
  };
  return (
    <Body cols="grid-rows-[auto_1fr]">
      <Panel title="KEYBOARD MAPPING" right={<span className="text-[11px] text-mute">Highlighted keys trigger pads · click to audition</span>}>
        <div className="relative h-[150px] select-none">
          <div className="absolute inset-0 flex">
            {whites.map((n) => {
              const i = padFor(n);
              return (
                <button
                  key={n}
                  onPointerDown={() => play(n)}
                  aria-label={`${NOTE_NAMES[n % 12]}${Math.floor(n / 12) - 2}${i >= 0 ? ` – ${pads[i].name}` : ""}`}
                  className="relative flex h-full flex-col items-center justify-end border-r border-[#02060b] pb-1.5 text-[9px] transition"
                  style={{
                    width: `${wPct}%`,
                    borderRadius: "0 0 4px 4px",
                    background: i >= 0 ? (sel === i ? "linear-gradient(180deg,#8fe9ff,#2fb4e8)" : "linear-gradient(180deg,#4cc4ee,#1b86b5)") : "linear-gradient(180deg,#d9e6ee,#aebfca)",
                    color: i >= 0 ? "#02131c" : "#4c6577",
                    boxShadow: i >= 0 ? "0 0 12px rgba(39,198,255,.5)" : "none",
                  }}
                >
                  {i >= 0 && <span className="mb-1 -rotate-90 whitespace-nowrap text-[10px] font-semibold">{pads[i].short}</span>}
                  {n % 12 === 0 ? `C${Math.floor(n / 12) - 2}` : ""}
                </button>
              );
            })}
          </div>
          {notes
            .filter((n) => !WHITE.includes(n % 12))
            .map((n) => {
              const wi = whites.filter((w) => w < n).length;
              const i = padFor(n);
              return (
                <button
                  key={n}
                  onPointerDown={() => play(n)}
                  aria-label={`${NOTE_NAMES[n % 12]}${Math.floor(n / 12) - 2}${i >= 0 ? ` – ${pads[i].name}` : ""}`}
                  className="absolute top-0 z-10 h-[90px] rounded-b-[3px] border border-black"
                  style={{
                    left: `calc(${wi * wPct}% - ${wPct * 0.3}%)`,
                    width: `${wPct * 0.6}%`,
                    background: i >= 0 ? (sel === i ? "linear-gradient(180deg,#59d3ff,#0b78b0)" : "linear-gradient(180deg,#1f90c4,#0a4466)") : "linear-gradient(180deg,#1c2a35,#060b10)",
                    boxShadow: i >= 0 ? "0 0 10px rgba(39,198,255,.55)" : "none",
                  }}
                >
                  {i >= 0 && <span className="block -rotate-90 whitespace-nowrap text-[9px] font-semibold text-white">{pads[i].short}</span>}
                </button>
              );
            })}
        </div>
      </Panel>
      <Panel title="VELOCITY ZONES" right={<span className="text-[11px] text-mute">Hits outside the range are ignored (MIDI velocity 1–127)</span>}>
        <div className="grid h-full grid-cols-4 grid-rows-2 gap-2">
          {pads.map((p, i) => (
            <div key={i} className="rounded-md border p-2" style={{ borderColor: sel === i ? "#9eefff" : "rgba(56,170,220,.25)", background: sel === i ? "rgba(39,198,255,.1)" : "rgba(3,10,17,.5)" }}>
              <button className="mb-1 flex w-full items-center gap-2 text-left text-[12px] font-medium" onClick={() => set({ sel: i })}>
                <span className="text-accent-hi">
                  <LaneIcon kind={p.kind} size={15} />
                </span>
                {p.name}
                <span className="ml-auto text-[10.5px] text-mute">
                  {p.note} · {p.midi}
                </span>
              </button>
              <div className="relative mb-1 h-[8px] rounded-full bg-[#020609]">
                <div className="absolute inset-y-0 rounded-full bg-accent" style={{ left: `${(p.velLo / 127) * 100}%`, width: `${((p.velHi - p.velLo) / 127) * 100}%`, boxShadow: "0 0 8px #27c6ff" }} />
              </div>
              <div className="flex justify-around">
                <DragValue label="Low" value={p.velLo} min={1} max={p.velHi} def={1} fmt={(v) => `${v}`} onChange={(v) => patch(i, { velLo: v })} pxPerStep={1.5} />
                <DragValue label="High" value={p.velHi} min={p.velLo} max={127} def={127} fmt={(v) => `${v}`} onChange={(v) => patch(i, { velHi: v })} pxPerStep={1.5} />
              </div>
            </div>
          ))}
        </div>
      </Panel>
    </Body>
  );
}

/* ================================================================== MACROS */
const MACROS = [
  { name: "PUNCH", def: 0, desc: ["Transient attack boost on all pads", "Adds up to +0.6 to every Attack"], fmt: (v: number) => `${Math.round(v * 100)}%` },
  { name: "TONE", def: 0.5, desc: ["Filter cutoff on all pads", "−3 … +3 octaves, auto-engages a low-pass"], fmt: (v: number) => `${v > 0.5 ? "+" : ""}${Math.round((v - 0.5) * 200)}%` },
  { name: "SPACE", def: 0, desc: ["Reverb & delay sends on all pads", "Opens Send 1 and Send 2 together"], fmt: (v: number) => `${Math.round(v * 100)}%` },
  { name: "DECAY", def: 0.5, desc: ["Envelope decay on all pads", "Scales Decay from ×0.5 to ×2"], fmt: (v: number) => `×${Math.pow(2, (v - 0.5) * 2).toFixed(2)}` },
];

function MacrosTab() {
  const macros = useStore((s) => s.macros);
  const set = useStore((s) => s.set);
  return (
    <Body cols="grid-cols-4">
      {MACROS.map((m, i) => (
        <Panel key={m.name} title={`MACRO ${i + 1} · ${m.name}`} className="items-stretch">
          <div className="flex h-full flex-col items-center justify-between pb-1 pt-4">
            <Knob label={m.name} hideLabel size={120} bipolar={m.def === 0.5} value={macros[i]} min={0} max={1} def={m.def} fmt={m.fmt} onChange={(v) => set({ macros: macros.map((x, k) => (k === i ? v : x)) })} />
            <div className="w-full rounded-md border border-line bg-[rgba(3,10,17,.5)] p-2.5 text-center">
              <p className="text-[12px] font-medium text-txt">{m.desc[0]}</p>
              <p className="mt-1 text-[10.5px] text-mute">{m.desc[1]}</p>
            </div>
            <button className="btn mt-3" onClick={() => set({ macros: macros.map((x, k) => (k === i ? m.def : x)) })}>
              <RotateCcw size={12} /> Reset
            </button>
          </div>
        </Panel>
      ))}
    </Body>
  );
}

/* ================================================================== ADVANCED */
function AdvancedTab() {
  const { adv, sel, pads } = useStore();
  const set = useStore((s) => s.set);
  const resetPad = useStore((s) => s.resetPad);
  const flash = useStore((s) => s.flashHint);
  const setAdv = (p: Partial<typeof adv>) => set({ adv: { ...adv, ...p } });
  return (
    <Body cols="grid-cols-3">
      <Panel title="PLAYBACK ENGINE">
        <div className="flex justify-around pt-2">
          <Knob label="Master Tune" size={52} bipolar value={adv.masterTune} min={-100} max={100} def={0} fmt={(v) => `${v > 0 ? "+" : ""}${Math.round(v)} ct`} onChange={(v) => setAdv({ masterTune: Math.round(v) })} />
          <Knob label="Vel. Sensitivity" size={52} value={adv.velSens} min={0} max={1} def={1} fmt={(v) => `${Math.round(v * 100)}%`} onChange={(v) => setAdv({ velSens: v })} />
        </div>
        <div className="mt-5 space-y-3 text-[12px]">
          <div className="flex items-center justify-between">
            <span className="text-mute">Velocity curve</span>
            <Select label="Velocity curve" className="w-[130px]" value={adv.velCurve} options={[{ value: 0, label: "Soft" }, { value: 1, label: "Linear" }, { value: 2, label: "Hard" }]} onChange={(v) => setAdv({ velCurve: v })} />
          </div>
          <div className="flex items-center justify-between">
            <span className="text-mute">Choke groups</span>
            <button className="btn w-[130px]" aria-pressed={adv.choke} onClick={() => setAdv({ choke: !adv.choke })}>
              {adv.choke ? "Enabled" : "Disabled"}
            </button>
          </div>
        </div>
      </Panel>
      <Panel title="EFFECT BUSES">
        <div className="flex justify-around pt-2">
          <Knob label="Reverb Size" size={52} value={adv.reverbSize} min={0.4} max={4} def={1.8} fmt={(v) => `${v.toFixed(1)} s`} onChange={(v) => setAdv({ reverbSize: Math.round(v * 10) / 10 })} />
          <Knob label="Delay Feedback" size={52} value={adv.delayFb} min={0} max={0.9} def={0.4} fmt={(v) => `${Math.round(v * 100)}%`} onChange={(v) => setAdv({ delayFb: v })} />
        </div>
        <div className="mt-5 flex items-center justify-between text-[12px]">
          <span className="text-mute">Delay time (tempo-sync)</span>
          <Select label="Delay time" className="w-[130px]" value={adv.delayDiv} options={DELAY_DIVS.map((d, i) => ({ value: i, label: d.label }))} onChange={(v) => setAdv({ delayDiv: v })} />
        </div>
        <p className="mt-4 text-[10.5px] leading-relaxed text-mute">Send 1 feeds a convolution reverb, Send 2 a ping-style feedback delay locked to the sequencer tempo. Return levels live in the Mixer tab.</p>
      </Panel>
      <Panel title="UTILITY & SHORTCUTS">
        <div className="grid grid-cols-1 gap-2">
          <button className="btn !h-[28px]" onClick={() => (resetPad(sel), flash(`${pads[sel].name} reset to defaults`))}>
            <RotateCcw size={12} /> Reset selected pad ({pads[sel].name})
          </button>
          <button className="btn !h-[28px]" onClick={() => (set({ macros: [0, 0.5, 0, 0.5] }), flash("Macros reset"))}>
            Reset all macros
          </button>
          <button className="btn !h-[28px]" onClick={() => (useStore.getState().loadPreset(0), flash(`Preset “${PRESETS[0].name}” loaded`))}>
            Load init preset
          </button>
        </div>
        <dl className="mt-4 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1.5 text-[11.5px]">
          {[
            ["A S D F / Z X C V", "Play pads 1–8"],
            ["Space", "Play / stop sequencer"],
            ["Ctrl + Z", "Undo pattern edit"],
            ["Click · Shift/Right-click", "Toggle step · accent step"],
            ["Double-click", "Reset knob to default"],
            ["Shift + drag", "Fine adjustment"],
          ].map(([k, v]) => (
            <div key={k} className="contents">
              <dt className="font-medium text-accent-hi">{k}</dt>
              <dd className="text-mute">{v}</dd>
            </div>
          ))}
        </dl>
      </Panel>
    </Body>
  );
}

export function TabContent({ tab }: { tab: string }) {
  switch (tab) {
    case "pattern":
      return <PatternTab />;
    case "mixer":
      return <MixerTab />;
    case "routing":
      return <RoutingTab />;
    case "zones":
      return <ZonesTab />;
    case "macros":
      return <MacrosTab />;
    default:
      return <AdvancedTab />;
  }
}
