import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { ChevronDown, ChevronLeft, ChevronRight, Power } from "lucide-react";
import { useStore } from "../store";
import { clamp, fromNorm, toNorm } from "../utils/math";

/* ------------------------------------------------------------------ */
export function useFrame(cb: () => void) {
  const ref = useRef(cb);
  ref.current = cb;
  useEffect(() => {
    let id = 0;
    const loop = () => {
      ref.current();
      id = requestAnimationFrame(loop);
    };
    id = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(id);
  }, []);
}

/** shows hint text in the status bar while hovered / dragged */
export function useHint(text: string, active: boolean) {
  const setHint = useStore((s) => s.setHint);
  useEffect(() => {
    if (active) setHint(text);
  }, [text, active, setHint]);
}

/* ------------------------------------------------------------------ */
export function PowerBtn({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) {
  return (
    <button
      type="button"
      aria-pressed={on}
      aria-label={`${label} ${on ? "on" : "off"}`}
      title={`${label}: ${on ? "On" : "Off"}`}
      onClick={onClick}
      className="grid h-[18px] w-[18px] shrink-0 place-items-center rounded-full border transition"
      style={{
        borderColor: on ? "#7fe3ff" : "rgba(80,130,160,.5)",
        color: on ? "#8ee8ff" : "#4d7188",
        background: on ? "radial-gradient(circle,#0f4a66,#07202f)" : "#07131d",
        boxShadow: on ? "0 0 9px rgba(39,198,255,.6)" : "none",
      }}
    >
      <Power size={11} strokeWidth={2.6} />
    </button>
  );
}

export function Panel({
  title,
  power,
  onPower,
  right,
  className = "",
  children,
  dim,
}: {
  title: string;
  power?: boolean;
  onPower?: () => void;
  right?: ReactNode;
  className?: string;
  children: ReactNode;
  dim?: boolean;
}) {
  return (
    <section className={`panel flex flex-col ${className}`} aria-label={title}>
      <header className="flex h-[34px] shrink-0 items-center gap-2 px-2.5">
        {onPower && <PowerBtn on={!!power} onClick={onPower} label={title} />}
        <h2 className="panel-title">{title}</h2>
        <div className="ml-auto flex items-center gap-1.5">{right}</div>
      </header>
      <div
        className="relative min-h-0 flex-1 px-2.5 pb-2.5 transition-opacity"
        style={{ opacity: dim ? 0.42 : 1, filter: dim ? "saturate(.5)" : undefined }}
      >
        {children}
      </div>
    </section>
  );
}

export function IconBtn({
  onClick,
  label,
  children,
  className = "",
  pressed,
}: {
  onClick?: () => void;
  label: string;
  children: ReactNode;
  className?: string;
  pressed?: boolean;
}) {
  return (
    <button
      type="button"
      className={`btn !px-0 ${className}`}
      onClick={onClick}
      aria-label={label}
      title={label}
      aria-pressed={pressed}
    >
      {children}
    </button>
  );
}

export const Prev = ({ onClick, label = "Previous", className = "w-[22px]" }: { onClick: () => void; label?: string; className?: string }) => (
  <IconBtn onClick={onClick} label={label} className={className}>
    <ChevronLeft size={14} />
  </IconBtn>
);
export const Next = ({ onClick, label = "Next", className = "w-[22px]" }: { onClick: () => void; label?: string; className?: string }) => (
  <IconBtn onClick={onClick} label={label} className={className}>
    <ChevronRight size={14} />
  </IconBtn>
);

/* ------------------------------------------------------------------ */
export interface Opt<T> {
  value: T;
  label: string;
}

export function Select<T extends string | number>({
  value,
  options,
  onChange,
  className = "",
  label,
  height = 24,
  up,
}: {
  value: T;
  options: Opt<T>[];
  onChange: (v: T) => void;
  className?: string;
  label: string;
  height?: number;
  up?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [hi, setHi] = useState(0);
  const root = useRef<HTMLDivElement>(null);
  const idx = Math.max(0, options.findIndex((o) => o.value === value));

  useEffect(() => {
    if (!open) return;
    const h = (e: PointerEvent) => {
      if (!root.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("pointerdown", h);
    return () => document.removeEventListener("pointerdown", h);
  }, [open]);

  const key = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") return setOpen(false);
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      const d = e.key === "ArrowDown" ? 1 : -1;
      if (open) setHi((h) => clamp(h + d, 0, options.length - 1));
      else onChange(options[clamp(idx + d, 0, options.length - 1)].value);
    }
    if (e.key === "Enter" && open) {
      e.preventDefault();
      onChange(options[hi].value);
      setOpen(false);
    }
  };

  return (
    <div ref={root} className={`relative ${className}`} onKeyDown={key}>
      <button
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={label}
        title={label}
        onClick={() => {
          setHi(idx);
          setOpen((o) => !o);
        }}
        className="inset flex w-full items-center justify-between gap-1 px-2 text-left text-[12px] text-txt transition hover:border-[rgba(120,220,255,.6)]"
        style={{ height }}
      >
        <span className="truncate">{options[idx]?.label}</span>
        <ChevronDown size={14} className={`shrink-0 text-accent-hi transition ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <ul
          role="listbox"
          aria-label={label}
          className={`absolute left-0 z-[60] max-h-56 ${up ? "bottom-full mb-1" : "top-full mt-1"} min-w-full overflow-auto rounded-md border border-[rgba(120,220,255,.5)] bg-[#061320] py-1 shadow-[0_8px_24px_rgba(0,0,0,.7),0_0_14px_rgba(39,198,255,.2)]`}
        >
          {options.map((o, i) => (
            <li
              key={String(o.value)}
              role="option"
              aria-selected={o.value === value}
              onMouseEnter={() => setHi(i)}
              onClick={() => {
                onChange(o.value);
                setOpen(false);
              }}
              className="cursor-pointer whitespace-nowrap px-2.5 py-[5px] text-[12px]"
              style={{
                background: i === hi ? "rgba(39,198,255,.2)" : undefined,
                color: o.value === value ? "#8ee8ff" : "#cfe8f5",
                fontWeight: o.value === value ? 600 : 400,
              }}
            >
              {o.label}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
const pol = (cx: number, cy: number, r: number, a: number) => {
  const rad = (a * Math.PI) / 180;
  return [cx + r * Math.sin(rad), cy - r * Math.cos(rad)];
};
const arc = (r: number, a0: number, a1: number) => {
  if (Math.abs(a1 - a0) < 0.5) return "";
  const [x0, y0] = pol(24, 24, r, a0);
  const [x1, y1] = pol(24, 24, r, a1);
  return `M${x0} ${y0} A${r} ${r} 0 ${Math.abs(a1 - a0) > 180 ? 1 : 0} ${a1 > a0 ? 1 : 0} ${x1} ${y1}`;
};

export interface KnobProps {
  label: string;
  value: number;
  min: number;
  max: number;
  def: number;
  onChange: (v: number) => void;
  fmt: (v: number) => string;
  log?: boolean;
  bipolar?: boolean;
  size?: number;
  hideLabel?: boolean;
  labelClass?: string;
  disabled?: boolean;
}

export function Knob({ label, value, min, max, def, onChange, fmt, log, bipolar, size = 44, hideLabel, labelClass = "", disabled }: KnobProps) {
  const n = toNorm(value, min, max, log);
  const drag = useRef<{ y: number; n: number } | null>(null);
  const el = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(false);
  const [hover, setHover] = useState(false);
  const stateRef = useRef({ n, min, max, log, onChange });
  stateRef.current = { n, min, max, log, onChange };
  useHint(`${label}: ${fmt(value)}   ·   drag / wheel to adjust, Shift = fine, double-click = reset`, hover || active);

  const apply = useCallback((nn: number) => {
    const c = stateRef.current;
    nn = clamp(nn, 0, 1);
    if (bipolar && Math.abs(nn - 0.5) < 0.012) nn = 0.5;
    c.onChange(fromNorm(nn, c.min, c.max, c.log));
  }, [bipolar]);

  useEffect(() => {
    const node = el.current;
    if (!node) return;
    const w = (e: WheelEvent) => {
      e.preventDefault();
      apply(stateRef.current.n - Math.sign(e.deltaY) * (e.shiftKey ? 0.004 : 0.03));
    };
    node.addEventListener("wheel", w, { passive: false });
    return () => node.removeEventListener("wheel", w);
  }, [apply]);

  const a1 = -135 + n * 270;
  const a0 = bipolar ? 0 : -135;
  const aEnd = bipolar ? -135 + n * 270 : a1;
  const [ix, iy] = pol(24, 24, 13, a1);
  const [jx, jy] = pol(24, 24, 5, a1);

  return (
    <div
      className={`flex flex-col items-center ${disabled ? "pointer-events-none opacity-50" : ""}`}
      onPointerEnter={() => setHover(true)}
      onPointerLeave={() => {
        setHover(false);
        if (!active) useStore.getState().setHint("");
      }}
    >
      {!hideLabel && <span className={`mb-[3px] text-[10.5px] leading-none text-mute ${labelClass}`}>{label}</span>}
      <div
        ref={el}
        role="slider"
        tabIndex={0}
        aria-label={label}
        aria-valuemin={min}
        aria-valuemax={max}
        aria-valuenow={Number(value.toFixed(3))}
        aria-valuetext={fmt(value)}
        className="cursor-ns-resize touch-none rounded-full"
        style={{ width: size, height: size }}
        onPointerDown={(e) => {
          e.currentTarget.setPointerCapture(e.pointerId);
          drag.current = { y: e.clientY, n };
          setActive(true);
        }}
        onPointerMove={(e) => {
          if (!drag.current) return;
          const k = e.shiftKey ? 0.0008 : 0.0075;
          apply(drag.current.n + (drag.current.y - e.clientY) * k);
        }}
        onPointerUp={() => {
          drag.current = null;
          setActive(false);
        }}
        onDoubleClick={() => onChange(def)}
        onKeyDown={(e) => {
          const step = e.shiftKey ? 0.1 : 0.02;
          if (e.key === "ArrowUp" || e.key === "ArrowRight") (e.preventDefault(), apply(n + step));
          if (e.key === "ArrowDown" || e.key === "ArrowLeft") (e.preventDefault(), apply(n - step));
          if (e.key === "Home") (e.preventDefault(), onChange(def));
        }}
      >
        <svg viewBox="0 0 48 48" width="100%" height="100%" className="overflow-visible">
          <defs>
            <radialGradient id="kb" cx="40%" cy="30%" r="80%">
              <stop offset="0%" stopColor="#2c506b" />
              <stop offset="60%" stopColor="#0c1f2f" />
              <stop offset="100%" stopColor="#040b12" />
            </radialGradient>
          </defs>
          <path d={arc(20, -135, 135)} stroke="rgba(80,140,180,.28)" strokeWidth="3" fill="none" strokeLinecap="round" />
          <path
            d={arc(20, a0, aEnd)}
            stroke="#29c4ff"
            strokeWidth="3"
            fill="none"
            strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 ${active ? 5 : 3}px #29c4ff)` }}
          />
          <circle cx="24" cy="24" r="15.5" fill="url(#kb)" stroke="rgba(130,210,245,.35)" strokeWidth="1" />
          <circle cx="24" cy="24" r="11" fill="none" stroke="rgba(0,0,0,.45)" strokeWidth="1" />
          <line x1={jx} y1={jy} x2={ix} y2={iy} stroke="#d5f6ff" strokeWidth="2.2" strokeLinecap="round" style={{ filter: "drop-shadow(0 0 2px #29c4ff)" }} />
        </svg>
      </div>
      <span className={`mt-[3px] text-[11px] leading-none tabular-nums ${active ? "text-accent-hi" : "text-txt"}`}>{fmt(value)}</span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/** compact vertical-drag number field (label above, value below) */
export function DragValue({
  label,
  hideLabel,
  value,
  min,
  max,
  def,
  step = 1,
  fmt,
  onChange,
  className = "",
  pxPerStep = 4,
  vertical = true,
}: {
  label?: string;
  hideLabel?: boolean;
  value: number;
  min: number;
  max: number;
  def: number;
  step?: number;
  fmt: (v: number) => string;
  onChange: (v: number) => void;
  className?: string;
  pxPerStep?: number;
  vertical?: boolean;
}) {
  const drag = useRef<{ y: number; v: number } | null>(null);
  const [active, setActive] = useState(false);
  const [hover, setHover] = useState(false);
  const el = useRef<HTMLDivElement>(null);
  const ref = useRef({ value, min, max, step, onChange });
  ref.current = { value, min, max, step, onChange };
  useHint(`${label ?? "Value"}: ${fmt(value)}   ·   drag up/down or wheel, double-click = reset`, hover || active);

  const set = (v: number) => {
    const c = ref.current;
    c.onChange(clamp(Math.round(v / c.step) * c.step, c.min, c.max));
  };
  useEffect(() => {
    const node = el.current;
    if (!node) return;
    const w = (e: WheelEvent) => {
      e.preventDefault();
      set(ref.current.value - Math.sign(e.deltaY) * ref.current.step);
    };
    node.addEventListener("wheel", w, { passive: false });
    return () => node.removeEventListener("wheel", w);
  }, []);

  return (
    <div
      ref={el}
      role="spinbutton"
      tabIndex={0}
      aria-label={label}
      aria-valuenow={value}
      aria-valuemin={min}
      aria-valuemax={max}
      aria-valuetext={fmt(value)}
      className={`flex cursor-ns-resize touch-none flex-col items-center justify-center rounded px-2 py-0.5 leading-none transition hover:bg-[rgba(39,198,255,.08)] ${className}`}
      onPointerEnter={() => setHover(true)}
      onPointerLeave={() => {
        setHover(false);
        if (!active) useStore.getState().setHint("");
      }}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        drag.current = { y: vertical ? e.clientY : e.clientX, v: value };
        setActive(true);
      }}
      onPointerMove={(e) => {
        if (!drag.current) return;
        const d = vertical ? drag.current.y - e.clientY : e.clientX - drag.current.y;
        set(drag.current.v + Math.round(d / (e.shiftKey ? pxPerStep * 4 : pxPerStep)) * step);
      }}
      onPointerUp={() => {
        drag.current = null;
        setActive(false);
      }}
      onDoubleClick={() => onChange(def)}
      onKeyDown={(e) => {
        if (e.key === "ArrowUp" || e.key === "ArrowRight") (e.preventDefault(), set(value + step));
        if (e.key === "ArrowDown" || e.key === "ArrowLeft") (e.preventDefault(), set(value - step));
      }}
    >
      {label && !hideLabel && <span className="mb-[5px] text-[10.5px] text-mute">{label}</span>}
      <span className={`text-[12.5px] font-medium tabular-nums ${active ? "text-accent-hi" : "text-txt"}`}>{fmt(value)}</span>
    </div>
  );
}
