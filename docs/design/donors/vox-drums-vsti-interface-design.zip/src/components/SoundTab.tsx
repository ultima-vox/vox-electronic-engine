import { useMemo, useRef, type PointerEvent as RPE, type ReactNode } from "react";
import { FILTER_LABELS, KITS, useStore, type FilterType } from "../store";
import { SAMPLE_NAMES, getProcessed } from "../audio/samples";
import { engine } from "../audio/engine";
import { clamp, fmtDb, fmtHz, fmtMs, fmtPan, fmtSigned, fromNorm, toNorm } from "../utils/math";
import { Banner } from "./Header";
import { Knob, Next, Panel, Prev, Select, useFrame } from "./ui";

const usePad = () => {
  const sel = useStore((s) => s.sel);
  const pad = useStore((s) => s.pads[s.sel]);
  const patch = useStore((s) => s.patchPad);
  return { sel, pad, patch: (p: Parameters<typeof patch>[1]) => patch(sel, p) };
};

const Chip = () => {
  const name = useStore((s) => s.pads[s.sel].name);
  return <span className="rounded-full border border-line bg-[#06121d] px-2 py-[2px] text-[10px] text-accent-hi">{name}</span>;
};

/* ------------------------------------------------------------ Pad bank */
export function PadButton({ i }: { i: number }) {
  const pad = useStore((s) => s.pads[i]);
  const selected = useStore((s) => s.sel === i);
  const set = useStore((s) => s.set);
  const glow = useRef<HTMLDivElement>(null);
  useFrame(() => {
    if (glow.current) glow.current.style.opacity = String(Math.min(1, engine.padLevel(i, 160) * 1.3));
  });
  const hit = (e: RPE<HTMLButtonElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const rel = clamp((e.clientY - r.top) / r.height, 0, 1);
    set({ sel: i });
    engine.trigger(i, 1 - rel * 0.45);
  };
  return (
    <button
      type="button"
      onPointerDown={hit}
      onClick={(e) => {
        if (e.detail === 0) {
          set({ sel: i });
          engine.trigger(i, 0.9);
        }
      }}
      aria-pressed={selected}
      aria-label={`Pad ${pad.note} ${pad.name}`}
      title={`${pad.note} – ${pad.name}\nClick to select & play (higher on the pad = harder hit)`}
      className="relative flex flex-col items-center justify-center overflow-hidden rounded-md border text-center transition active:scale-[0.98]"
      style={{
        borderColor: selected ? "#9eefff" : "rgba(56,170,220,.38)",
        background: selected ? "linear-gradient(180deg,#2fc8ff 0%,#0b78b0 100%)" : "linear-gradient(180deg,#0e2335 0%,#07131e 100%)",
        boxShadow: selected ? "0 0 16px rgba(39,198,255,.55), inset 0 1px 0 rgba(255,255,255,.35)" : "inset 0 1px 0 rgba(130,225,255,.06)",
        opacity: pad.mute ? 0.55 : 1,
      }}
    >
      <div ref={glow} className="pointer-events-none absolute inset-0 opacity-0" style={{ background: "radial-gradient(circle at 50% 50%,rgba(220,250,255,.75),rgba(39,198,255,.0) 70%)" }} />
      <span className="relative text-[11px] leading-none" style={{ color: selected ? "#d4f6ff" : "#7fb5d0" }}>
        {pad.note}
      </span>
      <span className="relative mt-[6px] text-[12.5px] font-medium leading-none" style={{ color: selected ? "#fff" : "#d3ecf8" }}>
        {pad.name}
      </span>
      {(pad.mute || pad.solo) && (
        <span className="absolute right-1 top-1 rounded-sm px-1 text-[8px] font-bold leading-[11px]" style={{ background: pad.solo ? "#2cc9ff" : "#f5a524", color: "#02131c" }}>
          {pad.solo ? "S" : "M"}
        </span>
      )}
    </button>
  );
}

function PadBank() {
  const { kit, powers } = useStore();
  const set = useStore((s) => s.set);
  const loadKit = useStore((s) => s.loadKit);
  return (
    <Panel
      title="DRUM PAD BANK"
      power={powers.bank}
      onPower={() => set({ powers: { ...powers, bank: !powers.bank } })}
      dim={!powers.bank}
      right={
        <>
          <Select label="Drum kit" className="w-[116px]" height={22} value={kit} options={KITS.map((k, i) => ({ value: i, label: k }))} onChange={loadKit} />
          <Prev className="w-[20px]" label="Previous kit" onClick={() => loadKit((kit + KITS.length - 1) % KITS.length)} />
          <Next className="w-[20px]" label="Next kit" onClick={() => loadKit((kit + 1) % KITS.length)} />
        </>
      }
    >
      <div className="grid h-full grid-cols-4 grid-rows-2 gap-[6px]">
        {Array.from({ length: 8 }, (_, i) => (
          <PadButton key={i} i={i} />
        ))}
      </div>
    </Panel>
  );
}

/* ------------------------------------------------------------ Sample */
function Waveform() {
  const { sel, pad } = usePad();
  const play = useRef<HTMLDivElement>(null);
  const data = useMemo(() => getProcessed(pad.kind, pad.variant, pad.reverse, pad.normalize), [pad.kind, pad.variant, pad.reverse, pad.normalize]);
  const path = useMemo(() => {
    const N = 240;
    const block = data.length / N;
    let d = "";
    for (let b = 0; b < N; b++) {
      let mn = 0, mx = 0;
      for (let i = Math.floor(b * block); i < Math.floor((b + 1) * block); i++) {
        mn = Math.min(mn, data[i]);
        mx = Math.max(mx, data[i]);
      }
      const y0 = 50 - mx * 46;
      const y1 = 50 - mn * 46;
      d += `M${b + 0.5} ${y0.toFixed(1)}V${Math.max(y1, y0 + 0.8).toFixed(1)}`;
    }
    return d;
  }, [data]);

  useFrame(() => {
    const f = engine.flash[sel];
    const el = play.current;
    if (!el) return;
    if (!f) return;
    const prog = (performance.now() - f.t) / f.dur;
    if (prog >= 0 && prog <= 1) {
      el.style.opacity = "1";
      el.style.left = `${prog * 100}%`;
    } else el.style.opacity = "0";
  });

  return (
    <div className="inset relative h-[74px] overflow-hidden">
      <svg viewBox="0 0 240 100" preserveAspectRatio="none" className="h-full w-full" role="img" aria-label={`Waveform of ${SAMPLE_NAMES[pad.kind][pad.variant]}`}>
        <line x1="0" x2="240" y1="50" y2="50" stroke="rgba(56,170,220,.25)" strokeWidth="1" vectorEffect="non-scaling-stroke" />
        <path d={path} stroke="#25c1ff" strokeWidth="1.7" vectorEffect="non-scaling-stroke" fill="none" style={{ filter: "drop-shadow(0 0 3px rgba(39,198,255,.8))" }} />
      </svg>
      <div ref={play} className="pointer-events-none absolute inset-y-0 w-px bg-white opacity-0" style={{ boxShadow: "0 0 8px #fff" }} />
    </div>
  );
}

function SamplePanel() {
  const { pad, patch } = usePad();
  const { powers } = useStore();
  const set = useStore((s) => s.set);
  const names = SAMPLE_NAMES[pad.kind];
  const dur = getProcessed(pad.kind, pad.variant, false, false).length / 44100;
  return (
    <Panel
      title="SAMPLE"
      power={powers.sample}
      onPower={() => set({ powers: { ...powers, sample: !powers.sample } })}
      dim={!powers.sample}
      right={
        <>
          <Select label="Sample" className="w-[134px]" height={22} value={pad.variant} options={names.map((n, i) => ({ value: i, label: n }))} onChange={(v) => patch({ variant: v })} />
          <Next className="w-[20px]" label="Next sample" onClick={() => patch({ variant: (pad.variant + 1) % names.length })} />
        </>
      }
    >
      <Waveform />
      <div className="mt-[3px] flex justify-between text-[9.5px] leading-none text-mute tabular-nums">
        <span>0.00s</span>
        <span>{dur.toFixed(2)}s</span>
      </div>
      <div className="mt-[7px] grid grid-cols-4 gap-1.5">
        <button className="btn" aria-pressed={pad.reverse} onClick={() => patch({ reverse: !pad.reverse })} title="Play the sample backwards">
          Reverse
        </button>
        <button className="btn" aria-pressed={pad.normalize} onClick={() => patch({ normalize: !pad.normalize })} title="Scale the sample to full level">
          Normalize
        </button>
        <button className="btn" aria-pressed={pad.mode === "oneshot"} onClick={() => patch({ mode: "oneshot" })} title="Play the whole sample, ignore note length">
          One Shot
        </button>
        <button className="btn" aria-pressed={pad.mode === "loop"} onClick={() => patch({ mode: "loop" })} title="Loop the sample while the envelope sustains">
          Loop
        </button>
      </div>
    </Panel>
  );
}

/* ------------------------------------------------------------ Envelope */
const E = { x0: 0.03, sa: 0.26, sd: 0.28, sh: 0.12, sr: 0.26, yp: 0.12, yz: 0.9 };

function Handle({ x, y, label, onMove, vertical }: { x: number; y: number; label: string; onMove: (px: number, py: number) => void; vertical?: boolean }) {
  const parent = useRef<HTMLDivElement>(null);
  const drag = useRef(false);
  return (
    <div
      ref={parent}
      role="slider"
      aria-label={label}
      aria-valuenow={Math.round(x * 100)}
      tabIndex={0}
      className="absolute h-[11px] w-[11px] -translate-x-1/2 -translate-y-1/2 touch-none rounded-full border-2 border-white bg-accent"
      style={{ left: `${x * 100}%`, top: `${y * 100}%`, cursor: vertical ? "move" : "ew-resize", boxShadow: "0 0 8px #27c6ff" }}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        drag.current = true;
      }}
      onPointerMove={(e) => {
        if (!drag.current) return;
        const r = e.currentTarget.parentElement!.getBoundingClientRect();
        onMove((e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height);
      }}
      onPointerUp={() => (drag.current = false)}
    />
  );
}

function EnvelopePanel() {
  const { pad, patch } = usePad();
  const { powers } = useStore();
  const set = useStore((s) => s.set);
  const { a, d, s, r } = pad.env;
  const setEnv = (k: "a" | "d" | "s" | "r", v: number) => patch({ env: { ...pad.env, [k]: v } });

  const nA = toNorm(a, 0.1, 2000, true), nD = toNorm(d, 5, 4000, true), nR = toNorm(r, 5, 5000, true);
  const x1 = E.x0 + E.sa * nA;
  const x2 = x1 + E.sd * nD;
  const x3 = x2 + E.sh;
  const x4 = x3 + E.sr * nR;
  const ys = E.yz - s * (E.yz - E.yp);
  const P = (x: number, y: number) => `${(x * 100).toFixed(2)},${(y * 100).toFixed(2)}`;
  const line = `M${P(E.x0, E.yz)} L${P(x1, E.yp)} L${P(x2, ys)} L${P(x3, ys)} L${P(x4, E.yz)}`;

  return (
    <Panel
      title="AMP ENVELOPE"
      power={powers.env}
      onPower={() => set({ powers: { ...powers, env: !powers.env } })}
      dim={!powers.env}
      right={<Chip />}
    >
      <div className="inset relative h-[56px]">
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
          <defs>
            <linearGradient id="envg" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#27c6ff" stopOpacity=".5" />
              <stop offset="1" stopColor="#27c6ff" stopOpacity=".03" />
            </linearGradient>
          </defs>
          {[0.25, 0.5, 0.75].map((g) => (
            <line key={g} x1="0" x2="100" y1={g * 100} y2={g * 100} stroke="rgba(56,170,220,.12)" vectorEffect="non-scaling-stroke" />
          ))}
          <path d={`${line} L${P(x4, E.yz)} Z`} fill="url(#envg)" />
          <path d={line} fill="none" stroke="#2ec9ff" strokeWidth="1.8" vectorEffect="non-scaling-stroke" strokeLinejoin="round" style={{ filter: "drop-shadow(0 0 3px #27c6ff)" }} />
        </svg>
        <Handle x={x1} y={E.yp} label="Attack time" onMove={(px) => setEnv("a", fromNorm((px - E.x0) / E.sa, 0.1, 2000, true))} />
        <Handle
          x={x2}
          y={ys}
          vertical
          label="Decay time and sustain level"
          onMove={(px, py) => patch({ env: { ...pad.env, d: fromNorm((px - x1) / E.sd, 5, 4000, true), s: clamp((E.yz - py) / (E.yz - E.yp), 0, 1) } })}
        />
        <Handle x={x4} y={E.yz} label="Release time" onMove={(px) => setEnv("r", fromNorm((px - x3) / E.sr, 5, 5000, true))} />
      </div>
      <div className="mt-[5px] grid grid-cols-4">
        <Knob label="A" size={36} value={a} min={0.1} max={2000} log def={0.5} fmt={fmtMs} onChange={(v) => setEnv("a", v)} />
        <Knob label="D" size={36} value={d} min={5} max={4000} log def={120} fmt={fmtMs} onChange={(v) => setEnv("d", v)} />
        <Knob label="S" size={36} value={s} min={0} max={1} def={0} fmt={(v) => v.toFixed(2)} onChange={(v) => setEnv("s", v)} />
        <Knob label="R" size={36} value={r} min={5} max={5000} log def={250} fmt={fmtMs} onChange={(v) => setEnv("r", v)} />
      </div>
    </Panel>
  );
}

/* ------------------------------------------------------------ Filter */
function response(type: FilterType, fc: number, res: number, f: number) {
  const r = f / fc;
  const stages = type.endsWith("24") ? 2 : 1;
  const q = type === "bp" ? 0.5 + res * 9 : Math.pow(10, (res * 8) / 20);
  const den = Math.sqrt((1 - r * r) ** 2 + (r / q) ** 2);
  const num = type.startsWith("lp") ? 1 : type.startsWith("hp") ? r * r : r / q;
  return Math.pow(num / den, stages);
}

function FilterPanel() {
  const { pad, patch } = usePad();
  const { cutoff, res, filterType: type, filterOn } = pad;
  const dbMin = -42, dbMax = 18;
  const yOf = (g: number) => 1 - (clamp(20 * Math.log10(Math.max(g, 1e-4)), dbMin, dbMax) - dbMin) / (dbMax - dbMin);
  const pts = useMemo(() => {
    const out: string[] = [];
    for (let i = 0; i <= 90; i++) {
      const f = 20 * Math.pow(1000, i / 90);
      out.push(`${(i / 90) * 100},${(yOf(response(type, cutoff, res, f)) * 100).toFixed(2)}`);
    }
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, cutoff, res]);
  const hx = toNorm(cutoff, 20, 20000, true);
  const hy = 0.82 - res * 0.64;

  return (
    <Panel
      title="FILTER"
      power={filterOn}
      onPower={() => patch({ filterOn: !filterOn })}
      right={
        <>
          <Chip />
          <Select
            label="Filter type"
            className="w-[128px]"
            height={22}
            value={type}
            options={(Object.keys(FILTER_LABELS) as FilterType[]).map((k) => ({ value: k, label: FILTER_LABELS[k] }))}
            onChange={(v) => patch({ filterType: v })}
          />
        </>
      }
      dim={!filterOn}
    >
      <div className="flex h-full gap-3">
        <div className="flex-1">
          <div className="inset relative h-[54px]">
            <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
              <defs>
                <linearGradient id="fg" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0" stopColor="#27c6ff" stopOpacity=".5" />
                  <stop offset="1" stopColor="#27c6ff" stopOpacity=".05" />
                </linearGradient>
              </defs>
              {[0.233, 0.566, 0.9].map((g) => (
                <line key={g} x1={g * 100} x2={g * 100} y1="0" y2="100" stroke="rgba(56,170,220,.12)" vectorEffect="non-scaling-stroke" />
              ))}
              <path d={`M0,100 L${pts.join(" L")} L100,100 Z`} fill="url(#fg)" />
              <path d={`M${pts.join(" L")}`} fill="none" stroke="#2ec9ff" strokeWidth="1.8" vectorEffect="non-scaling-stroke" style={{ filter: "drop-shadow(0 0 3px #27c6ff)" }} />
            </svg>
            <Handle
              x={hx}
              y={hy}
              vertical
              label="Cutoff and resonance"
              onMove={(px, py) => patch({ cutoff: fromNorm(px, 20, 20000, true), res: Math.round(clamp((0.82 - py) / 0.64, 0, 1) * 100) / 100 })}
            />
          </div>
          <div className="relative mt-[3px] h-[10px] text-[9.5px] leading-none text-mute">
            {[
              ["20", 0],
              ["100", 0.233],
              ["1k", 0.566],
              ["10k", 0.9],
              ["20k", 1],
            ].map(([l, p]) => (
              <span key={l} className="absolute -translate-x-1/2 first:translate-x-0 last:-translate-x-full [&:nth-child(4)]:-translate-x-[80%]" style={{ left: `${(p as number) * 100}%` }}>
                {l}
              </span>
            ))}
          </div>
        </div>
        <div className="flex gap-2">
          <Knob label="Cutoff" size={38} value={cutoff} min={20} max={20000} log def={20000} fmt={fmtHz} onChange={(v) => patch({ cutoff: v })} />
          <Knob label="Resonance" size={38} value={res} min={0} max={1} def={0.2} fmt={(v) => v.toFixed(2)} onChange={(v) => patch({ res: v })} />
        </div>
      </div>
    </Panel>
  );
}

/* ------------------------------------------------------------ small panels */
function TransientPanel() {
  const { pad, patch } = usePad();
  const f = fmtSigned(2);
  return (
    <Panel title="TRANSIENT" power={pad.transOn} onPower={() => patch({ transOn: !pad.transOn })} dim={!pad.transOn} right={<Chip />}>
      <div className="flex justify-around">
        <Knob label="Attack" size={38} bipolar value={pad.attack} min={-1} max={1} def={0} fmt={f} onChange={(v) => patch({ attack: Math.round(v * 100) / 100 })} />
        <Knob label="Sustain" size={38} bipolar value={pad.sustain} min={-1} max={1} def={0} fmt={f} onChange={(v) => patch({ sustain: Math.round(v * 100) / 100 })} />
      </div>
    </Panel>
  );
}

function PitchPanel() {
  const { pad, patch } = usePad();
  return (
    <Panel title="PITCH" power={pad.pitchOn} onPower={() => patch({ pitchOn: !pad.pitchOn })} dim={!pad.pitchOn} right={<Chip />}>
      <div className="flex justify-around">
        <Knob label="Tune" size={38} bipolar value={pad.tune} min={-24} max={24} def={0} fmt={(v) => `${v > 0 ? "+" : ""}${Math.round(v)} st`} onChange={(v) => patch({ tune: Math.round(v) })} />
        <Knob label="Fine" size={38} bipolar value={pad.fine} min={-100} max={100} def={0} fmt={(v) => `${v > 0 ? "+" : ""}${Math.round(v)} ct`} onChange={(v) => patch({ fine: Math.round(v) })} />
      </div>
    </Panel>
  );
}

function PerformancePanel() {
  const { pad, patch } = usePad();
  const { powers } = useStore();
  const set = useStore((s) => s.set);
  return (
    <Panel title="PERFORMANCE" power={powers.perf} onPower={() => set({ powers: { ...powers, perf: !powers.perf } })} dim={!powers.perf} right={<Chip />}>
      <div className="flex justify-between px-1">
        <Knob label="Pan" size={38} bipolar value={pad.pan} min={-1} max={1} def={0} fmt={fmtPan} onChange={(v) => patch({ pan: Math.round(v * 100) / 100 })} />
        <Knob label="Level" size={38} value={pad.level} min={-60} max={6} def={0} fmt={fmtDb(2)} onChange={(v) => patch({ level: v })} />
        <Knob label="Send 1" size={38} value={pad.send1} min={-60} max={0} def={-12} fmt={fmtDb(1)} onChange={(v) => patch({ send1: v })} />
        <Knob label="Send 2" size={38} value={pad.send2} min={-60} max={0} def={-60} fmt={fmtDb(1)} onChange={(v) => patch({ send2: v })} />
      </div>
    </Panel>
  );
}

export function SoundTab(): ReactNode {
  return (
    <div className="flex flex-col gap-2">
      <Banner />
      <div className="grid h-[176px] grid-cols-[1fr_1.03fr_1fr] gap-2">
        <PadBank />
        <SamplePanel />
        <EnvelopePanel />
      </div>
      <div className="grid h-[112px] grid-cols-[1.55fr_1fr_0.82fr_1.4fr] gap-2">
        <FilterPanel />
        <TransientPanel />
        <PitchPanel />
        <PerformancePanel />
      </div>
    </div>
  );
}
