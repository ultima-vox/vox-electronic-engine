import { useRef, useState } from "react";
import { Heart, Pencil, Check } from "lucide-react";
import banner from "../assets/banner.jpg";
import { PRESETS, TABS, useStore } from "../store";
import { engine } from "../audio/engine";
import { fmtDb } from "../utils/math";
import { IconBtn, Knob, Next, Prev, Select, useFrame } from "./ui";

function MasterMeter() {
  const l = useRef<HTMLDivElement>(null);
  const r = useRef<HTMLDivElement>(null);
  const hold = useRef([0, 0]);
  useFrame(() => {
    const m = engine.meters();
    [l, r].forEach((ref, i) => {
      hold.current[i] = Math.max(m[i], hold.current[i] * 0.9);
      const db = 20 * Math.log10(Math.max(hold.current[i], 1e-4));
      const pct = Math.max(0, Math.min(1, (db + 48) / 48)) * 100;
      if (ref.current) ref.current.style.height = `${pct}%`;
    });
  });
  return (
    <div className="flex h-[40px] gap-[3px]" role="img" aria-label="Master output meter">
      {[l, r].map((ref, i) => (
        <div key={i} className="relative flex w-[6px] items-end overflow-hidden rounded-sm bg-[#030a11] shadow-[inset_0_1px_3px_#000]">
          <div
            ref={ref}
            className="w-full"
            style={{ background: "linear-gradient(0deg,#0f8fc2 0%,#29c4ff 60%,#d9f6ff 85%,#ffb347 100%)", height: 0 }}
          />
        </div>
      ))}
    </div>
  );
}

export function Header() {
  const { name, slot, channel, preset, favorites, masterDb } = useStore();
  const set = useStore((s) => s.set);
  const loadPreset = useStore((s) => s.loadPreset);
  const [editing, setEditing] = useState(false);

  const finish = (v: string) => {
    set({ name: v.trim() || "Drums" });
    setEditing(false);
  };

  return (
    <header className="flex h-[64px] items-center gap-3 px-1" aria-label="Instrument header">
      <div className="w-[236px] shrink-0">
        <div className="flex h-[38px] items-center gap-2">
          {editing ? (
            <input
              autoFocus
              defaultValue={name}
              maxLength={16}
              aria-label="Instrument name"
              onBlur={(e) => finish(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") finish(e.currentTarget.value);
                if (e.key === "Escape") setEditing(false);
              }}
              className="inset w-[170px] bg-transparent px-2 font-display text-[30px] font-semibold leading-none text-white outline-none focus:border-accent"
              style={{ userSelect: "text" }}
            />
          ) : (
            <h1 className="font-display text-[38px] font-semibold leading-none tracking-wide text-white" onDoubleClick={() => setEditing(true)}>
              {name}
            </h1>
          )}
          <button
            type="button"
            aria-label={editing ? "Confirm name" : "Rename instrument"}
            title={editing ? "Confirm" : "Rename (or double-click the title)"}
            className="text-accent-hi transition hover:text-white"
            onMouseDown={(e) => editing && e.preventDefault()}
            onClick={() => setEditing((e) => !e)}
          >
            {editing ? <Check size={17} /> : <Pencil size={17} />}
          </button>
        </div>
        <p className="mt-1 text-[11.5px] tracking-wide text-mute">
          Slot {slot} <span className="mx-1 opacity-50">|</span> CH{channel} <span className="mx-1 opacity-50">|</span> Rhythm Engine 1.0
        </p>
      </div>

      <div className="flex flex-1 items-center gap-2">
        <Select
          label="Preset"
          className="flex-1"
          height={34}
          value={preset}
          options={PRESETS.map((p, i) => ({ value: i, label: (favorites[i] ? "★ " : "") + p.name }))}
          onChange={loadPreset}
        />
        <Prev className="!h-[34px] w-[34px]" label="Previous preset" onClick={() => loadPreset((preset + PRESETS.length - 1) % PRESETS.length)} />
        <Next className="!h-[34px] w-[34px]" label="Next preset" onClick={() => loadPreset((preset + 1) % PRESETS.length)} />
        <IconBtn
          label={favorites[preset] ? "Remove from favourites" : "Add to favourites"}
          className="!h-[34px] w-[34px] !border-transparent !bg-none"
          onClick={() => set({ favorites: favorites.map((f, i) => (i === preset ? !f : f)) })}
        >
          <Heart size={21} className="text-accent-hi" fill={favorites[preset] ? "#27c6ff" : "none"} style={{ filter: favorites[preset] ? "drop-shadow(0 0 5px #27c6ff)" : undefined }} />
        </IconBtn>
      </div>

      <div className="flex items-center gap-2">
        <span className="text-[12px] text-mute">Channel</span>
        <Select
          label="MIDI channel"
          className="w-[92px]"
          height={34}
          value={channel}
          options={Array.from({ length: 16 }, (_, i) => ({ value: i + 1, label: `CH${i + 1}` }))}
          onChange={(v) => set({ channel: v })}
        />
      </div>

      <div className="flex items-center gap-2 border-l border-line pl-3">
        <MasterMeter />
        <Knob label="Master" value={masterDb} min={-60} max={6} def={-3} size={38} fmt={fmtDb(1)} onChange={(v) => set({ masterDb: v })} />
      </div>
    </header>
  );
}

export function Tabs() {
  const tab = useStore((s) => s.tab);
  const set = useStore((s) => s.set);
  return (
    <nav role="tablist" aria-label="Sections" className="grid h-[32px] grid-cols-7 gap-[7px]">
      {TABS.map((t) => {
        const on = tab === t.id;
        return (
          <button
            key={t.id}
            role="tab"
            aria-selected={on}
            onClick={() => set({ tab: t.id })}
            className="font-display text-[14px] font-semibold tracking-[0.1em] transition"
            style={{
              borderRadius: 5,
              border: `1px solid ${on ? "#9eefff" : "rgba(56,170,220,.4)"}`,
              color: on ? "#021019" : "#b4def0",
              background: on ? "linear-gradient(180deg,#38d0ff 0%,#0a8fd0 100%)" : "linear-gradient(180deg,#0d2437,#071622)",
              boxShadow: on ? "0 0 16px rgba(39,198,255,.6), inset 0 1px 0 rgba(255,255,255,.4)" : "inset 0 1px 0 rgba(130,225,255,.06)",
            }}
          >
            {t.label}
          </button>
        );
      })}
    </nav>
  );
}

export function Banner() {
  return (
    <div className="panel relative h-[96px] shrink-0 overflow-hidden" aria-label="Vox Drums banner">
      <img src={banner} alt="" className="absolute inset-0 h-full w-full object-cover object-[50%_45%] opacity-90" draggable={false} />
      <div className="absolute inset-0" style={{ background: "linear-gradient(90deg,rgba(2,8,16,.96) 0%,rgba(2,8,16,.55) 24%,rgba(2,8,16,0) 42%,rgba(2,8,16,0) 62%,rgba(2,8,16,.6) 80%,rgba(2,8,16,.95) 100%)" }} />
      <div className="absolute left-5 top-1/2 -translate-y-1/2">
        <div className="font-display text-[40px] font-medium leading-none tracking-[0.12em] text-accent-hi glow-text">
          VOX <span className="text-white">DRUMS</span>
        </div>
        <div className="mt-2 text-[8.5px] leading-[1.5] tracking-[0.22em] text-mute">
          RHYTHM BUILDS WORLDS
          <br />
          PERCUSSION DRIVES EMOTION
        </div>
      </div>
      <div className="absolute right-5 top-1/2 -translate-y-1/2 text-[9px] leading-[1.55] tracking-[0.22em] text-accent-hi/90">
        <div className="mb-2 text-[10px] text-txt">
          DEEP.
          <br />
          PUNCHY.
          <br />
          RHYTHMIC.
        </div>
        <div className="text-[8.5px] text-mute">
          ELECTRONIC DRUMS
          <br />
          FOR MODERN CREATORS.
        </div>
      </div>
    </div>
  );
}

export function StatusBar() {
  const hint = useStore((s) => s.hint);
  const bpm = useStore((s) => s.bpm);
  const vox = useRef<HTMLSpanElement>(null);
  const aud = useRef<HTMLSpanElement>(null);
  useFrame(() => {
    if (vox.current) vox.current.textContent = String(engine.activeVoices).padStart(2, "0");
    if (aud.current) aud.current.textContent = engine.ctx ? (engine.ctx.state === "running" ? "Audio ready" : "Audio suspended") : "Click any pad to enable audio";
  });
  return (
    <footer className="flex h-[18px] items-center justify-between px-1 text-[10.5px] text-mute" aria-live="polite">
      <span className="truncate">{hint || "Hover a control for details  ·  Keys A S D F / Z X C V play the pads  ·  Space = play / stop  ·  Ctrl+Z = undo"}</span>
      <span className="ml-3 flex shrink-0 gap-4 tabular-nums">
        <span ref={aud} />
        <span>
          Voices <span ref={vox} className="text-accent-hi" />
        </span>
        <span>{bpm} BPM</span>
        <span className="text-accent-hi">VOX DRUMS v1.0</span>
      </span>
    </footer>
  );
}
