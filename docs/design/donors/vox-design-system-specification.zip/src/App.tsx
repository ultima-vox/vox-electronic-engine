import { useEffect, useState } from "react";
import { productAccents } from "./data";
import { useStored } from "./lib/util";
import { cn } from "./utils/cn";
import Overview from "./sections/Overview";
import Tokens from "./sections/Tokens";
import Showcase from "./sections/Showcase";
import Registry from "./sections/Registry";
import Drums from "./sections/Drums";
import Fx from "./sections/Fx";
import Binding from "./sections/Binding";
import Plan from "./sections/Plan";

const NAV = [
  { id: "overview", label: "Обзор", no: "00" },
  { id: "tokens", label: "Токены", no: "01" },
  { id: "showcase", label: "Showcase", no: "02" },
  { id: "registry", label: "Реестр и гейт", no: "03" },
  { id: "drums", label: "VOX Drums", no: "04" },
  { id: "fx", label: "VOX FX", no: "05" },
  { id: "binding", label: "Binding matrix", no: "06" },
  { id: "plan", label: "План и релиз", no: "07" },
] as const;

type Id = (typeof NAV)[number]["id"];
const fromHash = (): Id => {
  const h = window.location.hash.replace("#", "");
  return (NAV.find((n) => n.id === h)?.id ?? "overview") as Id;
};

export default function App() {
  const [page, setPage] = useState<Id>(fromHash);
  const [product, setProduct] = useStored<(typeof productAccents)[number]["key"]>("vox.product.v1", "drums");
  const accent = productAccents.find((p) => p.key === product) ?? productAccents[0];

  const go = (id: string) => {
    setPage(id as Id);
    window.location.hash = id;
    window.scrollTo({ top: 0 });
  };

  useEffect(() => {
    const on = () => setPage(fromHash());
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);

  return (
    <div className="min-h-screen bg-vox-bg text-vox-text" style={{ ["--product" as string]: accent.hex }}>
      <header className="sticky top-0 z-30 flex flex-wrap items-center gap-x-5 gap-y-2 border-b border-vox-border bg-vox-panel/95 px-4 py-2.5 backdrop-blur">
        <div className="flex items-center gap-3">
          <div
            aria-hidden
            className="flex h-8 w-8 items-center justify-center rounded-[6px] border border-vox-edge bg-vox-raised font-mono text-[13px] font-bold text-[var(--product)]"
          >
            V
          </div>
          <div className="leading-tight">
            <div className="engrave text-[14px] font-semibold tracking-[0.18em]">VOX MUSIC</div>
            <div className="font-mono text-[10px] text-vox-sub">DESIGN SYSTEM 1.0 · DOC 18.11.2026</div>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-2" role="group" aria-label="Идентичность продукта">
          <span className="hidden text-[11px] text-vox-sub sm:inline">Accent продукта</span>
          {productAccents.map((p) => (
            <button
              key={p.key}
              aria-pressed={product === p.key}
              onClick={() => setProduct(p.key)}
              className={cn(
                "flex min-h-8 items-center gap-2 rounded-[6px] border px-2.5 text-[12px] font-medium transition-colors duration-[80ms]",
                product === p.key ? "bg-vox-raised text-vox-text" : "border-vox-border text-vox-sub hover:bg-vox-raised",
              )}
              style={product === p.key ? { borderColor: p.hex } : undefined}
            >
              <span className="h-2.5 w-2.5 rounded-full" style={{ background: p.hex }} aria-hidden />
              {p.name.replace("VOX ", "")}
            </button>
          ))}
        </div>
      </header>

      <div className="mx-auto flex max-w-[1500px] flex-col lg:flex-row">
        <nav aria-label="Разделы" className="shrink-0 border-b border-vox-border lg:sticky lg:top-[53px] lg:h-[calc(100vh-53px)] lg:w-52 lg:border-b-0 lg:border-r">
          <ul className="flex gap-1 overflow-x-auto p-2 lg:flex-col lg:p-3">
            {NAV.map((n) => (
              <li key={n.id}>
                <button
                  onClick={() => go(n.id)}
                  aria-current={page === n.id ? "page" : undefined}
                  className={cn(
                    "flex min-h-10 w-full items-center gap-2.5 whitespace-nowrap rounded-[6px] border-l-2 px-3 text-left text-[13px] transition-colors duration-[80ms]",
                    page === n.id ? "border-[var(--product)] bg-vox-raised font-semibold text-vox-text" : "border-transparent text-vox-sub hover:bg-vox-panel hover:text-vox-text",
                  )}
                >
                  <span className="font-mono text-[10px] text-[var(--product)]">{n.no}</span>
                  {n.label}
                </button>
              </li>
            ))}
          </ul>
          <div className="hidden p-4 text-[11px] leading-relaxed text-vox-sub lg:block">
            <div className="rounded-[6px] border border-dashed border-vox-edge p-3">
              Веб-эталон поведения и документ ТЗ. Целевой стек: C++20 · JUCE 9.0.1 · VST3 · Windows x64.
            </div>
          </div>
        </nav>

        <main className="min-w-0 flex-1 p-4 md:p-6 lg:p-8">
          {page === "overview" && <Overview go={go} />}
          {page === "tokens" && <Tokens />}
          {page === "showcase" && <Showcase />}
          {page === "registry" && <Registry />}
          {page === "drums" && <Drums />}
          {page === "fx" && <Fx />}
          {page === "binding" && <Binding />}
          {page === "plan" && <Plan />}
          <footer className="mt-10 border-t border-vox-border pt-4 text-[11px] text-vox-sub">
            Статус: предлагаемое ТЗ, не отчёт о выполненной работе. Ничего не отмечено PASS без исполненного теста. Изображения и mockup — только по отдельной команде владельца «нарисуй».
          </footer>
        </main>
      </div>
    </div>
  );
}
