import { useCallback, useEffect, useRef, useState } from "react";

export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

function chan(c: number) {
  const s = c / 255;
  return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
}
export function relLum(hex: string) {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return 0.2126 * chan(r) + 0.7152 * chan(g) + 0.0722 * chan(b);
}
export function contrast(a: string, b: string) {
  const la = relLum(a);
  const lb = relLum(b);
  const [hi, lo] = la > lb ? [la, lb] : [lb, la];
  return (hi + 0.05) / (lo + 0.05);
}

export function useStored<T>(key: string, init: T): [T, (v: T | ((p: T) => T)) => void] {
  const [val, setVal] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : init;
    } catch {
      return init;
    }
  });
  const set = useCallback(
    (v: T | ((p: T) => T)) => {
      setVal((prev) => {
        const next = typeof v === "function" ? (v as (p: T) => T)(prev) : v;
        try {
          localStorage.setItem(key, JSON.stringify(next));
        } catch {
          /* storage недоступен — работаем в памяти */
        }
        return next;
      });
    },
    [key],
  );
  return [val, set];
}

export interface Telemetry {
  l: number;
  r: number;
  seq: number;
}

/**
 * ДЕМО-источник телеметрии: синтетический сигнал, публикуемый как неизменяемый
 * snapshot с частотой hz. Метры двигаются по snapshot, а не по анимационному таймеру.
 */
export function useDemoTelemetry(active: boolean, offsetDb: number, hz = 25): Telemetry | null {
  const [snap, setSnap] = useState<Telemetry | null>(null);
  const off = useRef(offsetDb);
  off.current = offsetDb;
  useEffect(() => {
    if (!active) {
      setSnap(null);
      return;
    }
    let t = 0;
    let seq = 0;
    const id = window.setInterval(() => {
      t += 1 / hz;
      const body = -15 + 6 * Math.sin(t * 2.1) + 4 * Math.sin(t * 5.3);
      const kick = Math.max(0, Math.sin(t * Math.PI * 2 * 2)) ** 6 * 9;
      const l = body + kick + (Math.random() - 0.5) * 3 + off.current;
      const r = body + kick * 0.9 + (Math.random() - 0.5) * 3 + off.current;
      seq += 1;
      setSnap({ l, r, seq });
    }, 1000 / hz);
    return () => window.clearInterval(id);
  }, [active, hz]);
  return snap;
}
