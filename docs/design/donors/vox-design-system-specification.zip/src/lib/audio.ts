// Мини-синтез только для прослушивания эталонных контролов (Web Audio, по жесту пользователя).
let ctx: AudioContext | null = null;
export const audioState = { enabled: true };

function getCtx(): AudioContext | null {
  if (!audioState.enabled) return null;
  try {
    if (!ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
    }
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

export const midiToFreq = (n: number) => 440 * Math.pow(2, (n - 69) / 12);

/** Удерживаемая нота. Возвращает функцию release. */
export function startNote(note: number, velocity: number): () => void {
  const c = getCtx();
  if (!c) return () => {};
  const o = c.createOscillator();
  const o2 = c.createOscillator();
  const g = c.createGain();
  const lp = c.createBiquadFilter();
  o.type = "sawtooth";
  o2.type = "square";
  o.frequency.value = midiToFreq(note);
  o2.frequency.value = midiToFreq(note) * 1.004;
  lp.type = "lowpass";
  lp.frequency.value = 1800;
  const peak = 0.12 * (velocity / 127);
  g.gain.setValueAtTime(0, c.currentTime);
  g.gain.linearRampToValueAtTime(peak, c.currentTime + 0.01);
  o.connect(lp);
  o2.connect(lp);
  lp.connect(g).connect(c.destination);
  o.start();
  o2.start();
  let done = false;
  return () => {
    if (done) return;
    done = true;
    const t = c.currentTime;
    g.gain.cancelScheduledValues(t);
    g.gain.setValueAtTime(g.gain.value, t);
    g.gain.linearRampToValueAtTime(0, t + 0.12);
    o.stop(t + 0.15);
    o2.stop(t + 0.15);
  };
}

export function drumHit(pad: number, velocity: number) {
  const c = getCtx();
  if (!c) return;
  const t = c.currentTime;
  const amp = 0.5 * (velocity / 127);
  const kind = pad % 4;
  const g = c.createGain();
  g.connect(c.destination);
  if (kind === 0 || kind === 3) {
    const o = c.createOscillator();
    o.type = "sine";
    const f = kind === 0 ? 120 : 200 + pad * 6;
    o.frequency.setValueAtTime(f, t);
    o.frequency.exponentialRampToValueAtTime(f * 0.35, t + 0.18);
    g.gain.setValueAtTime(amp, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
    o.connect(g);
    o.start(t);
    o.stop(t + 0.3);
  } else {
    const len = Math.floor(c.sampleRate * 0.2);
    const buf = c.createBuffer(1, len, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    const src = c.createBufferSource();
    src.buffer = buf;
    const f = c.createBiquadFilter();
    f.type = "highpass";
    f.frequency.value = kind === 1 ? 1200 : 6500;
    g.gain.setValueAtTime(amp * 0.7, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + (kind === 1 ? 0.16 : 0.07));
    src.connect(f).connect(g);
    src.start(t);
  }
}
