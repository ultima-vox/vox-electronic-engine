export type CompStatus = "Concept" | "Prototype" | "Implemented" | "Production" | "Deferred";

export const principles = [
  ["Музыкальная задача прежде экрана", "Одно действие — понятный эффект, связанные контролы рядом, минимум переключений."],
  ["Контрол = реальная цель", "Каждый контрол привязан к параметру, действию или диагностике. Нет нарисованных фейдеров, спектров, клавиш и VU без данных."],
  ["Одно значение — одна истина", "UI не дублирует DSP state, host automation, selection и meter ownership."],
  ["Интенсивность ≠ клиппинг", "Parameter value, MIDI velocity, DSP peak и post-host clipping — разные данные и разные индикаторы."],
  ["Клавиатура и видимый фокус", "Все существенные операции доступны с клавиатуры; цвет никогда не единственный признак."],
  ["Без промежуточных UI-релизов", "Автопроверка в процессе, одна финальная ручная DAW-проверка владельца на полной сборке."],
];

export const priority = [
  "Актуальное явное решение владельца",
  "Утверждённая спецификация продукта и issue #127",
  "Действующие контракты идентичности / состояния / DSP",
  "Этот дизайн-системный контракт",
  "Исторические DS-0 документы и образцы",
  "Предпочтение разработчика",
];

export const colorTokens = [
  { name: "background", hex: "#06121D", role: "основа редактора" },
  { name: "panel", hex: "#0B1925", role: "рабочие секции" },
  { name: "panelRaised", hex: "#102230", role: "активная / поднятая поверхность" },
  { name: "graph", hex: "#051019", role: "аудиоредактор / временная шкала" },
  { name: "border", hex: "#1D3B50", role: "структура и разделение" },
  { name: "accent", hex: "#00DDF5", role: "семантический акцент / focus" },
  { name: "text", hex: "#E9F3FA", role: "основной текст" },
  { name: "textSecondary", hex: "#9AB2C5", role: "вторичный текст" },
  { name: "warning", hex: "#E3B341", role: "предупреждение" },
  { name: "danger", hex: "#E4425D", role: "реальная ошибка / перегрузка" },
];

/** Предложения, не входящие в исходную таблицу ТЗ. */
export const proposedTokens = [
  { name: "edgeStrong", hex: "#4F7A96", role: "граница интерактивного контрола (≥3:1 к panel)" },
  { name: "automated", hex: "#3DDC97", role: "состояние Automated / подтверждённый OK" },
  { name: "modulated", hex: "#7AA2FF", role: "внешнее кольцо модуляции" },
];

export const productAccents = [
  { key: "drums", name: "VOX Drums", hex: "#EF805D", tag: "copper / coral" },
  { key: "fx", name: "VOX FX", hex: "#16CDBA", tag: "aqua" },
  { key: "synth", name: "VOX Synth", hex: "#9668F2", tag: "electric violet" },
] as const;

export const spacing = [4, 8, 12, 16, 20, 24, 32];
export const radii = [4, 6, 8];
export const strokes = [1, 1.5, 2];
export const icons = [16, 20, 24];
export const knobSizes = [
  { px: 36, name: "compact" },
  { px: 48, name: "normal" },
  { px: 64, name: "large" },
];
export const typeScale = [
  { name: "instrument title", px: 26, w: 600 },
  { name: "section", px: 14, w: 600 },
  { name: "label", px: 12, w: 500 },
  { name: "value", px: 14, w: 500 },
  { name: "value (compact, min)", px: 11, w: 500 },
];
export const motion = [
  { ms: 80, use: "hover / press" },
  { ms: 140, use: "смена состояния" },
  { ms: 220, use: "панели / popover" },
];

export const states = [
  "Normal", "Hover", "Pressed", "Focused", "Selected", "Active", "Disabled", "ReadOnly", "Unavailable",
  "Warning", "Error", "Automated", "Modulated", "Bypassed", "Dirty", "Dragging", "DropValid", "DropInvalid",
] as const;

export const units = ["Hz / kHz", "ms / s", "dB", "%", "semitones (± st)", "BPM", "steps / bars", "pan L / R"];

export const ownership = [
  ["AudioProcessor", "DSP, host parameters", "audio / host", "Никаких обратных владений"],
  ["Product controller", "Структурные документы, Undo, workspace layout", "message thread", "Валидация до handoff"],
  ["JUCE message thread", "Components, file dialogs", "message thread", "paint() ничего не вычисляет"],
  ["Audio thread", "Подготовленный DSP snapshot", "audio", "Без lock / alloc / I/O"],
  ["Telemetry coordinator", "takePadMeter / takeMainMeter / takeHitMask — раз за тик", "message thread 20–30 Hz", "Immutable snapshots → widgets"],
];

export const contracts = [
  ["ParameterBinding", "штатный juce::ParameterAttachment + host gesture begin/end"],
  ["DisplayValue / Unit", "формат и парсинг единиц, строгая валидация"],
  ["ControlState", "18 первичных состояний, Disabled ≠ ReadOnly ≠ Unavailable"],
  ["TelemetrySnapshot", "POD, bounded, stale / no-data"],
  ["SelectionContext", "один выбранный pad / step / bar, follow / pin"],
  ["ValidatedEdit / Undo", "одна Undo-группа на завершённый drag, Escape = revert"],
];

export interface RegRow {
  name: string;
  family: string;
  status: CompStatus;
  consumers: string;
  evidence: string;
  demo?: boolean;
}

const E_EXIST = "В публичном VoxComponents.h (§0); аудит DS-00 не выполнен — Production не присваивается";
const E_NONE = "В публичном списке libs/vox-ui не найден (§0)";

export const registry: RegRow[] = [
  { name: "VoxPanel", family: "layout", status: "Implemented", consumers: "все", evidence: E_EXIST },
  { name: "VoxSectionHeader", family: "layout", status: "Implemented", consumers: "все", evidence: E_EXIST },
  { name: "VoxTabBar", family: "navigation", status: "Implemented", consumers: "все", evidence: E_EXIST },
  { name: "VoxKnob", family: "input", status: "Implemented", consumers: "все продукты", evidence: E_EXIST, demo: true },
  { name: "VoxEncoder", family: "input", status: "Concept", consumers: "все", evidence: E_NONE },
  { name: "VoxButton", family: "input", status: "Implemented", consumers: "все", evidence: E_EXIST },
  { name: "VoxComboBox", family: "input", status: "Implemented", consumers: "все", evidence: E_EXIST },
  { name: "VoxFader / VoxLinearSlider", family: "input", status: "Concept", consumers: "Drums Mixer, FX outputs, Synth Mix", evidence: E_NONE + "; в Drums только knobs в MixerPage", demo: true },
  { name: "VoxPad / VoxPadGrid", family: "performance", status: "Concept", consumers: "Drums (+ FX trigger-pad при реальном использовании)", evidence: "Есть 4×4 PadButton в DrumsEditor.cpp — продуктовый примитив, не общая библиотека", demo: true },
  { name: "VoxKeyboard", family: "performance", status: "Concept", consumers: "Synth; FX trigger / pitch preview", evidence: E_NONE, demo: true },
  { name: "VoxToggle / VoxSwitch / VoxIconButton / VoxSegmented", family: "input", status: "Concept", consumers: "все", evidence: E_NONE },
  { name: "VoxValueField / VoxNumericInput / VoxSearchField", family: "input", status: "Concept", consumers: "все", evidence: E_NONE },
  { name: "VoxMeter / VoxPeakMeter / VoxStatusIndicator", family: "feedback", status: "Concept", consumers: "все", evidence: "Измерители в DrumsPages.cpp — доноры, не общий компонент", demo: true },
  { name: "VoxGraph / VoxEnvelopeEditor / VoxCurveEditor", family: "graph", status: "Concept", consumers: "FX timeline, Drums envelopes, Synth mod", evidence: "FX: CurveEditor только для gain (прототип продукта)", demo: true },
  { name: "VoxWaveform / VoxSampleRange", family: "graph", status: "Concept", consumers: "Drums, FX granular, Synth sampler", evidence: E_NONE },
  { name: "VoxXYPad", family: "graph", status: "Concept", consumers: "FX, Synth", evidence: E_NONE, demo: true },
  { name: "VoxModRing / VoxModMatrixView", family: "graph", status: "Concept", consumers: "FX, Synth", evidence: "FX Modulation.h — автономные примитивы, не подключены к UI" },
  { name: "VoxStepGrid / VoxTimeline / VoxPianoRoll", family: "timeline", status: "Concept", consumers: "Drums, FX, Synth", evidence: "PatternEditor в Drums — продуктовый; PianoRoll — Deferred до потребителя", demo: true },
  { name: "VoxDockWorkspace / VoxSplitter / VoxPanelHeader", family: "layout", status: "Concept", consumers: "Drums", evidence: "DrumsEditor.cpp — 8 страниц tabs_/pages_[0..7]" },
  { name: "VoxPresetBrowser / VoxFileStatus / VoxDropTarget", family: "navigation", status: "Concept", consumers: "Drums, FX, Synth", evidence: E_NONE },
  { name: "VoxPopover / VoxDialog / VoxTooltip / VoxToast / VoxBanner", family: "feedback", status: "Concept", consumers: "все", evidence: E_NONE },
  { name: "VoxLevelStrip / VoxRoutingIndicator", family: "performance", status: "Concept", consumers: "Drums; FX Process routing", evidence: E_NONE },
  { name: "VoxPianoRoll", family: "timeline", status: "Deferred", consumers: "Synth (нет утверждённого потребителя)", evidence: "Не создавать без продуктового потребителя (§4)" },
];

export interface Gap {
  id: string;
  p: 1 | 2;
  title: string;
  found: string;
  deliver: string;
}

export const drumsGaps: Gap[] = [
  { id: "DR-UI-01", p: 1, title: "Dock workspace #127", found: "DrumsEditor.cpp: восемь страниц tabs_/pages_[0..7]", deliver: "Side / center / bottom зоны; named layouts, restore, focus и splitter tests" },
  { id: "DR-UI-02", p: 1, title: "SELECT ≠ AUDITION", found: "PadButton::onClick вызывает selectPad и audition(pad,110) одновременно", deliver: "Раздельные действия и MIDI ownership; нет случайных hit-triggers" },
  { id: "DR-UI-03", p: 1, title: "Hardware Pad Rack 4×4 + List16", found: "4×4 PadButton есть; единого dock/list с selection-контрактом нет", deliver: "16 равных rubber pads + List, note/status/missing/mute/solo, keyboard" },
  { id: "DR-UI-04", p: 1, title: "Bottom 16-strip Mixer, вертикальные faders", found: "MixerPage: реальные knobs/peak; drm.kit.volume подписан как Main", deliver: "Единственный bottom dock; kit fader = «Kit Level / All outputs»" },
  { id: "DR-UI-05", p: 1, title: "Истинная telemetry velocity / peak / over", found: "takeHitMask() — биты; takePadMeter/takeMainMeter через exchange(0); velocity и per-bus over нет", deliver: "Один UI telemetry coordinator + минимальное расширение telemetry, точные tap points" },
  { id: "DR-UI-06", p: 1, title: "Inspector follow / pin", found: "В 8-страничном UI нет Inspector с per-object pin", deliver: "Один выбранный pad/step/bar, sync при automation, recovery невалидного pin" },
  { id: "DR-UI-07", p: 1, title: "Song: Source vs This Bar", found: "Song engine/Strip и per-bar editors существуют", deliver: "2 edit scopes; copy-on-first-real-edit; Undo восстанавливает linkage" },
  { id: "DR-UI-08", p: 1, title: "Step parameter lanes под одной линейкой", found: "PatternEditor есть, #127 layout не реализован", deliver: "Velocity/Probability/Ratchet/Microtiming + multi-select/zoom/undo" },
  { id: "DR-UI-09", p: 1, title: "Full Sound + Sample Editor", found: "Прототипы Sound/Sample в DrumsEditor", deliver: "Synth/Sample/Layer flow, waveform trim, только реальные параметры (нет ADSR без поддержки)" },
  { id: "DR-UI-10", p: 1, title: "Dockable Generator, 23 styles", found: "makeGeneratePage и реестр 23 стилей есть", deliver: "8 реальных параметров, seed/locks/undo/context, без fake actions" },
  { id: "DR-UI-11", p: 1, title: "Routing и MIDI transfer", found: "Routing page и Pattern/Song MIDI export есть", deliver: "Честные active-bus/fallback; drag editable MIDI в Cubase/REAPER; no fake insert-to-track" },
  { id: "DR-UI-12", p: 1, title: "Workspace save/reset, resize/DPI", found: "Старый DUIS page-based UiState", deliver: "Единая layout schema (#127/§14 #130), 4 workspace defaults, keyboard nav" },
  { id: "DR-UI-13", p: 1, title: "Release factory content", found: "FACTORY_CONTENT.md: electronic — listening pending; Rock/Metal NOT RELEASE-READY", deliver: "Прослушивание + лицензированные сэмплы либо честное исключение паков" },
  { id: "DR-UI-14", p: 1, title: "Windows candidate acceptance", found: "#141 и #153 — Draft/HOLD", deliver: "Exact-head suite/build/validator/RT/states/multibus; один pass владельца в Cubase/REAPER" },
  { id: "DR-UI-15", p: 2, title: "Notes / roles mapping в UI", found: "Pad role mapping и kits есть в engine/state", deliver: "Label + note + semantic role/genre на реальных данных (4×4 и List)" },
  { id: "DR-UI-16", p: 2, title: "Accessibility / empty / error", found: "Текущие компоненты не доказывают gate #127", deliver: "Tab/focus, missing sample, invalid output, no data, warnings, keyboard editing tests" },
];

export const fxGaps: Gap[] = [
  { id: "FX-UI-01", p: 1, title: "Workspace / navigation", found: "Один interim FxPanel: knob/family/seed, layer cards, FX types", deliver: "PERFORM/DESIGN/TIMELINE/MOTION/PROCESS/TRIGGER/PRESETS/ADVANCED + control map" },
  { id: "FX-UI-02", p: 1, title: "20 curves, реальное редактирование", found: "CurveEditor для gain и частичные layer settings", deliver: "4 кривые на слой + 4 глобальных, snap/units/undo, headless-эквивалент DSP" },
  { id: "FX-UI-03", p: 1, title: "2 osc + 2 filters на слой", found: "12 предварительных family-рецептов в NoiseRiser.h", deliver: "Per-family controls + согласие с DSP, не generic control со сменным смыслом" },
  { id: "FX-UI-04", p: 1, title: "Typed modulation", found: "Modulation.h — автономные примитивы, не подключены к Program/UI", deliver: "64 routes, 2 LFO / S&H / ADSR, overlays, детерминированный state + tests" },
  { id: "FX-UI-05", p: 1, title: "8 automatable macros", found: "Macro/controller/visual mapping отсутствует", deliver: "8 стабильных ID, mappings, base/automation policy, Program recall" },
  { id: "FX-UI-06", p: 1, title: "Complete FX chain", found: "4 слота и часть типов есть; delay/reverb/phaser/flanger/chorus и tails не завершены", deliver: "Все типы, true bypass, wet/dry, type-specific controls, quality/tails" },
  { id: "FX-UI-07", p: 1, title: "Factory generator", found: "Generate/Mutate задействованы; 48 uncurated seeds, 12 test patterns", deliver: "Seed + 4-layer program + locks / A-B + curated browser" },
  { id: "FX-UI-08", p: 1, title: "Host-sync trigger grid", found: "Pattern.h — SMF bytes offline; runtime host-sync и UI нет", deliver: "Real-time scheduler: start/seek/tempo/loop, parity с MIDI export, grid edit" },
  { id: "FX-UI-09", p: 1, title: "WAV/MIDI workflows", found: "Worker-only OfflineRender.h / MIDI bytes; file/drag UX нет", deliver: "Export dialog/drag, progress/cancel, точность и tails, import tests" },
  { id: "FX-UI-10", p: 1, title: "User sample / granular lifecycle", found: "Built-in procedural sample и 64-grain pool", deliver: "Decode worker, safe ownership, hash/relocation/missing diagnostics + waveform" },
  { id: "FX-UI-11", p: 1, title: "Musical sound / Program correctness", found: "12 family — предварительные реализации", deliver: "Aural, spectral, alias, level и bounded perf по семействам и sample rates" },
  { id: "FX-UI-12", p: 1, title: "Full host validation", found: "Exact-head Windows qualification не подтверждена; прежние SEGFAULT на старых heads", deliver: "Exact HEAD MSVC, suite/validator, memory/RT, DAW acceptance" },
  { id: "FX-UI-13", p: 2, title: "Keyboard / performance feedback", found: "MIDI note triggers есть; общей клавиатуры нет", deliver: "VoxKeyboard: корректные note/panic/velocity и one-shot policy" },
  { id: "FX-UI-14", p: 2, title: "Accessibility + responsive", found: "Interim fixed layout, базовые bindings", deliver: "1040×700 fallback, 125/150/200% DPI, focus/labels/numeric values" },
  { id: "FX-UI-15", p: 2, title: "Accurate diagnostics", found: "Output peak есть; профилирования нет", deliver: "event/grain/clip/quality/source telemetry, без fake CPU/RMS" },
];

export const fxWorkspaces = [
  ["PERFORM", "Program/category/style browser, Generate/Mutate/A–B, lock/seed, 8 macros, stereo output, trigger keyboard, event count/time/peak"],
  ["DESIGN", "4 layer cards: enable/solo, family, pitch/gain/pan/width/timing, 4 curves, family-specific controls"],
  ["TIMELINE", "seconds/bars, ruler, 20 curves × 2–16 points, snap/shape/zoom, multi-select, undo/redo, preview"],
  ["MOTION", "2 LFO, envelope, S&H, ADSR, follower, 64-route typed matrix, 8 macros, base vs evaluated"],
  ["PROCESS", "4 effect slots: algorithm, bypass, wet/dry, amount, type controls, latency/tail"],
  ["TRIGGER", "1–4 bars, 1/4–1/32/triplet, velocity/probability/ratchet, internal vs host timing, MIDI export"],
  ["PRESETS", "Factory/User ≥48 programs, ≥12 patterns, search/favorites/compare, portable samples, A/B"],
  ["ADVANCED", "event/grain count, CPU/memory/tail/clipping, quality, VST3 identity, diagnostics"],
];

export const drumsDonors = [
  ["Quick-параметры страниц", "Inspector (follow / pin)", "DR-UI-06"],
  ["makeGeneratePage, 23 стиля", "Side dock: Generator", "DR-UI-10"],
  ["MixerPage (knobs, peak)", "Bottom dock: Mixer (16 strips, faders)", "DR-UI-04"],
  ["Routing page", "Side dock: Routing", "DR-UI-11"],
  ["PatternEditor", "Center: Step Sequencer + lanes", "DR-UI-08"],
  ["Song engine / Strip / per-bar editors", "Center: Song Arranger", "DR-UI-07"],
  ["Прототипы Sound / Sample", "Center: Full Sound / Sample Editor", "DR-UI-09"],
  ["Presets / kits / FACTORY_CONTENT", "Side dock: Library", "DR-UI-13"],
  ["Диагностика / peak", "Side dock: Diagnostics", "DR-UI-05"],
];

export const bindingCols = [
  "product", "workspace", "panel", "control", "actual_source_path", "parameterID_or_controller_method",
  "value_domain", "unit", "default", "automation", "structural_state", "telemetry_source",
  "gesture", "reset", "undo", "status", "test_case",
] as const;

const T = "TBD-AUDIT";
type BRow = Record<(typeof bindingCols)[number], string>;
function b(p: Partial<BRow>): BRow {
  const r = {} as BRow;
  bindingCols.forEach((c) => (r[c] = p[c] ?? T));
  return r;
}

/** ID не выдумываются: всё, что не подтверждено ТЗ, помечено TBD-AUDIT. */
export const bindingRows: BRow[] = [
  b({ product: "drums", workspace: "Mixing", panel: "Bottom Mixer", control: "Kit Level fader", actual_source_path: "products/drums/DrumsPages.cpp (MixerPage)", parameterID_or_controller_method: "drm.kit.volume", unit: "dB (представление)", automation: "host", status: "Gap: подпись «Main» → «Kit Level / All outputs»", test_case: "DR-UI-04" }),
  b({ product: "drums", workspace: "Beatmaking", panel: "Pad Rack", control: "Pad SELECT", actual_source_path: "products/drums/DrumsEditor.cpp (PadButton::onClick)", parameterID_or_controller_method: "selectPad(pad)", value_domain: "pad 0..15", automation: "нет", structural_state: "SelectionContext", gesture: "click / Arrow", status: "Gap: слит с audition", test_case: "DR-UI-02" }),
  b({ product: "drums", workspace: "Beatmaking", panel: "Pad Rack", control: "Pad AUDITION", actual_source_path: "products/drums/DrumsEditor.cpp (PadButton::onClick)", parameterID_or_controller_method: "audition(pad, 110)", value_domain: "velocity 1..127", default: "110 (фикс.)", automation: "нет", gesture: "click / Enter / Space", status: "Gap: velocity policy не определена", test_case: "DR-UI-02" }),
  b({ product: "drums", workspace: "все", panel: "Telemetry coordinator", control: "Pad hit flash", parameterID_or_controller_method: "takeHitMask()", value_domain: "bitmask 16", telemetry_source: "takeHitMask()", status: "Gap: нет velocity", test_case: "DR-UI-05" }),
  b({ product: "drums", workspace: "Mixing", panel: "Level Strip", control: "Pad peak meter", parameterID_or_controller_method: "takePadMeter()", unit: "dBFS", telemetry_source: "takePadMeter() (exchange(0))", status: "Implemented в продукте; единый coordinator требуется", test_case: "DR-UI-05" }),
  b({ product: "drums", workspace: "Mixing", panel: "Bottom Mixer", control: "Main peak meter", parameterID_or_controller_method: "takeMainMeter()", unit: "dBFS", telemetry_source: "takeMainMeter() (exchange(0))", status: "Gap: per-bus over отсутствует", test_case: "DR-UI-05" }),
  b({ product: "drums", workspace: "Beatmaking", panel: "Generator", control: "Style selector (23)", actual_source_path: "makeGeneratePage + registry (integration)", structural_state: "pattern", status: "Donor: перенос в dock", test_case: "DR-UI-10" }),
  b({ product: "drums", workspace: "Beatmaking", panel: "Generator", control: "8 generator parameters", actual_source_path: "makeGeneratePage", gesture: "drag / numeric", undo: "требуется", status: "Donor: ID подтвердить аудитом", test_case: "DR-UI-10" }),
  b({ product: "drums", workspace: "Composition", panel: "Song Arranger", control: "Edit scope (Source / This Bar)", structural_state: "Song 16/32/64", undo: "linkage restore", status: "Gap", test_case: "DR-UI-07" }),
  b({ product: "drums", workspace: "Mixing", panel: "Routing", control: "Output Main / Out2–9", actual_source_path: "Routing page", structural_state: "pad output", status: "Donor: честный fallback disabled bus", test_case: "DR-UI-11" }),
  b({ product: "drums", workspace: "Composition", panel: "Song / Pattern", control: "MIDI drag export", actual_source_path: "Pattern/Song MIDI export code", status: "Donor: drag UX проверить", test_case: "DR-UI-11" }),
  b({ product: "drums", workspace: "все", panel: "Dock", control: "Named layout (4 presets)", structural_state: "layout schema (UI-only, versioned)", undo: "нет (UI-only)", status: "Gap", test_case: "DR-UI-12" }),
  b({ product: "fx", workspace: "PERFORM", panel: "Program", control: "Generate / Mutate", actual_source_path: "products/fx (FxPanel)", structural_state: "Program", status: "Implemented частично (FX #156)", test_case: "FX-UI-07" }),
  b({ product: "fx", workspace: "PERFORM", panel: "Program", control: "Seed", actual_source_path: "products/fx (FxPanel)", structural_state: "Program seed", status: "Implemented частично", test_case: "FX-UI-07" }),
  b({ product: "fx", workspace: "DESIGN", panel: "Layer A–D", control: "Family selector (12)", actual_source_path: "NoiseRiser.h", structural_state: "Program layer", status: "Preliminary DSP", test_case: "FX-UI-03" }),
  b({ product: "fx", workspace: "TIMELINE", panel: "Curves", control: "Gain CurveEditor", actual_source_path: "products/fx (CurveEditor)", value_domain: "2–16 nodes", structural_state: "Program curves", undo: "требуется", status: "Prototype; 19 кривых отсутствуют", test_case: "FX-UI-02" }),
  b({ product: "fx", workspace: "MOTION", panel: "Macros", control: "Macro 1–8", parameterID_or_controller_method: "нет контроллера", automation: "требуется 8 стабильных ID", status: "Concept (DSP gap)", test_case: "FX-UI-05" }),
  b({ product: "fx", workspace: "MOTION", panel: "Matrix", control: "Route (64)", actual_source_path: "Modulation.h", status: "Не подключено к Program/UI", test_case: "FX-UI-04" }),
  b({ product: "fx", workspace: "PROCESS", panel: "Slot 1–4", control: "Effect type selector", actual_source_path: "products/fx", structural_state: "Program slot", status: "Implemented частично", test_case: "FX-UI-06" }),
  b({ product: "fx", workspace: "TRIGGER", panel: "Pattern", control: "Host-sync grid", actual_source_path: "Pattern.h", parameterID_or_controller_method: "нет runtime scheduler", status: "Gap: только SMF offline", test_case: "FX-UI-08" }),
  b({ product: "fx", workspace: "PRESETS", panel: "Export", control: "WAV / MIDI export", actual_source_path: "OfflineRender.h", status: "Worker-only, без UX", test_case: "FX-UI-09" }),
  b({ product: "fx", workspace: "ADVANCED", panel: "Diagnostics", control: "Output peak", telemetry_source: "output peak (существует)", unit: "dBFS", status: "Implemented; CPU/RMS — не фальсифицировать", test_case: "FX-UI-15" }),
];

export interface Stage {
  id: string;
  title: string;
  items: string[];
  exit: string;
}

export const stages: Stage[] = [
  { id: "DS-00", title: "Аудит и контракт", items: [
    "Сравнительная таблица: vox-ui + DS-0 branch + product widgets + #127/03/04/05",
    "Снять shared API, ownership, цвета/темы, размеры; пометить статусы компонентов с доказательством",
    "Полный UI_BINDING_MATRIX.csv (ID не выдумывать)",
    "Один current-owner source of truth; старые DS-документы — donor/historical",
    "Зафиксировать USER_VISUAL_SIGNOFF_REQUIRED для Drums #127 (только текст, без рисунков)",
  ], exit: "Матрица, component registry, архитектура, P1/P2, закрытые противоречия" },
  { id: "DS-01", title: "Foundations и компонентные контракты", items: [
    "Semantic tokens/theme per product, типографика, сетка, радиусы, focus, scale",
    "Shared input: knob/encoder, fader, switch/toggle/button/segmented, numeric, combo",
    "Единая host-gesture / parameter-adapter policy; запрет несуществующих ID",
    "vox_ui_showcase: все состояния, масштаб 75–200%",
  ], exit: "Независимая shared-библиотека + showcase + unit tests, без зависимости от Drums/FX DSP" },
  { id: "DS-02", title: "Performance / graphical / musical primitives", items: [
    "Meter/peak/over; VoxPad 4×4 + List; VoxKeyboard; timeline/step/curve/waveform/XY",
    "Read-only display / editable-через-controller; immutable snapshots",
    "Visual gate: именование скриншотов, reference SHA, без fallback на stock JUCE skin",
  ], exit: "Component tests / a11y / perf + пример в showcase + один reuse consumer" },
  { id: "DS-03", title: "Dockable VOX Drums UI (#127)", items: [
    "Карта 8 страниц → docks без потери функций",
    "Pad Rack 4×4/List, Inspector/pin, Step+Song+Sound+Sample, один bottom Mixer",
    "Минимальная telemetry после Architecture Guard; звуковой путь не менять",
    "Tests: 16 pads, 23 styles, 9 buses, Song 16/32/64, MIDI drag, automation, presets, layout restore",
  ], exit: "Нативный UI + реальные данные + exact-HEAD CI + visual owner acceptance (Draft/HOLD)" },
  { id: "DS-04", title: "Полный VOX FX UI", items: [
    "8 workspaces поверх products/fx и vox-ui",
    "Визуализировать только настоящий Program state; не обходить parameter IDs",
    "Полные workflows: generate/mutate/locks, layers, curves, modulation/macros, FX, host-sync patterns, WAV/MIDI, samples, presets",
    "Недостающий DSP — требование владельцу FX PR, не UI-муляж",
  ], exit: "Все FX workspaces functional, Windows CI / release gate" },
  { id: "DS-05", title: "Production hardening", items: [
    "Нет P0/P1; exact-head Windows x64 CI; Steinberg validator; ID checker; manifest; hashes",
    "100% интерактивных контролов с рабочей целью; 0 fake controls",
    "Screenshots Drums 1040×700 / 1280×720 / 1440×900 / 1600×1000 × 100/125/150/200% DPI",
    "Keyboard-only: focus order, role, visible focus; contrast и hit areas на реальных assets",
    "Automation/Program restore: reopen, undo/redo, resize, offline bounce; UI CPU при 96 kHz",
    "Финальный 1× pass владельца в Cubase/REAPER → независимое TL approval; main закрыт",
  ], exit: "Release-gate checklist пройден на конечном SHA" },
];

export const acceptance = [
  "Реальная цель и владелец; нет копий компонента с иным поведением",
  "Public API и нормализация/единицы документированы; 1 control ↔ 1 параметр (кроме XY и macro)",
  "Все допустимые состояния (normal…error) различимы",
  "Мышь + клавиатура + fine + numeric + reset + focus; имя/роль/значение/единицы; нет focus-trap и захвата DAW shortcut",
  "Корректные host gestures, feedback без циклов, state/Undo/redo, record/playback в Cubase/REAPER",
  "Meter/timeline/overlay — через safe snapshot; hidden editor останавливает repaint timers",
  "Responsive / DPI / длинные labels; нет клиппинга и скрытых кнопок",
  "Скриншот реального компонента и реального продукта; независимое ревью",
  "Нет alloc / lock / file / GUI / destroy в audio callback; реальные audio tests",
  "Минимум один негативный тест (missing sample / unavailable bus / invalid preset / bad file …)",
  "Exact HEAD Windows CI + VST3 validator; asset/license/provenance список",
];

export const leadChecklist = [
  "Единые токены/LookAndFeel для трёх продуктов; нет stock JUCE skin на реальных экранах",
  "Завершены input controls (knobs, faders, pads, keyboard, value input, switches); registry без ложного Production",
  "Завершены graph/timeline/selection/drag/drop/meters/file/preset/responsive/accessibility контракты",
  "Drums — весь #127: dock / Inspector / bottom faders / 4×4 / List / select-audition / named layouts",
  "FX — все 8 workspaces и связь с FX-01…FX-07 DSP/pattern/export/state/quality",
  "Cross-plugin tests: controls, host automation, resize; negative tests; state round trip; telemetry truthfulness",
  "Windows 10/11 x64 CI на конечном SHA, Steinberg validator, VST3 package + SHA-256; 44.1/48/96 kHz; 64/128/512; multi-instance",
  "Factory-content manifest, 48 FX программ / 12 паттернов, Drums factory content, ручное прослушивание",
  "Визуальная подпись владельца + один финальный DAW-тест владельца",
  "Нет открытых P0/P1, нет фальшивых элементов, нет непроверенных «PASS», нет изменений в main",
];

export const ciCommands = `cmake -S . -B build-suite -A x64 -DVOX_BUILD_SUITE=ON -DVOX_BUILD_LEGACY=OFF -DVOX_STRICT_DEPENDENCIES=ON "-DFETCHCONTENT_SOURCE_DIR_JUCE=$env:JUCE_DIR"
cmake --build build-suite --config Release --clean-first --parallel
ctest --test-dir build-suite -C Release -L suite --output-on-failure`;

export const gitRules = [
  ["UI / DS ветка", "от next/standalone-suite; один основной Draft PR для общей библиотеки; переиспользовать существующий UI PR"],
  ["Drums UI", "только от integration/vox-drums-1.0 после DS review; не drm/production-candidate и не Rack; #153 и #152 не терять"],
  ["FX UI", "координация с #156 (arena/d9776bd9-vox-electronic-engine); без force-push, без переключения ветки Arena"],
  ["Миграция vox-ui", "в next/standalone-suite — после code/contract review и cross-product CI; до этого изолированный Draft"],
  ["main", "закрыт для разработки; изменения processor API — узкий отдельный PR"],
  ["CI", "для точного SHA; Linux syntax check ≠ Windows qualification; зелёный старый commit не засчитывается"],
];

export const outOfScope = [
  "Переписывание DSP", "Rack / Kontakt-подобный хост", "Переразметка host ParameterID", "VST3 MIDI output",
  "Сетевые / neural сервисы", "HTML / WebView / Electron", "Генерация изображений без команды «нарисуй»", "Спонтанное объединение веток",
];
