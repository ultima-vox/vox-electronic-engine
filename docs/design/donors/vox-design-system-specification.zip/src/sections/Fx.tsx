import { useState } from "react";
import { Card, Note, PageHead } from "../components/ui";
import { GapTable } from "../components/GapTable";
import { fxGaps, fxWorkspaces } from "../data";
import { cn } from "../utils/cn";

const chain = ["Параметр / ввод", "DSP", "Аудио / события", "Program / host recall", "UI"];

export default function Fx() {
  const [ws, setWs] = useState(0);
  const layers = ["A", "B", "C", "D"];
  return (
    <div>
      <PageHead kicker="DS-04 · VOX FX · PR #156" title="Восемь рабочих пространств">
        VOX FX — самостоятельный MIDI-triggered VST3 Instrument, не insert-процессор. Проверено на efe909b0 (18.11.2026; live HEAD перепроверить).
        Интерфейс отображает только настоящий Program state; недостающий DSP возвращается владельцу FX PR как требование, а не заменяется UI-муляжом.
      </PageHead>

      <Card title="Целевая спецификация Program" sub="Цели, а не факт выполнения">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
          {[["4", "слоя A–D"], ["8", "одновременных событий"], ["64", "grains (глобально)"], ["20", "кривых (4×4 + 4)"], ["64", "mod routes"], ["8", "macros"], ["4", "serial FX slots"], ["12", "synthesis families"]].map(([n, l]) => (
            <div key={l} className="rounded-[6px] border border-vox-border bg-vox-raised p-2 text-center">
              <div className="tnum font-mono text-[20px] font-semibold text-[var(--product)]">{n}</div>
              <div className="text-[11px] leading-tight text-vox-sub">{l}</div>
            </div>
          ))}
        </div>
        <p className="mt-3 text-[12px] text-vox-sub">Длительность 50 ms–32 s (seconds/bars) · 48 curated programs / 12 patterns · детерминированная генерация · offline WAV/MIDI export.</p>
      </Card>

      <Card className="mt-5" title="Навигация workspaces" sub="Выберите область, чтобы увидеть обязательное содержимое и связанные gaps">
        <div role="tablist" className="flex flex-wrap gap-1 border-b border-vox-border pb-2">
          {fxWorkspaces.map(([n], i) => (
            <button
              key={n}
              role="tab"
              aria-selected={ws === i}
              onClick={() => setWs(i)}
              onKeyDown={(e) => {
                if (e.key === "ArrowRight") setWs((ws + 1) % 8);
                if (e.key === "ArrowLeft") setWs((ws + 7) % 8);
              }}
              className={cn("min-h-9 rounded-t-[6px] border-b-2 px-3 font-mono text-[12px] font-semibold tracking-wider", ws === i ? "border-[var(--product)] bg-vox-raised text-vox-text" : "border-transparent text-vox-sub hover:text-vox-text")}
            >
              {n}
            </button>
          ))}
        </div>
        <div role="tabpanel" className="pt-4">
          <div className="text-[13px] leading-relaxed">{fxWorkspaces[ws][1]}</div>
          {ws === 1 && (
            <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {layers.map((l) => (
                <div key={l} className="rounded-[6px] border border-vox-border bg-vox-raised p-3">
                  <div className="flex items-center justify-between"><b className="font-mono text-[var(--product)]">Layer {l}</b><span className="font-mono text-[10px] text-vox-sub">E · S</span></div>
                  <ul className="mt-2 space-y-0.5 text-[11px] text-vox-sub">
                    <li>family (1 из 12)</li><li>pitch · gain · pan · width · timing</li><li>2 osc · 2 filters</li><li>4 curves</li>
                  </ul>
                </div>
              ))}
            </div>
          )}
          {ws === 4 && (
            <div className="mt-4 flex flex-wrap items-center gap-2 font-mono text-[11px]">
              {["Slot 1", "Slot 2", "Slot 3", "Slot 4"].map((s, i) => (
                <span key={s} className="flex items-center gap-2"><span className="rounded border border-vox-edge bg-vox-raised px-3 py-2">{s}</span>{i < 3 && <span className="text-vox-sub">→</span>}</span>
              ))}
            </div>
          )}
          <div className="mt-4"><Note tone="neutral">Каждый контрол этого workspace попадёт в UI_BINDING_MATRIX.csv с реальным источником; без источника контрол не отображается.</Note></div>
        </div>
      </Card>

      <div className="mt-5">
        <GapTable gaps={fxGaps} storeKey="vox.gaps.fx.v1" />
      </div>

      <Card className="mt-5" title="Контрольное правило" sub="Заголовок Glitch, Granular, Generate, Effect slot или Pattern.h сами по себе не доказывают завершённый сценарий">
        <div className="flex flex-wrap items-center gap-2">
          {chain.map((c, i) => (
            <span key={c} className="flex items-center gap-2">
              <span className="rounded-[6px] border border-vox-edge bg-vox-raised px-3 py-2 text-[12px] font-medium">{c}</span>
              {i < chain.length - 1 && <span className="text-[var(--product)]" aria-hidden>→</span>}
            </span>
          ))}
        </div>
        <p className="mt-3 text-[12px] text-vox-sub">Проверяется вся цепочка. Ни одно звено не засчитывается по наличию C++ функции.</p>
      </Card>
    </div>
  );
}
