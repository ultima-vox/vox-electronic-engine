import { useEffect, useMemo, useState } from "react";
import { Badge, Btn, Card, Note, PageHead } from "../components/ui";
import { GapTable } from "../components/GapTable";
import { drumsDonors, drumsGaps } from "../data";
import { useStored } from "../lib/util";
import { cn } from "../utils/cn";

type Bottom = "collapsed" | "compact" | "expanded";
interface Layout {
  schema: 1;
  name: string;
  left: boolean;
  right: boolean;
  leftDock: string;
  rightDock: string;
  center: string[];
  split: "h" | "v";
  bottom: Bottom;
}

const PRESETS: Record<string, Layout> = {
  Beatmaking: { schema: 1, name: "Beatmaking", left: true, right: true, leftDock: "Pad Rack", rightDock: "Generator", center: ["Step Sequencer"], split: "h", bottom: "compact" },
  Composition: { schema: 1, name: "Composition", left: true, right: true, leftDock: "Pad Rack", rightDock: "Inspector", center: ["Song Arranger", "Step Sequencer"], split: "v", bottom: "collapsed" },
  "Sound Design": { schema: 1, name: "Sound Design", left: true, right: true, leftDock: "Pad Rack", rightDock: "Inspector", center: ["Full Sound Editor", "Sample Editor"], split: "h", bottom: "collapsed" },
  Mixing: { schema: 1, name: "Mixing", left: true, right: true, leftDock: "Pad Rack", rightDock: "Routing", center: ["Step Sequencer"], split: "h", bottom: "expanded" },
};

const VIEWPORTS = [
  { w: 1040, h: 700, label: "1040×700 (min)" },
  { w: 1280, h: 720, label: "1280×720" },
  { w: 1440, h: 900, label: "1440×900" },
  { w: 1600, h: 1000, label: "1600×1000" },
];
const DPI = [100, 125, 150, 200];
const LEFT_W = 260;
const RIGHT_W = 280;
const CENTER_MIN = 560;
const CHROME = 48;
const BOTTOM_H: Record<Bottom, number> = { collapsed: 36, compact: 140, expanded: 260 };
const LEFT_DOCKS = ["Pad Rack"];
const RIGHT_DOCKS = ["Inspector", "Generator", "Library", "Routing", "Diagnostics"];
const EDITORS = ["Step Sequencer", "Song Arranger", "Full Sound Editor", "Sample Editor"];

function DockBox({ children, className, style }: { children: React.ReactNode; className?: string; style?: React.CSSProperties }) {
  return (
    <div className={cn("absolute overflow-hidden rounded-[4px] border border-vox-edge bg-vox-panel p-1 text-[9px] leading-tight sm:text-[10px]", className)} style={style}>
      {children}
    </div>
  );
}

function DockSim() {
  const [stored, setStored] = useStored<Layout>("vox.drums.layout.v1", PRESETS.Beatmaking);
  const [vp, setVp] = useState(VIEWPORTS[0]);
  const [dpi, setDpi] = useState(100);
  const [msg, setMsg] = useState("");
  // защита от несовместимой схемы: безопасный fallback
  const layout = stored && stored.schema === 1 ? stored : PRESETS.Beatmaking;
  const upd = (p: Partial<Layout>) => setStored({ ...layout, ...p, name: "Custom" });

  useEffect(() => {
    if (!msg) return;
    const id = setTimeout(() => setMsg(""), 3000);
    return () => clearTimeout(id);
  }, [msg]);

  const calc = useMemo(() => {
    // эффективная ширина в логических px после DPI-масштаба
    const W = Math.round(vp.w / (dpi / 100));
    const H = Math.round(vp.h / (dpi / 100));
    let left = layout.left;
    let right = layout.right;
    const notes: string[] = [];
    const centerW = () => W - (left ? LEFT_W : 0) - (right ? RIGHT_W : 0);
    if (centerW() < CENTER_MIN && right) {
      right = false;
      notes.push("правый dock свёрнут первым");
    }
    if (centerW() < CENTER_MIN && left) {
      left = false;
      notes.push("левый dock свёрнут");
    }
    let bottom = layout.bottom;
    if (H - CHROME - BOTTOM_H[bottom] < 300 && bottom !== "collapsed") {
      bottom = bottom === "expanded" ? "compact" : "collapsed";
      notes.push(`Mixer уменьшен до ${bottom}`);
    }
    let center = layout.center;
    let split = layout.split;
    if (centerW() < 760 && center.length === 2) {
      center = [center[0]];
      notes.push("center: второй редактор → tab fallback");
    }
    if (center.length === 2 && H - CHROME - BOTTOM_H[bottom] < 420 && split === "v") {
      split = "h";
      notes.push("split v → h");
    }
    return { W, H, left, right, bottom, center, split, notes, centerW: centerW() };
  }, [vp, dpi, layout]);

  const { W, H } = calc;
  const pct = (n: number, d: number) => `${(n / d) * 100}%`;
  const mixerH = BOTTOM_H[calc.bottom];
  const mainH = H - CHROME - mixerH;
  const leftW = calc.left ? LEFT_W : 0;
  const rightW = calc.right ? RIGHT_W : 0;
  const cx = leftW;
  const cw = W - leftW - rightW;

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        {Object.keys(PRESETS).map((k) => (
          <Btn key={k} active={layout.name === k} onClick={() => setStored(PRESETS[k])}>{k}</Btn>
        ))}
        {layout.name === "Custom" && <Badge tone="warn">● Custom (Dirty)</Badge>}
        <Btn onClick={() => { setStored(PRESETS.Beatmaking); setMsg("Reset → Beatmaking (safe default)"); }}>Reset</Btn>
      </div>
      <div className="mb-3 flex flex-wrap items-center gap-3 text-[12px] text-vox-sub">
        <label className="flex items-center gap-1.5">Окно
          <select value={vp.label} onChange={(e) => setVp(VIEWPORTS.find((v) => v.label === e.target.value)!)} className="min-h-8 rounded-[6px] border border-vox-edge bg-vox-raised px-2 text-vox-text">
            {VIEWPORTS.map((v) => <option key={v.label}>{v.label}</option>)}
          </select>
        </label>
        <label className="flex items-center gap-1.5">Windows DPI
          <select value={dpi} onChange={(e) => setDpi(+e.target.value)} className="min-h-8 rounded-[6px] border border-vox-edge bg-vox-raised px-2 text-vox-text">
            {DPI.map((d) => <option key={d} value={d}>{d}%</option>)}
          </select>
        </label>
        <span className="tnum font-mono">логическое окно {W}×{H}</span>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
        <div>
          <div className="relative w-full rounded-[6px] border border-vox-border bg-vox-bg" style={{ aspectRatio: `${W} / ${H}` }} role="img" aria-label={`Схема workspace ${layout.name}, ${W}×${H}`}>
            <DockBox className="inset-x-0.5 top-0.5 flex items-center gap-2 !px-2" style={{ height: pct(CHROME, H) }}>
              <b className="text-vox-text">VOX Drums</b><span className="text-vox-sub">kit · pattern · song · BPM · Undo · Redo · Panic · context</span>
            </DockBox>
            {calc.left && (
              <DockBox style={{ left: pct(0, W), top: pct(CHROME, H), width: pct(LEFT_W, W), height: pct(mainH, H) }} className="border-[var(--product)]">
                <b className="text-[var(--product)]">{layout.leftDock}</b>
                <div className="mt-1 grid grid-cols-4 gap-0.5">
                  {Array.from({ length: 16 }, (_, i) => <div key={i} className="aspect-square rounded-[2px] border border-vox-edge bg-vox-graph" />)}
                </div>
              </DockBox>
            )}
            {calc.center.map((e, i) => {
              const two = calc.center.length === 2;
              const horiz = calc.split === "h";
              const st: React.CSSProperties = two
                ? horiz
                  ? { left: pct(cx + (i ? cw / 2 : 0), W), width: pct(cw / 2, W), top: pct(CHROME, H), height: pct(mainH, H) }
                  : { left: pct(cx, W), width: pct(cw, W), top: pct(CHROME + (i ? mainH / 2 : 0), H), height: pct(mainH / 2, H) }
                : { left: pct(cx, W), width: pct(cw, W), top: pct(CHROME, H), height: pct(mainH, H) };
              return (
                <DockBox key={e} style={st} className="bg-vox-graph">
                  <b className="text-vox-text">{e}</b>
                  <div className="mt-1 space-y-0.5">
                    {Array.from({ length: 4 }, (_, k) => <div key={k} className="h-1.5 rounded-[1px] bg-vox-border" />)}
                  </div>
                </DockBox>
              );
            })}
            {calc.right && (
              <DockBox style={{ left: pct(W - RIGHT_W, W), top: pct(CHROME, H), width: pct(RIGHT_W, W), height: pct(mainH, H) }}>
                <b className="text-vox-text">{layout.rightDock}</b>
                <div className="mt-1 space-y-0.5">{Array.from({ length: 5 }, (_, k) => <div key={k} className="h-1.5 rounded-[1px] bg-vox-border" />)}</div>
              </DockBox>
            )}
            <DockBox style={{ left: pct(0, W), top: pct(H - mixerH, H), width: pct(W, W), height: pct(mixerH, H) }} className="border-[var(--product)]/70">
              <b className="text-[var(--product)]">Mixer · {calc.bottom}</b>
              {calc.bottom !== "collapsed" && (
                <div className="mt-1 flex h-[70%] gap-0.5">
                  {Array.from({ length: calc.bottom === "expanded" ? 16 : 8 }, (_, i) => (
                    <div key={i} className="relative flex-1 rounded-[2px] border border-vox-border bg-vox-graph">
                      {calc.bottom === "expanded" && <div className="absolute inset-x-0.5 bottom-1 h-1 rounded-[1px] bg-vox-edge" style={{ bottom: `${10 + (i * 37) % 60}%` }} />}
                    </div>
                  ))}
                </div>
              )}
            </DockBox>
          </div>
          <div className="mt-2 min-h-5 text-[12px]" aria-live="polite">
            {calc.notes.length ? (
              <span className="text-vox-warn">Авто-адаптация: {calc.notes.join(" · ")}. Периферия сжимается раньше музыкальной сетки.</span>
            ) : (
              <span className="text-vox-sub">Центр {calc.centerW} px ≥ {CENTER_MIN} px — адаптация не требуется.</span>
            )}
            {msg && <span className="ml-2 text-vox-accent">{msg}</span>}
          </div>
        </div>

        <div className="space-y-3 text-[12px]">
          <fieldset className="rounded-[6px] border border-vox-border p-3">
            <legend className="px-1 text-vox-sub">Docks</legend>
            <label className="flex items-center gap-2"><input type="checkbox" className="accent-[var(--product)]" checked={layout.left} onChange={(e) => upd({ left: e.target.checked })} /> Левый dock</label>
            <select value={layout.leftDock} onChange={(e) => upd({ leftDock: e.target.value })} className="mt-1 min-h-8 w-full rounded-[6px] border border-vox-edge bg-vox-raised px-2">{LEFT_DOCKS.map((d) => <option key={d}>{d}</option>)}</select>
            <label className="mt-2 flex items-center gap-2"><input type="checkbox" className="accent-[var(--product)]" checked={layout.right} onChange={(e) => upd({ right: e.target.checked })} /> Правый dock</label>
            <select value={layout.rightDock} onChange={(e) => upd({ rightDock: e.target.value })} className="mt-1 min-h-8 w-full rounded-[6px] border border-vox-edge bg-vox-raised px-2">{RIGHT_DOCKS.map((d) => <option key={d}>{d}</option>)}</select>
          </fieldset>
          <fieldset className="rounded-[6px] border border-vox-border p-3">
            <legend className="px-1 text-vox-sub">Center (макс. 2)</legend>
            {[0, 1].map((i) => (
              <select
                key={i}
                aria-label={`Редактор ${i + 1}`}
                value={layout.center[i] ?? ""}
                onChange={(e) => {
                  const next = [...layout.center];
                  if (e.target.value === "") next.splice(i, 1);
                  else if (next.includes(e.target.value) && next[i] !== e.target.value) return setMsg("Одна панель — одна модель: дубликат запрещён");
                  else next[i] = e.target.value;
                  upd({ center: next.filter(Boolean) });
                }}
                className="mb-1 min-h-8 w-full rounded-[6px] border border-vox-edge bg-vox-raised px-2"
              >
                {i === 1 && <option value="">— нет —</option>}
                {EDITORS.map((d) => <option key={d}>{d}</option>)}
              </select>
            ))}
            <div className="mt-1 flex gap-1">
              <Btn active={layout.split === "h"} onClick={() => upd({ split: "h" })}>Split ↔</Btn>
              <Btn active={layout.split === "v"} onClick={() => upd({ split: "v" })}>Split ↕</Btn>
            </div>
          </fieldset>
          <fieldset className="rounded-[6px] border border-vox-border p-3">
            <legend className="px-1 text-vox-sub">Bottom Mixer (ровно один)</legend>
            <div className="flex gap-1">
              {(["collapsed", "compact", "expanded"] as Bottom[]).map((b) => <Btn key={b} active={layout.bottom === b} onClick={() => upd({ bottom: b })}>{b}</Btn>)}
            </div>
          </fieldset>
        </div>
      </div>

      <details className="mt-3 rounded-[6px] border border-vox-border bg-vox-raised p-3 text-[12px]">
        <summary className="cursor-pointer text-vox-sub">UI-only layout schema (versioned, сохраняется локально)</summary>
        <pre className="mt-2 overflow-x-auto font-mono text-[11px] text-vox-sub">{JSON.stringify(layout, null, 2)}</pre>
        <p className="mt-2 text-vox-sub">Layout не влияет на DSP / Pattern / automation. Неизвестная schema → безопасный default.</p>
      </details>
    </div>
  );
}

export default function Drums() {
  return (
    <div>
      <PageHead kicker="DS-03 · VOX Drums · issue #127" title="Dockable workstation: матрица разрывов">
        Проверено на ef13daa3 (integration, 18.11.2026; live HEAD перепроверить перед реализацией). Это разрывы от утверждённого релизного UI, а не утверждение, что генератор,
        Song или мультивыходы отсутствуют в DSP. Сначала карта переноса всех функций 8 страниц → docks без потери возможностей.
      </PageHead>

      <Note tone="danger">
        <b className="text-vox-danger">USER_VISUAL_SIGNOFF_REQUIRED.</b> Hardware-inspired направление принято условно; до нового Drums UI C++ нужен отдельный финальный sign-off владельца.
        Drums и FX — Draft/HOLD для релиза.
      </Note>

      <div className="mt-5"><GapTable gaps={drumsGaps} storeKey="vox.gaps.drums.v1" /></div>

      <Card className="mt-6" title="Симулятор workspace (§7.1)" sub="Top chrome · Side docks · Center ≤ 2 редакторов · один Bottom Mixer · именованные layouts · 1040×700 min · DPI 125/150/200 %">
        <DockSim />
      </Card>

      <Card className="mt-5" title="Карта переноса: существующие функции → docks" sub="Предварительная, составлена по упоминаниям в ТЗ; уточняется аудитом DS-00. Не удалять функцию без проверенной замены.">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-left text-[12px]">
            <thead className="text-vox-sub"><tr><th className="pb-2 font-medium">Донор (сейчас)</th><th className="pb-2 font-medium">Цель</th><th className="pb-2 font-medium">Gap</th></tr></thead>
            <tbody>
              {drumsDonors.map(([a, b, c]) => (
                <tr key={a} className="border-t border-vox-border">
                  <td className="py-1.5 pr-3">{a}</td>
                  <td className="py-1.5 pr-3 text-vox-sub">→ {b}</td>
                  <td className="py-1.5 font-mono text-[11px] text-[var(--product)]">{c}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Card title="Сценарии end-to-end (§7.3)">
          <ol className="list-decimal space-y-1.5 pl-5 text-[12px] text-vox-sub">
            <li>Kit → <b className="text-vox-text">SELECT</b> без звука → отдельный AUDITION с velocity → Tune/Decay → automation и Undo.</li>
            <li>Pattern + parameter lanes → generate / lock / mutate / fill → A/B → save/restore.</li>
            <li>Song 16/32/64 → Edit Source / This Bar → copy-on-write → full-song MIDI drag в Cubase/REAPER.</li>
            <li>Mix 16 pads → Main/Out2–9, Mute/Solo, sends/tails, disabled-bus fallback, per-bus метры без ложной телеметрии.</li>
            <li>WAV A/B → waveform/trim/reverse/layering → missing-file → другой PC → диагностика без подмены.</li>
            <li>Layout / pin Inspector / Mixer / resize / DPI → restore; DSP, Pattern и automation не меняются.</li>
          </ol>
        </Card>
        <Card title="Telemetry: что можно показывать">
          <table className="w-full text-left text-[12px]">
            <thead className="text-vox-sub"><tr><th className="pb-2 font-medium">Индикатор</th><th className="pb-2 font-medium">Источник</th></tr></thead>
            <tbody className="[&_td]:border-t [&_td]:border-vox-border [&_td]:py-1.5">
              <tr><td>Hit flash</td><td className="text-vox-sub">takeHitMask() — только биты; velocity требует расширения</td></tr>
              <tr><td>Pad peak</td><td className="text-vox-sub">takePadMeter() · exchange(0)</td></tr>
              <tr><td>Main peak</td><td className="text-vox-sub">takeMainMeter() · exchange(0)</td></tr>
              <tr><td>Per-bus OVER</td><td><Badge tone="danger">нет данных → Unavailable</Badge></td></tr>
            </tbody>
          </table>
          <p className="mt-3 text-[12px] text-vox-sub">Один coordinator вызывает take* раз за тик (20–30 Hz) и рассылает immutable snapshots. Расширение — только после Architecture Guard и независимой ревизии tap-point.</p>
        </Card>
      </div>
    </div>
  );
}
