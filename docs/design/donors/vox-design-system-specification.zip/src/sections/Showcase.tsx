import { useCallback, useState } from "react";
import { Badge, Btn, Card, Note, PageHead } from "../components/ui";
import { Fader, Knob, Meter, XYPad, dbToNorm, fmtHz, fmtMs, normToDb } from "../components/controls";
import { PadGrid, StepGridDemo, VoxKeyboardDemo } from "../components/perform";
import { EnvelopeEditor } from "../components/graph";
import { states } from "../data";
import { audioState } from "../lib/audio";
import { useDemoTelemetry } from "../lib/util";
import { cn } from "../utils/cn";

type Tone = "ok" | "warn" | "danger" | "accent";
interface LogItem {
  id: number;
  msg: string;
  tone?: Tone;
}
let logId = 0;

function Strip({ name, base, live }: { name: string; base: number; live: boolean }) {
  const [n, setN] = useState(dbToNorm(0));
  const [mute, setMute] = useState(false);
  const db = normToDb(n);
  const snap = useDemoTelemetry(live && !mute, (db === -Infinity ? -90 : db) + base);
  const pk = (v: number | undefined) => (snap && v !== undefined ? Math.max(-80, v) : null);
  return (
    <div className="flex flex-col items-center gap-2 rounded-[8px] border border-vox-border bg-vox-raised p-3">
      <div className="flex gap-2">
        <Fader label={name} value={n} onChange={setN} disabled={false} />
        <div className="flex gap-1 pt-0">
          <Meter label={`${name} L`} peak={pk(snap?.l)} />
          <Meter label={`${name} R`} peak={pk(snap?.r)} />
        </div>
      </div>
      <Btn active={mute} onClick={() => setMute((m) => !m)} className="w-full">{mute ? "MUTED" : "Mute"}</Btn>
    </div>
  );
}

function stateStyle(s: (typeof states)[number]): { cls: string; glyph: string; how: string } {
  const base = "border-vox-edge bg-vox-raised text-vox-text";
  switch (s) {
    case "Normal": return { cls: base, glyph: "", how: "базовая рамка" };
    case "Hover": return { cls: "border-vox-sub bg-vox-border/60 text-vox-text", glyph: "", how: "светлее рамка и фон" };
    case "Pressed": return { cls: "border-vox-edge bg-vox-graph text-vox-text translate-y-px shadow-[inset_0_2px_4px_#000]", glyph: "", how: "утоплено, сдвиг 1 px" };
    case "Focused": return { cls: "border-vox-edge bg-vox-raised text-vox-text outline outline-2 outline-offset-2 outline-vox-accent", glyph: "", how: "внешний контур 2 px" };
    case "Selected": return { cls: "border-[var(--product)] bg-vox-raised text-vox-text", glyph: "◉", how: "рамка + маркер ◉" };
    case "Active": return { cls: "border-[var(--product)] bg-[var(--product)]/25 text-vox-text", glyph: "▶", how: "заливка + маркер ▶" };
    case "Disabled": return { cls: "border-vox-border bg-vox-panel text-vox-sub opacity-40", glyph: "", how: "приглушено, не фокусируется" };
    case "ReadOnly": return { cls: "border-dashed border-vox-edge bg-transparent text-vox-text", glyph: "🔒", how: "пунктир без заливки, значение читаемо" };
    case "Unavailable": return { cls: "hatch border-vox-border bg-vox-panel text-vox-sub", glyph: "—", how: "штриховка, причина в tooltip" };
    case "Warning": return { cls: "border-vox-warn bg-vox-raised text-vox-warn", glyph: "▲", how: "рамка + треугольник" };
    case "Error": return { cls: "border-vox-danger bg-vox-danger/10 text-vox-danger", glyph: "✕", how: "рамка + ✕ + текст ошибки" };
    case "Automated": return { cls: "border-vox-ok bg-vox-raised text-vox-ok", glyph: "A", how: "бейдж A" };
    case "Modulated": return { cls: "border-dashed border-vox-mod bg-vox-raised text-vox-mod", glyph: "M", how: "пунктирное кольцо + M" };
    case "Bypassed": return { cls: "border-vox-edge bg-vox-panel text-vox-sub line-through", glyph: "⏻", how: "зачёркнуто, host-значение не меняется" };
    case "Dirty": return { cls: "border-vox-edge bg-vox-raised text-vox-text italic", glyph: "●", how: "курсив + точка (несохранённое)" };
    case "Dragging": return { cls: "border-vox-text bg-vox-raised text-vox-text shadow-[0_6px_14px_rgba(0,0,0,0.7)] scale-[1.03]", glyph: "✥", how: "тень + масштаб" };
    case "DropValid": return { cls: "border-dashed border-vox-ok bg-vox-ok/10 text-vox-ok", glyph: "+", how: "пунктир + «+»" };
    case "DropInvalid": return { cls: "border-dashed border-vox-danger bg-vox-danger/10 text-vox-danger", glyph: "⊘", how: "пунктир + ⊘" };
  }
}

export default function Showcase() {
  const [log, setLog] = useState<LogItem[]>([{ id: 0, msg: "Журнал событий: действия контролов, host-gesture, ownership" }]);
  const push = useCallback((msg: string, tone?: Tone) => setLog((l) => [{ id: ++logId, msg, tone }, ...l].slice(0, 40)), []);
  const [sound, setSound] = useState(true);
  const [live, setLive] = useState(true);

  const [tune, setTune] = useState(0);
  const [cut, setCut] = useState(1200);
  const [decay, setDecay] = useState(240);
  const [drive, setDrive] = useState(35);
  const [pan, setPan] = useState(0);
  const [send, setSend] = useState(20);
  const [xy, setXy] = useState({ x: 0.55, y: 0.35 });
  const [modDepth, setModDepth] = useState(0.12);

  const g = (name: string) => (p: "begin" | "end") => push(`host gesture ${p.toUpperCase()} · ${name}`, "accent");

  return (
    <div>
      <PageHead kicker="DS-01 / DS-02 · Эталон поведения" title="Showcase контролов">
        Живые эталоны контрактов из §4–5. Данные метров и клавиатуры — демо-источники (подписаны); они показывают контракт, а не подтверждают DSP. Реальное поведение
        доказывается только product / DAW-тестом, а showcase доказывает локальный компонент.
      </PageHead>

      <div className="mb-4 flex flex-wrap items-center gap-3">
        <Btn
          active={sound}
          onClick={() => {
            audioState.enabled = !sound;
            setSound(!sound);
          }}
        >
          🔊 Звук демо: {sound ? "вкл" : "выкл"}
        </Btn>
        <Btn active={live} onClick={() => setLive((l) => !l)}>
          Telemetry: {live ? "live demo (25 Hz snapshot)" : "no data"}
        </Btn>
        <Badge tone="warn">DEMO DATA</Badge>
      </div>

      <div className="grid gap-5 xl:grid-cols-[1fr_340px]">
        <div className="space-y-5">
          <Card title="VoxKnob / VoxEncoder" sub="270°, drag ↕, Shift = fine, двойной клик = default, Enter / клик по значению = ввод ('1.5k', '200 ms'), ←→↑↓ PgUp PgDn Home End">
            <div className="flex flex-wrap items-start gap-x-3 gap-y-5">
              <Knob label="Tune" size={64} min={-24} max={24} def={0} bipolar unit="st" value={tune} onChange={setTune} onGesture={g("Tune")} fmt={(v) => `${v > 0 ? "+" : ""}${v.toFixed(1)} st`} />
              <Knob label="Cutoff" size={64} min={20} max={20000} def={1200} log value={cut} onChange={setCut} onGesture={g("Cutoff")} fmt={fmtHz} mod={0.12} />
              <Knob label="Decay" size={48} min={5} max={4000} def={240} log value={decay} onChange={setDecay} unit="ms" fmt={fmtMs} onGesture={g("Decay")} />
              <Knob label="Drive" size={48} min={0} max={100} def={35} unit="%" value={drive} onChange={setDrive} state="automated" fmt={(v) => `${v.toFixed(0)} %`} onGesture={g("Drive (automated)")} />
              <Knob label="Pan" size={48} min={-100} max={100} def={0} bipolar value={pan} onChange={setPan} fmt={(v) => (Math.abs(v) < 1 ? "C" : v < 0 ? `L ${Math.abs(v).toFixed(0)}` : `R ${v.toFixed(0)}`)} />
              <Knob label="Send" size={36} min={0} max={100} def={20} unit="%" value={send} onChange={setSend} fmt={(v) => `${v.toFixed(0)} %`} />
              <Knob label="Read-only" size={48} min={0} max={100} def={50} unit="%" value={62} onChange={() => {}} state="readOnly" fmt={(v) => `${v} %`} />
              <Knob label="Disabled" size={48} min={0} max={100} def={50} unit="%" value={40} onChange={() => {}} state="disabled" fmt={(v) => `${v} %`} />
              <Knob label="Unavail." size={48} min={0} max={100} def={50} unit="%" value={40} onChange={() => {}} state="unavailable" fmt={() => "n/a"} />
              <Knob label="Error" size={48} min={0} max={100} def={50} unit="%" value={90} onChange={() => {}} state="error" fmt={(v) => `${v} %`} />
            </div>
            <div className="mt-4 grid gap-2 text-[11px] text-vox-sub md:grid-cols-2">
              <Note>Cutoff — логарифмическая шкала (Hz / kHz); внешнее кольцо <span className="text-vox-mod">M</span> — модуляционный диапазон, а не копия base-дуги. Drive — Automated (бейдж A).</Note>
              <Note>Tune / Pan — bipolar: ноль виден, дуга растёт от центра. Double-click возвращает к <i>default параметра</i> (Tune 0, Cutoff 1.2 kHz), а не к декоративным 50 %.</Note>
            </div>
          </Card>

          <Card title="VoxFader + VoxPeakMeter" sub="Вертикальный фейдер: утопленный трек, unity-метка 0 dB, double-click = unity, ввод dB. Метры — по snapshot; OVER — отдельный latch.">
            <div className="flex flex-wrap gap-3">
              <Strip name="Kick" base={-4} live={live} />
              <Strip name="Snare" base={-9} live={live} />
              <Strip name="Hat" base={-16} live={live} />
              <div className="max-w-xs flex-1 space-y-2 text-[12px] text-vox-sub">
                <p>Поднимите Kick до +6 dB: demo post-fader peak выйдет за 0 dBFS и защёлкнет <b className="text-vox-danger">OVER</b>. Цвет шкалы меняется на danger только выше 0 dBFS; жёлтая зона — предупреждение, не clip.</p>
                <p>«Telemetry: no data» показывает честное состояние без данных — штриховка и «no data», а не нулевой уровень.</p>
                <p>Демо-таппер: 0 dB = n 0.75, диапазон −60…+6 dB. В продукте шкала берётся из нормализации существующего ParameterID; звук и автоматизация не меняются ради dB-шкалы.</p>
              </div>
            </div>
          </Card>

          <Card title="VoxPadGrid · SELECT ≠ AUDITION" sub="Отдельные действия, явная velocity, mute / solo / missing, List 16">
            <PadGrid onLog={push} />
          </Card>

          <Card title="VoxKeyboard" sub="Ownership нот UI / EXT / sustain, drag между клавишами, Panic, горизонтальный scroll">
            <VoxKeyboardDemo onLog={push} />
          </Card>

          <Card title="VoxStepGrid" sub="Сетка шагов + velocity-lane под одной линейкой">
            <StepGridDemo />
          </Card>

          <Card title="VoxEnvelopeEditor / VoxCurveEditor" sub="2–16 узлов, snap, Undo / Redo, Escape = revert, клавиатурное редактирование">
            <EnvelopeEditor />
          </Card>
        </div>

        <div className="space-y-5">
          <div className="sticky top-4 space-y-5">
            <Card title="Журнал событий" sub="Что получил бы product controller">
              <ul className="max-h-[300px] space-y-1 overflow-y-auto font-mono text-[11px]" aria-live="polite">
                {log.map((l) => (
                  <li
                    key={l.id}
                    className={cn(
                      "rounded-[4px] border-l-2 bg-vox-raised px-2 py-1 leading-snug",
                      l.tone === "ok" && "border-vox-ok text-vox-text",
                      l.tone === "warn" && "border-vox-warn text-vox-warn",
                      l.tone === "danger" && "border-vox-danger text-vox-danger",
                      l.tone === "accent" && "border-vox-accent text-vox-sub",
                      !l.tone && "border-vox-edge text-vox-sub",
                    )}
                  >
                    {l.msg}
                  </li>
                ))}
              </ul>
              <Btn className="mt-2" onClick={() => setLog([])}>Очистить</Btn>
            </Card>

            <Card title="VoxXYPad + mod overlay" sub="Два связанных параметра: Cutoff (log) × Resonance. Пунктир — модуляция.">
              <div className="flex flex-col items-center gap-3">
                <XYPad x={xy.x} y={xy.y} onChange={(x, y) => setXy({ x, y })} modX={modDepth} modY={modDepth * 0.6} size={240} />
                <div className="tnum font-mono text-[12px] text-vox-sub">
                  Cutoff {fmtHz(20 * Math.pow(1000, xy.x))} · Res {(xy.y * 100).toFixed(0)} %
                </div>
                <label className="flex items-center gap-2 text-[12px] text-vox-sub">
                  Mod depth
                  <input type="range" min={0} max={0.3} step={0.01} value={modDepth} onChange={(e) => setModDepth(+e.target.value)} className="w-28 accent-[var(--color-vox-mod)]" />
                  <span className="tnum font-mono text-vox-text">±{(modDepth * 100).toFixed(0)}%</span>
                </label>
              </div>
            </Card>
          </div>
        </div>
      </div>

      <Card className="mt-5" title="Матрица состояний (18)" sub="Disabled, ReadOnly и Unavailable — разные состояния. Цвет — никогда единственный признак.">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          {states.map((s) => {
            const st = stateStyle(s);
            return (
              <div key={s} className="flex flex-col gap-1">
                <div className={cn("relative flex h-9 items-center justify-between gap-2 rounded-[6px] border px-2 text-[12px]", st.cls)}>
                  <span className="tnum">{s}</span>
                  <span aria-hidden className="font-mono text-[12px]">{st.glyph}</span>
                  {s === "Dirty" && <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-vox-text" aria-hidden />}
                </div>
                <div className="text-[10px] leading-tight text-vox-sub">{st.how}</div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
