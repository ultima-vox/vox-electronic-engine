import { useState } from "react";
import { Badge, Btn, Card, Note, PageHead } from "../components/ui";
import { ciCommands, gitRules, leadChecklist, stages } from "../data";
import { useStored } from "../lib/util";
import { cn } from "../utils/cn";

export default function Plan() {
  const [done, setDone] = useStored<Record<string, boolean>>("vox.plan.v1", {});
  const [open, setOpen] = useState("DS-00");
  const [copied, setCopied] = useState(false);
  const key = (s: string, i: number) => `${s}:${i}`;
  const total = stages.reduce((n, s) => n + s.items.length, 0);
  const finished = Object.values(done).filter(Boolean).length + 0;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(ciCommands);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div>
      <PageHead kicker="§10–13 · План, Git, CI, чек-лист" title="Дорожная карта DS-00 → DS-05">
        Одна зона ответственности UI-команды. DSP-разработчики Drums/FX продолжают работу; UI-агент не переписывает их PR и не меняет общие processor/state контракты без ревью.
      </PageHead>

      <div className="mb-4 flex items-center gap-3 text-[12px] text-vox-sub">
        <div className="h-2 w-64 overflow-hidden rounded-full bg-vox-graph" role="progressbar" aria-valuemin={0} aria-valuemax={total} aria-valuenow={finished}>
          <div className="h-full bg-[var(--product)] transition-all duration-[140ms]" style={{ width: `${(finished / total) * 100}%` }} />
        </div>
        <span className="tnum font-mono text-vox-text">{finished}/{total}</span> задач отмечено (локальный трекер)
      </div>

      <div className="space-y-2">
        {stages.map((s) => {
          const n = s.items.filter((_, i) => done[key(s.id, i)]).length;
          const isOpen = open === s.id;
          return (
            <section key={s.id} className="rounded-[8px] border border-vox-border bg-vox-panel">
              <h3>
                <button
                  aria-expanded={isOpen}
                  onClick={() => setOpen(isOpen ? "" : s.id)}
                  className="flex min-h-12 w-full items-center gap-3 px-4 text-left"
                >
                  <span className="font-mono text-[13px] font-bold text-[var(--product)]">{s.id}</span>
                  <span className="flex-1 text-[14px] font-semibold">{s.title}</span>
                  <Badge tone={n === s.items.length ? "ok" : "neutral"}>{n}/{s.items.length}</Badge>
                  <span aria-hidden className={cn("text-vox-sub transition-transform duration-[140ms]", isOpen && "rotate-90")}>▸</span>
                </button>
              </h3>
              {isOpen && (
                <div className="border-t border-vox-border px-4 py-3">
                  <ul className="space-y-1">
                    {s.items.map((it, i) => (
                      <li key={it}>
                        <label className="flex cursor-pointer items-start gap-2 rounded-[4px] px-1 py-1 text-[12px] hover:bg-vox-raised">
                          <input type="checkbox" className="mt-0.5 h-4 w-4 accent-[var(--product)]" checked={!!done[key(s.id, i)]} onChange={() => setDone((d) => ({ ...d, [key(s.id, i)]: !d[key(s.id, i)] }))} />
                          <span className={cn(done[key(s.id, i)] && "text-vox-sub line-through")}>{it}</span>
                        </label>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-3"><Note tone="accent"><b className="text-vox-accent">Exit:</b> {s.exit}</Note></div>
                </div>
              )}
            </section>
          );
        })}
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <Card title="Git и параллельная работа">
          <dl className="space-y-2 text-[12px]">
            {gitRules.map(([k, v]) => (
              <div key={k} className="flex gap-3">
                <dt className="w-28 shrink-0 font-semibold text-[var(--product)]">{k}</dt>
                <dd className="text-vox-sub">{v}</dd>
              </div>
            ))}
          </dl>
        </Card>

        <Card title="Windows CI (из suite.yml)" sub="JUCE/VST3 SDK — строго по действующему workflow; не менять ABI при UI-работах">
          <pre className="overflow-x-auto rounded-[6px] border border-vox-border bg-vox-graph p-3 font-mono text-[11px] leading-relaxed text-vox-sub">{ciCommands}</pre>
          <div className="mt-2 flex items-center gap-2">
            <Btn onClick={copy}>{copied ? "✓ Скопировано" : "Копировать"}</Btn>
          </div>
          <p className="mt-3 text-[12px] text-vox-sub">
            Короткий ctest — не подмена обязательных стадий: Drums gain-staging (параллельный пакет) и Steinberg validator с pinned SDK. Записывать SHA, run URL, число тестов,
            manifest / SHA-256, причину FAIL и подтверждение отсутствия P0/P1. Линукс-syntax-check ≠ Windows qualification.
          </p>
        </Card>
      </div>

      <Card className="mt-5" title="Чек-лист принимающего техлида (§13)" sub="Локальные отметки; ни один пункт не закрыт этим документом">
        <LeadList />
      </Card>
    </div>
  );
}

function LeadList() {
  const [c, setC] = useStored<boolean[]>("vox.lead.v1", leadChecklist.map(() => false));
  const n = c.filter(Boolean).length;
  return (
    <div>
      <ul className="grid gap-1.5 md:grid-cols-2">
        {leadChecklist.map((l, i) => (
          <li key={l}>
            <label className={cn("flex cursor-pointer items-start gap-2 rounded-[6px] border px-3 py-2 text-[12px] leading-snug", c[i] ? "border-[var(--product)] bg-[var(--product)]/10" : "border-vox-border hover:bg-vox-raised")}>
              <input type="checkbox" className="mt-0.5 h-4 w-4 accent-[var(--product)]" checked={!!c[i]} onChange={() => setC((p) => p.map((v, k) => (k === i ? !v : v)))} />
              {l}
            </label>
          </li>
        ))}
      </ul>
      <div className="mt-3 text-[12px] text-vox-sub">
        Закрыто {n} из {leadChecklist.length}.{" "}
        {n === leadChecklist.length ? <span className="text-vox-ok">Готово к независимому TL approval; merge в main — только по отдельному разрешению.</span> : "Релиз заблокирован до закрытия всех пунктов."}
      </div>
    </div>
  );
}
