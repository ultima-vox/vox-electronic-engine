import { useMemo, useState } from "react";
import { Badge, Btn, Card, Note, PageHead, StatusBadge } from "../components/ui";
import { acceptance, registry, type CompStatus } from "../data";
import { useStored } from "../lib/util";
import { cn } from "../utils/cn";

const STATUSES: CompStatus[] = ["Concept", "Prototype", "Implemented", "Production", "Deferred"];

export default function Registry() {
  const [filter, setFilter] = useState<CompStatus | "all">("all");
  const [q, setQ] = useState("");
  const [family, setFamily] = useState("all");
  const [gate, setGate] = useStored<Record<string, boolean[]>>("vox.gate.v1", {});
  const [active, setActive] = useState(registry[3].name);

  const families = useMemo(() => ["all", ...Array.from(new Set(registry.map((r) => r.family)))], []);
  const rows = registry.filter(
    (r) => (filter === "all" || r.status === filter) && (family === "all" || r.family === family) && r.name.toLowerCase().includes(q.toLowerCase()),
  );

  const checks = gate[active] ?? acceptance.map(() => false);
  const done = checks.filter(Boolean).length;
  const all = done === acceptance.length;
  const comp = registry.find((r) => r.name === active)!;

  const toggle = (i: number) => setGate((g) => ({ ...g, [active]: (g[active] ?? acceptance.map(() => false)).map((v, k) => (k === i ? !v : v)) }));

  return (
    <div>
      <PageHead kicker="DS-00 · Component registry" title="Реестр компонентов и протокол приёмки">
        Названия — контракт целевой библиотеки, а не утверждение, что C++ классы существуют. Production возможен только при выполнении всех применимых условий §12;
        до аудита DS-00 ни один компонент не получает Production.
      </PageHead>

      <div className="mb-3 flex flex-wrap items-center gap-2">
        <Btn active={filter === "all"} onClick={() => setFilter("all")}>Все ({registry.length})</Btn>
        {STATUSES.map((s) => (
          <Btn key={s} active={filter === s} onClick={() => setFilter(s)}>
            {s} ({registry.filter((r) => r.status === s).length})
          </Btn>
        ))}
        <select
          aria-label="Семейство"
          value={family}
          onChange={(e) => setFamily(e.target.value)}
          className="min-h-8 rounded-[6px] border border-vox-edge bg-vox-raised px-2 text-[12px]"
        >
          {families.map((f) => (
            <option key={f} value={f}>{f === "all" ? "все семейства" : f}</option>
          ))}
        </select>
        <input
          aria-label="Поиск компонента"
          placeholder="Поиск…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="min-h-8 w-44 rounded-[6px] border border-vox-edge bg-vox-graph px-2 text-[12px]"
        />
      </div>

      <div className="overflow-x-auto rounded-[8px] border border-vox-border bg-vox-panel">
        <table className="w-full min-w-[820px] text-left text-[12px]">
          <thead className="bg-vox-raised text-vox-sub">
            <tr>
              <th className="px-3 py-2 font-medium">Компонент</th>
              <th className="px-3 py-2 font-medium">Семейство</th>
              <th className="px-3 py-2 font-medium">Статус</th>
              <th className="px-3 py-2 font-medium">Потребители</th>
              <th className="px-3 py-2 font-medium">Доказательство</th>
              <th className="px-3 py-2 font-medium">Веб-эталон</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.name} className="border-t border-vox-border align-top">
                <td className="px-3 py-2 font-mono font-semibold">{r.name}</td>
                <td className="px-3 py-2 text-vox-sub">{r.family}</td>
                <td className="px-3 py-2"><StatusBadge status={r.status} /></td>
                <td className="px-3 py-2 text-vox-sub">{r.consumers}</td>
                <td className="px-3 py-2 text-vox-sub">{r.evidence}</td>
                <td className="px-3 py-2">{r.demo ? <Badge tone="accent">showcase ✓</Badge> : <span className="text-vox-edge">—</span>}</td>
              </tr>
            ))}
            {!rows.length && (
              <tr><td colSpan={6} className="px-3 py-6 text-center text-vox-sub">Нет компонентов под фильтр</td></tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="mt-2 text-[11px] text-vox-sub">Компонент становится общим после проверки использования минимум в двух применимых контекстах либо обоснованного нейтрального контракта.</p>

      <Card className="mt-6" title="Гейт приёмки компонента (§12)" sub="Отметки сохраняются локально. Результат — «допуск к Production-ревью», а не присвоение статуса.">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <label className="flex items-center gap-2 text-[12px] text-vox-sub">
            Компонент
            <select
              value={active}
              onChange={(e) => setActive(e.target.value)}
              className="min-h-8 rounded-[6px] border border-vox-edge bg-vox-raised px-2 font-mono text-[12px] text-vox-text"
            >
              {registry.map((r) => (
                <option key={r.name}>{r.name}</option>
              ))}
            </select>
          </label>
          <StatusBadge status={comp.status} />
          <div className="ml-auto flex items-center gap-2">
            <div className="h-2 w-40 overflow-hidden rounded-full bg-vox-graph" role="progressbar" aria-valuemin={0} aria-valuemax={acceptance.length} aria-valuenow={done}>
              <div className="h-full bg-[var(--product)] transition-all duration-[140ms]" style={{ width: `${(done / acceptance.length) * 100}%` }} />
            </div>
            <span className="tnum font-mono text-[12px]">{done}/{acceptance.length}</span>
          </div>
        </div>
        <ul className="grid gap-1.5 md:grid-cols-2">
          {acceptance.map((a, i) => (
            <li key={a}>
              <label className={cn("flex cursor-pointer items-start gap-2 rounded-[6px] border px-3 py-2 text-[12px] leading-snug", checks[i] ? "border-[var(--product)] bg-[var(--product)]/10" : "border-vox-border hover:bg-vox-raised")}>
                <input type="checkbox" checked={!!checks[i]} onChange={() => toggle(i)} className="mt-0.5 h-4 w-4 accent-[var(--product)]" />
                <span><span className="tnum mr-1 font-mono text-vox-sub">{i + 1}.</span>{a}</span>
              </label>
            </li>
          ))}
        </ul>
        <div className="mt-4">
          {all ? (
            <Note tone="ok"><b className="text-vox-ok">Допуск к Production-ревью.</b> Все 11 условий отмечены. Статус Production присваивается только после независимого ревью и exact-HEAD Windows CI + VST3 validator.</Note>
          ) : (
            <Note tone="warn">Статус остаётся <b>{comp.status}</b>: не выполнено {acceptance.length - done} из {acceptance.length}. Ничего не называется PASS, если тест не исполнялся.</Note>
          )}
        </div>
        <div className="mt-3"><Btn onClick={() => setGate((g) => ({ ...g, [active]: acceptance.map(() => false) }))}>Сбросить отметки</Btn></div>
      </Card>
    </div>
  );
}
