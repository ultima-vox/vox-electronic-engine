import { useState } from "react";
import { Badge, Btn, Note, PageHead } from "../components/ui";
import { bindingCols, bindingRows } from "../data";
import { cn } from "../utils/cn";

function toCsv(rows: typeof bindingRows) {
  const esc = (s: string) => (/[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s);
  return [bindingCols.join(","), ...rows.map((r) => bindingCols.map((c) => esc(r[c])).join(","))].join("\n");
}

export default function Binding() {
  const [prod, setProd] = useState<"all" | "drums" | "fx">("all");
  const [q, setQ] = useState("");
  const rows = bindingRows.filter(
    (r) => (prod === "all" || r.product === prod) && Object.values(r).join(" ").toLowerCase().includes(q.toLowerCase()),
  );
  const cells = bindingRows.length * bindingCols.length;
  const tbd = bindingRows.reduce((n, r) => n + Object.values(r).filter((v) => v === "TBD-AUDIT").length, 0);

  const download = () => {
    const blob = new Blob(["\ufeff" + toCsv(bindingRows)], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "UI_BINDING_MATRIX.csv";
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div>
      <PageHead kicker="DS-00 · UI_BINDING_MATRIX.csv" title="Матрица привязок">
        Каждый видимый интерактивный контрол обязан иметь рабочую цель: 100 % с целью, 0 fake controls. Здесь — черновик на основе того, что названо в ТЗ.
        Идентификаторы не выдумываются: всё, что не подтверждено источником, помечено <span className="font-mono text-vox-warn">TBD-AUDIT</span> и закрывается аудитом DS-00.
      </PageHead>

      <div className="mb-3 grid grid-cols-3 gap-3 sm:max-w-xl">
        {[["Строк", bindingRows.length], ["Ячеек", cells], ["TBD-AUDIT", `${tbd} (${Math.round((tbd / cells) * 100)}%)`]].map(([l, v]) => (
          <div key={l as string} className="rounded-[6px] border border-vox-border bg-vox-panel p-3">
            <div className="tnum font-mono text-[18px] text-[var(--product)]">{v}</div>
            <div className="text-[11px] text-vox-sub">{l}</div>
          </div>
        ))}
      </div>

      <div className="mb-3 flex flex-wrap items-center gap-2">
        {(["all", "drums", "fx"] as const).map((p) => (
          <Btn key={p} active={prod === p} onClick={() => setProd(p)}>{p === "all" ? "Все" : p}</Btn>
        ))}
        <input
          aria-label="Поиск по матрице"
          placeholder="Поиск…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="min-h-8 w-48 rounded-[6px] border border-vox-edge bg-vox-graph px-2 text-[12px]"
        />
        <Btn onClick={download} className="ml-auto">⇩ Экспорт CSV (17 колонок)</Btn>
      </div>

      <div className="max-h-[560px] overflow-auto rounded-[8px] border border-vox-border bg-vox-panel">
        <table className="w-max min-w-full text-left text-[11px]">
          <thead className="sticky top-0 z-10 bg-vox-raised text-vox-sub">
            <tr>
              {bindingCols.map((c) => (
                <th key={c} className="whitespace-nowrap px-2 py-2 font-mono font-medium">{c}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-t border-vox-border align-top">
                {bindingCols.map((c) => (
                  <td key={c} className={cn("max-w-[260px] px-2 py-1.5", r[c] === "TBD-AUDIT" ? "font-mono text-vox-warn/80" : c === "control" || c === "product" ? "font-semibold" : "text-vox-sub", c === "product" && (r.product === "drums" ? "!text-vox-drums" : "!text-vox-fx"))}>
                    {r[c]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Note tone="accent">Подтверждено ТЗ в явном виде: <span className="font-mono">drm.kit.volume</span>, <span className="font-mono">selectPad(pad)</span>, <span className="font-mono">audition(pad,110)</span>, <span className="font-mono">takeHitMask()</span>, <span className="font-mono">takePadMeter</span>, <span className="font-mono">takeMainMeter</span>. Остальное — по месту, ID не угадывать.</Note>
        <Note tone="warn">Для статус-колонки: <Badge tone="warn">Gap</Badge> = расхождение с утверждённым UI; <Badge tone="neutral">Donor</Badge> = работающий механизм, переносимый в dock; ни одна строка не отмечена PASS.</Note>
      </div>
    </div>
  );
}
