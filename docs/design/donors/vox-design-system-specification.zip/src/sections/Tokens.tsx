import { Badge, Card, Note, PageHead } from "../components/ui";
import { colorTokens, icons, knobSizes, motion, productAccents, proposedTokens, radii, spacing, strokes, typeScale, units } from "../data";
import { contrast } from "../lib/util";
import { cn } from "../utils/cn";

interface Pair {
  fg: string;
  bg: string;
  fgName: string;
  bgName: string;
  kind: "text" | "large" | "graphic";
}

const hex = (n: string) => [...colorTokens, ...proposedTokens].find((t) => t.name === n)!.hex;
const pairs: Pair[] = [
  { fgName: "text", bgName: "background", kind: "text" },
  { fgName: "text", bgName: "panel", kind: "text" },
  { fgName: "text", bgName: "panelRaised", kind: "text" },
  { fgName: "textSecondary", bgName: "background", kind: "text" },
  { fgName: "textSecondary", bgName: "panel", kind: "text" },
  { fgName: "textSecondary", bgName: "panelRaised", kind: "text" },
  { fgName: "accent", bgName: "panel", kind: "graphic" },
  { fgName: "warning", bgName: "panel", kind: "text" },
  { fgName: "danger", bgName: "panel", kind: "text" },
  { fgName: "danger", bgName: "panelRaised", kind: "text" },
  { fgName: "border", bgName: "background", kind: "graphic" },
  { fgName: "border", bgName: "panel", kind: "graphic" },
  { fgName: "edgeStrong", bgName: "panel", kind: "graphic" },
  { fgName: "automated", bgName: "panel", kind: "text" },
  { fgName: "modulated", bgName: "panel", kind: "text" },
].map((p) => ({ ...p, fg: hex(p.fgName), bg: hex(p.bgName) })) as Pair[];

export default function Tokens() {
  return (
    <div>
      <PageHead kicker="DS-01 · Foundations" title="Токены, геометрия, типографика">
        Все цвета — семантические токены, никаких <code className="font-mono text-vox-text">Colour::fromString()</code> по продукту. Значения — стартовая база из ТЗ;
        перед визуальным утверждением фактические значения <code className="font-mono text-vox-text">Tokens.h</code> проверяются аудитом.
      </PageHead>

      <div className="grid gap-5 xl:grid-cols-2">
        <Card title="Семантические цвета" sub="Начальная база из ТЗ">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {colorTokens.map((t) => (
              <div key={t.name} className="overflow-hidden rounded-[6px] border border-vox-border">
                <div className="h-12" style={{ background: t.hex }} />
                <div className="bg-vox-raised p-2">
                  <div className="text-[12px] font-semibold">{t.name}</div>
                  <div className="font-mono text-[11px] text-vox-sub">{t.hex}</div>
                  <div className="mt-0.5 text-[11px] leading-tight text-vox-sub">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 mb-2 flex items-center gap-2 text-[12px] font-semibold">
            Предложения сверх ТЗ <Badge tone="warn">новое требование ТЗ</Badge>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {proposedTokens.map((t) => (
              <div key={t.name} className="overflow-hidden rounded-[6px] border border-dashed border-vox-edge">
                <div className="h-8" style={{ background: t.hex }} />
                <div className="bg-vox-raised p-2">
                  <div className="text-[12px] font-semibold">{t.name}</div>
                  <div className="font-mono text-[11px] text-vox-sub">{t.hex}</div>
                  <div className="mt-0.5 text-[11px] leading-tight text-vox-sub">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card title="Идентичность продуктов" sub="Предложения 05_ULTIMA_VOX_UI_JUCE_SKIN.md. Не переопределяют error / focus / mute / modulated / clip">
          <div className="grid gap-2">
            {productAccents.map((p) => (
              <div key={p.key} className="flex items-center gap-3 rounded-[6px] border border-vox-border bg-vox-raised p-3">
                <div className="h-10 w-10 rounded-[6px]" style={{ background: p.hex }} />
                <div className="flex-1">
                  <div className="text-[13px] font-semibold">{p.name}</div>
                  <div className="font-mono text-[11px] text-vox-sub">{p.hex} · {p.tag}</div>
                </div>
                <div className="tnum rounded-[4px] border px-2 py-1 font-mono text-[11px]" style={{ borderColor: p.hex, color: p.hex }}>
                  {contrast(p.hex, hex("panel")).toFixed(2)}:1
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4">
            <Note tone="accent">
              VoxLookAndFeel — один на все продукты. Продукт меняет только accent-токен идентичности; focus всегда семантический <span className="font-mono text-vox-accent">#00DDF5</span>.
              Переключатель продукта в шапке меняет accent этой консоли.
            </Note>
          </div>
        </Card>
      </div>

      <Card className="mt-5" title="Проверка контраста (вычисляется)" sub="Пороги: текст ≥ 4.5:1, графика / focus ≥ 3:1 (проектные пороги на основе WCAG 2.2). Фактический тест на экране обязателен.">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[12px]">
            <thead className="text-vox-sub">
              <tr>
                <th className="pb-2 font-medium">Образец</th><th className="pb-2 font-medium">Пара</th><th className="pb-2 font-medium">Тип</th>
                <th className="pb-2 font-medium">Ratio</th><th className="pb-2 font-medium">Порог</th><th className="pb-2 font-medium">Итог</th>
              </tr>
            </thead>
            <tbody>
              {pairs.map((p) => {
                const r = contrast(p.fg, p.bg);
                const need = p.kind === "text" ? 4.5 : 3;
                const ok = r >= need;
                return (
                  <tr key={p.fgName + p.bgName} className="border-t border-vox-border">
                    <td className="py-1.5">
                      <span className="inline-block rounded-[4px] px-2 py-0.5 font-mono text-[11px]" style={{ background: p.bg, color: p.fg, border: `1px solid ${p.kind === "graphic" ? p.fg : "transparent"}` }}>
                        {p.kind === "graphic" ? "▭ граница" : "Aa 123"}
                      </span>
                    </td>
                    <td className="py-1.5 font-mono text-[11px]">{p.fgName} / {p.bgName}</td>
                    <td className="py-1.5 text-vox-sub">{p.kind === "text" ? "текст" : "графика"}</td>
                    <td className="tnum py-1.5 font-mono">{r.toFixed(2)}:1</td>
                    <td className="tnum py-1.5 font-mono text-vox-sub">≥ {need}:1</td>
                    <td className="py-1.5"><Badge tone={ok ? "ok" : "danger"}>{ok ? "✓ pass" : "✕ fail"}</Badge></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="mt-3">
          <Note tone="warn">
            <b className="text-vox-warn">Находка:</b> токен <span className="font-mono">border #1D3B50</span> не проходит 3:1 и допустим только как декоративный разделитель.
            Границы интерактивных контролов, фейдеров и полей ввода должны использовать отдельный токен (предложение — <span className="font-mono">edgeStrong</span>); решение — за владельцем при визуальном sign-off.
          </Note>
        </div>
      </Card>

      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        <Card title="Сетка 4 px" sub="Отступы 4 / 8 / 12 / 16 / 20 / 24 / 32">
          <div className="space-y-1.5">
            {spacing.map((s) => (
              <div key={s} className="flex items-center gap-3">
                <span className="tnum w-8 font-mono text-[11px] text-vox-sub">{s}</span>
                <div className="h-3 rounded-[2px] bg-[var(--product)]" style={{ width: s * 4 }} />
              </div>
            ))}
          </div>
          <div className="mt-4 text-[12px] font-semibold">Радиусы</div>
          <div className="mt-2 flex gap-3">
            {radii.map((r) => (
              <div key={r} className="flex flex-col items-center gap-1">
                <div className="h-12 w-12 border-2 border-vox-edge bg-vox-raised" style={{ borderRadius: r }} />
                <span className="font-mono text-[11px] text-vox-sub">{r}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 text-[12px] font-semibold">Линии / иконки</div>
          <div className="mt-2 flex items-end gap-4">
            {strokes.map((s) => (
              <div key={s} className="flex flex-col items-center gap-1">
                <div className="w-10 bg-vox-text" style={{ height: s }} />
                <span className="font-mono text-[11px] text-vox-sub">{s}</span>
              </div>
            ))}
            {icons.map((s) => (
              <div key={s} className="flex flex-col items-center gap-1">
                <div className="border border-dashed border-vox-edge" style={{ width: s, height: s }} />
                <span className="font-mono text-[11px] text-vox-sub">{s}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card title="Размеры контролов" sub="Hit-area ≥ 24×24, предпочтительно 28+; частые действия 32–40+">
          <div className="flex items-end gap-5">
            {knobSizes.map((k) => (
              <div key={k.px} className="flex flex-col items-center gap-1">
                <div className="rounded-full border-2 border-vox-edge bg-gradient-to-br from-[#2a4256] to-[#0d1b27]" style={{ width: k.px, height: k.px }} />
                <span className="font-mono text-[11px]">{k.px}</span>
                <span className="text-[11px] text-vox-sub">{k.name}</span>
              </div>
            ))}
            <div className="flex flex-col items-center gap-1 opacity-70">
              <div className="rounded-full border-2 border-dashed border-vox-warn" style={{ width: 52, height: 52 }} />
              <span className="font-mono text-[11px]">~52</span>
              <span className="text-[11px] text-vox-warn">нужен токен</span>
            </div>
          </div>
          <div className="mt-5 space-y-2 text-[12px]">
            <div className="flex items-center gap-3"><div className="h-7 w-24 rounded-[6px] border border-vox-edge bg-vox-raised" /> контроль 28–32 px</div>
            <div className="flex items-center gap-3"><div className="h-9 w-24 rounded-[6px] border border-vox-edge bg-vox-raised" /> вкладка ~36 px</div>
            <div className="flex items-center gap-3"><div className="relative h-6 w-6 border border-dashed border-vox-accent"><div className="absolute inset-1 bg-vox-text/60" /></div> минимум 24×24 hit-area</div>
          </div>
        </Card>

        <Card title="Типографика и единицы">
          <div className="space-y-2">
            {typeScale.map((t) => (
              <div key={t.name} className="flex items-baseline justify-between gap-3 border-b border-vox-border pb-1.5">
                <span style={{ fontSize: t.px, fontWeight: t.w }} className="tnum">VOX {t.px}</span>
                <span className="text-right text-[11px] text-vox-sub">{t.name}<br />{t.px} px</span>
              </div>
            ))}
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {units.map((u) => (
              <Badge key={u}>{u}</Badge>
            ))}
          </div>
          <div className="tnum mt-3 font-mono text-[12px] text-vox-sub">Числа tabular: 1 234.5 · 0 000.0</div>
        </Card>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Card title="Движение" sub="Только короткие переходы состояния; метры двигаются по данным, не по таймеру анимации">
          <div className="flex gap-3">
            {motion.map((m) => (
              <button
                key={m.ms}
                className="group flex-1 rounded-[6px] border border-vox-edge bg-vox-raised p-3 text-left"
              >
                <div
                  className={cn("mb-2 h-2 w-3 rounded-full bg-[var(--product)] transition-all group-hover:w-full group-focus:w-full")}
                  style={{ transitionDuration: `${m.ms}ms` }}
                />
                <div className="tnum font-mono text-[13px]">≤ {m.ms} ms</div>
                <div className="text-[11px] text-vox-sub">{m.use}</div>
              </button>
            ))}
          </div>
          <p className="mt-2 text-[11px] text-vox-sub">Наведите / сфокусируйте плитку. prefers-reduced-motion отключает переходы.</p>
        </Card>
        <Card title="Семантика величин">
          <ul className="space-y-1.5 text-[12px] text-vox-sub">
            <li><b className="text-vox-text">Unipolar</b> — 0–100 % с видимым числом; интенсивность = значение параметра, не clip.</li>
            <li><b className="text-vox-text">Bipolar</b> — видимый центр / ноль, L/R, ± st, корректная нулевая зона.</li>
            <li><b className="text-vox-text">Log / частота</b> — Cutoff и Time в физических единицах по нормализации параметра.</li>
            <li><b className="text-vox-text">Audio peak</b> — измеренное, с точкой цепи, hold / decay и единицами. OVER — отдельный latched индикатор.</li>
            <li><b className="text-vox-text">Automation base / modulation</b> — база видна постоянно, модуляция — внешнее кольцо.</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
