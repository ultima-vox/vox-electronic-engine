import { Badge, Card, Note, PageHead } from "../components/ui";
import { bindingRows, contracts, drumsGaps, fxGaps, outOfScope, ownership, principles, priority, registry } from "../data";

export default function Overview({ go }: { go: (id: string) => void }) {
  const byStatus = (s: string) => registry.filter((r) => r.status === s).length;
  const tbd = bindingRows.reduce((n, r) => n + Object.values(r).filter((v) => v === "TBD-AUDIT").length, 0);
  const p1 = [...drumsGaps, ...fxGaps].filter((g) => g.p === 1).length;
  const p2 = [...drumsGaps, ...fxGaps].filter((g) => g.p === 2).length;

  const stats = [
    ["Компоненты в реестре", registry.length, "go:registry"],
    ["Implemented", byStatus("Implemented"), ""],
    ["Production", byStatus("Production"), ""],
    ["Concept / Deferred", byStatus("Concept") + byStatus("Deferred"), ""],
    ["Разрывы P1", p1, "go:drums"],
    ["Разрывы P2", p2, "go:drums"],
    ["TBD-AUDIT ячеек в матрице", tbd, "go:binding"],
  ] as const;

  return (
    <div>
      <PageHead kicker="VOX MUSIC · Design System 1.0 · ТЗ от 18.11.2026" title="Консоль дизайн-системы">
        Рабочий справочник технического задания: токены, реестр компонентов, эталонные интерактивные контролы, матрицы разрывов Drums и FX, матрица привязок,
        план DS-00…DS-05 и гейт приёмки. Целевая реализация — нативный C++20 / JUCE 9.0.1 (VST3, Windows x64); эта консоль — веб-эталон поведения и документ, а не плагин.
      </PageHead>

      <Note tone="warn">
        <b className="text-vox-warn">Статус документа.</b> Это предлагаемое единое ТЗ, а не заявление о выполненной работе. Ни один компонент не имеет статуса Production,
        ни один тест не отмечен как PASS. Рисунки, mockup и визуальные прототипы не создаются без отдельной команды владельца «нарисуй»; контролы в консоли —
        интерактивный код-эталон поведения. Требуется <Badge tone="danger">USER_VISUAL_SIGNOFF_REQUIRED</Badge> до нового Drums UI C++ (#127).
      </Note>

      <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-7">
        {stats.map(([label, n, link]) => (
          <button
            key={label}
            disabled={!link}
            onClick={() => link && go(link.slice(3))}
            className="rounded-[8px] border border-vox-border bg-vox-panel p-3 text-left enabled:hover:border-[var(--product)]"
          >
            <div className="tnum font-mono text-[26px] font-semibold leading-none text-[var(--product)]">{n}</div>
            <div className="mt-2 text-[12px] leading-tight text-vox-sub">{label}</div>
          </button>
        ))}
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <Card title="Архитектура" sub="vox-ui — только JUCE GUI; без зависимостей от DSP продуктов">
          <div className="space-y-2 font-mono text-[12px]">
            <div className="rounded-[6px] border border-vox-accent/60 bg-vox-raised px-3 py-2 text-center text-vox-accent">SEMANTIC TOKENS · THEME · TYPOGRAPHY</div>
            <div className="text-center text-vox-sub">│</div>
            <div className="rounded-[6px] border border-vox-edge bg-vox-raised p-3">
              <div className="mb-2 text-center font-semibold text-vox-text">libs/vox-ui</div>
              <div className="grid grid-cols-2 gap-2 text-[11px] text-vox-sub">
                <div className="rounded border border-vox-border px-2 py-1">control primitives</div>
                <div className="rounded border border-vox-border px-2 py-1">form / input / feedback</div>
                <div className="rounded border border-vox-border px-2 py-1">graph / meter / waveform</div>
                <div className="rounded border border-vox-border px-2 py-1">navigation / layout / dock</div>
                <div className="col-span-2 rounded border border-vox-border px-2 py-1">showcase + visual gate + accessibility tests</div>
              </div>
            </div>
            <div className="text-center text-vox-sub">▲ ▲ ▲</div>
            <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
              <div className="rounded border border-vox-drums/70 px-2 py-2 text-vox-drums">products/drums UI</div>
              <div className="rounded border border-vox-fx/70 px-2 py-2 text-vox-fx">products/fx UI</div>
              <div className="rounded border border-vox-synth/70 px-2 py-2 text-vox-synth">products/synth UI</div>
            </div>
            <div className="text-center text-vox-sub">product controllers → DSP / state</div>
          </div>
        </Card>

        <Card title="Приоритет обязательств">
          <ol className="space-y-1.5">
            {priority.map((p, i) => (
              <li key={p} className="flex items-center gap-3 text-[13px]">
                <span className="tnum flex h-6 w-6 items-center justify-center rounded-full border border-vox-edge font-mono text-[11px] text-[var(--product)]">{i + 1}</span>
                {p}
              </li>
            ))}
          </ol>
          <p className="mt-3 text-[12px] text-vox-sub">Сторонние дизайн-рекомендации не отменяют установленные продуктовые требования. WCAG — целевой ориентир, а не заявление о сертификации VST3.</p>
        </Card>
      </div>

      <h3 className="engrave mb-3 mt-8 text-[14px] font-semibold">Шесть UX-принципов</h3>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {principles.map(([t, d], i) => (
          <div key={t} className="rounded-[8px] border border-vox-border bg-vox-panel p-4">
            <div className="font-mono text-[11px] text-[var(--product)]">0{i + 1}</div>
            <div className="mt-1 text-[14px] font-semibold">{t}</div>
            <p className="mt-1 text-[12px] leading-relaxed text-vox-sub">{d}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <Card title="Ownership / lifetime">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[12px]">
              <thead className="text-vox-sub">
                <tr><th className="pb-2 font-medium">Владелец</th><th className="pb-2 font-medium">Что</th><th className="pb-2 font-medium">Поток</th></tr>
              </thead>
              <tbody>
                {ownership.map(([a, b, c, d]) => (
                  <tr key={a} className="border-t border-vox-border align-top">
                    <td className="py-1.5 pr-2 font-semibold">{a}</td>
                    <td className="py-1.5 pr-2 text-vox-sub">{b}<div className="text-[11px] text-vox-edge">{d}</div></td>
                    <td className="py-1.5 font-mono text-[11px] text-vox-sub">{c}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
        <div className="space-y-5">
          <Card title="Входные контракты (проектные интерфейсы)" sub="Не утверждение о существующих классах / API">
            <dl className="space-y-1.5 text-[12px]">
              {contracts.map(([k, v]) => (
                <div key={k} className="flex gap-3">
                  <dt className="w-36 shrink-0 font-mono text-[var(--product)]">{k}</dt>
                  <dd className="text-vox-sub">{v}</dd>
                </div>
              ))}
            </dl>
          </Card>
          <Card title="Вне границ UI-проекта">
            <div className="flex flex-wrap gap-1.5">
              {outOfScope.map((o) => (
                <Badge key={o} tone="danger">✕ {o}</Badge>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
