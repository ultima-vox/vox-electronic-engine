import type { ReactNode } from "react";
import { cn } from "../utils/cn";
import type { CompStatus } from "../data";

export type Tone = "neutral" | "ok" | "warn" | "danger" | "accent" | "mod" | "product";

const toneCls: Record<Tone, string> = {
  neutral: "border-vox-edge text-vox-sub",
  ok: "border-vox-ok/70 text-vox-ok",
  warn: "border-vox-warn/70 text-vox-warn",
  danger: "border-vox-danger/70 text-vox-danger",
  accent: "border-vox-accent/70 text-vox-accent",
  mod: "border-vox-mod/70 text-vox-mod",
  product: "border-[var(--product)] text-[var(--product)]",
};

export function Badge({ tone = "neutral", children, className }: { tone?: Tone; children: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 whitespace-nowrap rounded-[4px] border px-1.5 py-0.5 font-mono text-[11px] leading-4",
        toneCls[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

const statusMeta: Record<CompStatus, { tone: Tone; sym: string }> = {
  Concept: { tone: "neutral", sym: "○" },
  Prototype: { tone: "warn", sym: "◔" },
  Implemented: { tone: "accent", sym: "◑" },
  Production: { tone: "ok", sym: "●" },
  Deferred: { tone: "mod", sym: "—" },
};

export function StatusBadge({ status }: { status: CompStatus }) {
  const m = statusMeta[status];
  return (
    <Badge tone={m.tone}>
      <span aria-hidden>{m.sym}</span>
      {status}
    </Badge>
  );
}

export function Card({
  title,
  sub,
  right,
  children,
  className,
}: {
  title?: string;
  sub?: string;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("rounded-[8px] border border-vox-border bg-vox-panel", className)}>
      {(title || right) && (
        <header className="flex items-start justify-between gap-3 border-b border-vox-border px-4 py-3">
          <div>
            {title && <h3 className="engrave text-[14px] font-semibold tracking-wide text-vox-text">{title}</h3>}
            {sub && <p className="mt-0.5 text-[12px] text-vox-sub">{sub}</p>}
          </div>
          {right}
        </header>
      )}
      <div className="p-4">{children}</div>
    </section>
  );
}

export function PageHead({ kicker, title, children }: { kicker: string; title: string; children?: ReactNode }) {
  return (
    <div className="mb-6">
      <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-[var(--product)]">{kicker}</div>
      <h2 className="mt-1 text-[26px] font-semibold leading-tight tracking-tight">{title}</h2>
      {children && <div className="mt-2 max-w-3xl text-[13px] leading-relaxed text-vox-sub">{children}</div>}
    </div>
  );
}

export function Btn({
  children,
  onClick,
  active,
  disabled,
  tone = "neutral",
  className,
  title,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  active?: boolean;
  disabled?: boolean;
  tone?: "neutral" | "danger";
  className?: string;
  title?: string;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      title={title}
      disabled={disabled}
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        "min-h-8 rounded-[6px] border px-3 text-[12px] font-medium transition-colors duration-[80ms] active:translate-y-px",
        "disabled:cursor-not-allowed disabled:opacity-40",
        active
          ? "border-[var(--product)] bg-[var(--product)]/15 text-vox-text"
          : tone === "danger"
            ? "border-vox-danger/60 bg-vox-raised text-vox-danger hover:bg-vox-danger/10"
            : "border-vox-edge bg-vox-raised text-vox-text hover:border-vox-sub hover:bg-vox-border/50",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Note({ tone = "neutral", children }: { tone?: Tone; children: ReactNode }) {
  const bar: Record<Tone, string> = {
    neutral: "border-vox-edge",
    ok: "border-vox-ok",
    warn: "border-vox-warn",
    danger: "border-vox-danger",
    accent: "border-vox-accent",
    mod: "border-vox-mod",
    product: "border-[var(--product)]",
  };
  return (
    <div className={cn("rounded-[6px] border-l-4 bg-vox-raised px-3 py-2 text-[12px] leading-relaxed text-vox-sub", bar[tone])}>
      {children}
    </div>
  );
}
