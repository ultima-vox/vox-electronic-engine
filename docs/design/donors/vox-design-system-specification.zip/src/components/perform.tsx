import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "../utils/cn";
import { drumHit, startNote } from "../lib/audio";
import { Btn, Badge } from "./ui";

/* ═════════════════════ PadGrid (4×4 + List16) ═════════════════════ */

export const PAD_NAMES = ["Kick", "Kick 2", "Snare", "Rim", "Clap", "Snare 2", "Hat C", "Hat O", "Tom L", "Tom M", "Tom H", "Perc 1", "Perc 2", "Crash", "FX 1", "FX 2"];
const MISSING = 13;

export function PadGrid({ onLog }: { onLog: (m: string, tone?: "ok" | "warn" | "danger" | "accent") => void }) {
  const [selected, setSelected] = useState(0);
  const [focusIdx, setFocusIdx] = useState(0);
  const [view, setView] = useState<"grid" | "list">("grid");
  const [vel, setVel] = useState(110);
  const [muted, setMuted] = useState<number[]>([]);
  const [soloed, setSoloed] = useState<number[]>([]);
  const [flash, setFlash] = useState<Record<number, { k: number; v: number }>>({});
  const btns = useRef<(HTMLButtonElement | null)[]>([]);

  const select = (i: number) => {
    setSelected(i);
    onLog(`SELECT pad ${i + 1} «${PAD_NAMES[i]}» — звука нет, trigger не отправлен`, "accent");
  };
  const audition = (i: number) => {
    if (i === MISSING) return onLog(`AUDITION pad ${i + 1}: sample missing — запуск отклонён, подмены нет`, "danger");
    const silenced = muted.includes(i) || (soloed.length > 0 && !soloed.includes(i));
    setFlash((f) => ({ ...f, [i]: { k: (f[i]?.k ?? 0) + 1, v: vel } }));
    if (silenced) return onLog(`AUDITION pad ${i + 1}: velocity ${vel} зарегистрирована, вывод заглушен (mute/solo)`, "warn");
    drumHit(i, vel);
    onLog(`AUDITION pad ${i + 1} «${PAD_NAMES[i]}» · note ${36 + i} · velocity ${vel} (задано явно, не pressure)`, "ok");
  };
  const toggle = (arr: number[], set: (a: number[]) => void, i: number) => set(arr.includes(i) ? arr.filter((x) => x !== i) : [...arr, i]);

  const nav = (e: React.KeyboardEvent, i: number) => {
    const d: Record<string, number> = { ArrowRight: 1, ArrowLeft: -1, ArrowDown: 4, ArrowUp: -4 };
    if (!(e.key in d)) return;
    e.preventDefault();
    const n = Math.min(15, Math.max(0, i + d[e.key]));
    setFocusIdx(n);
    setSelected(n);
    btns.current[n]?.focus();
  };

  const status = (i: number) => (i === MISSING ? "MISSING" : muted.includes(i) ? "MUTE" : soloed.includes(i) ? "SOLO" : "");

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-3">
        <div className="flex gap-1" role="group" aria-label="Режим Pad Rack">
          <Btn active={view === "grid"} onClick={() => setView("grid")}>4×4</Btn>
          <Btn active={view === "list"} onClick={() => setView("list")}>List 16</Btn>
        </div>
        <label className="flex items-center gap-2 text-[12px] text-vox-sub">
          Audition velocity
          <input type="range" min={1} max={127} value={vel} onChange={(e) => setVel(+e.target.value)} className="w-28 accent-[var(--product)]" />
          <span className="tnum w-8 font-mono text-vox-text">{vel}</span>
        </label>
      </div>

      {view === "grid" ? (
        <div role="group" aria-label="Pad Rack 4×4" className="grid w-full max-w-[420px] grid-cols-4 gap-2">
          {PAD_NAMES.map((name, i) => {
            const sel = selected === i;
            const st = status(i);
            return (
              <div
                key={i}
                className={cn(
                  "relative aspect-square overflow-hidden rounded-[8px] border bg-[#0d1a25] shadow-[inset_0_2px_6px_rgba(0,0,0,0.7),0_1px_0_rgba(79,122,150,0.35)]",
                  sel ? "border-[var(--product)] ring-1 ring-[var(--product)]" : "border-vox-border",
                )}
              >
                <button
                  type="button"
                  aria-pressed={sel}
                  aria-label={`Select pad ${i + 1} ${name} (без звука)`}
                  onClick={() => select(i)}
                  className={cn(
                    "absolute inset-x-0 top-0 z-10 h-7 border-b px-1.5 text-left font-mono text-[10px] font-bold tracking-wider",
                    sel ? "border-[var(--product)]/60 bg-[var(--product)]/20 text-vox-text" : "border-vox-border text-vox-sub hover:bg-vox-raised",
                  )}
                >
                  {sel ? "◉ SEL" : "○ SEL"} <span className="float-right tnum text-vox-sub">{i + 1}</span>
                </button>
                <button
                  ref={(el) => {
                    btns.current[i] = el;
                  }}
                  type="button"
                  tabIndex={focusIdx === i ? 0 : -1}
                  aria-label={`Audition pad ${i + 1} ${name}, note ${36 + i}${st ? ", " + st : ""}`}
                  aria-disabled={i === MISSING}
                  onFocus={() => setFocusIdx(i)}
                  onKeyDown={(e) => nav(e, i)}
                  onClick={() => audition(i)}
                  className={cn(
                    "absolute inset-x-0 bottom-0 top-7 flex flex-col items-center justify-center gap-0.5 active:bg-vox-raised",
                    i === MISSING && "hatch cursor-not-allowed",
                  )}
                >
                  {flash[i] && (
                    <span
                      key={flash[i].k}
                      className="hit-flash pointer-events-none absolute inset-0"
                      style={{ background: "var(--product)", opacity: flash[i].v / 127 }}
                    />
                  )}
                  <span className="relative text-[12px] font-semibold text-vox-text">{name}</span>
                  <span className="tnum relative font-mono text-[10px] text-vox-sub">N{36 + i}</span>
                  {st && (
                    <span className={cn("relative rounded-[3px] px-1 font-mono text-[9px] font-bold", st === "MISSING" ? "bg-vox-danger text-white" : st === "MUTE" ? "bg-vox-warn text-vox-bg" : "bg-vox-accent text-vox-bg")}>
                      {st}
                    </span>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      ) : (
        <div role="table" aria-label="Pad Rack List 16" className="max-w-[560px] overflow-hidden rounded-[6px] border border-vox-border">
          {PAD_NAMES.map((name, i) => (
            <div key={i} role="row" className={cn("flex items-center gap-2 border-b border-vox-border px-2 py-1 last:border-0", selected === i && "bg-[var(--product)]/10")}>
              <span className="tnum w-6 font-mono text-[11px] text-vox-sub">{i + 1}</span>
              <span className="w-20 text-[12px]">{name}</span>
              <span className="tnum w-12 font-mono text-[11px] text-vox-sub">N{36 + i}</span>
              <span className="w-16">{status(i) && <Badge tone={i === MISSING ? "danger" : "warn"}>{status(i)}</Badge>}</span>
              <div className="ml-auto flex gap-1">
                <Btn active={selected === i} onClick={() => select(i)}>SELECT</Btn>
                <Btn onClick={() => audition(i)} disabled={i === MISSING}>AUDITION</Btn>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-3 flex flex-wrap items-center gap-2 rounded-[6px] border border-vox-border bg-vox-raised px-3 py-2 text-[12px]">
        <span className="text-vox-sub">Выбран:</span>
        <b>
          {selected + 1} · {PAD_NAMES[selected]}
        </b>
        <Btn active={muted.includes(selected)} onClick={() => toggle(muted, setMuted, selected)} className="ml-auto">Mute</Btn>
        <Btn active={soloed.includes(selected)} onClick={() => toggle(soloed, setSoloed, selected)}>Solo</Btn>
      </div>
      <p className="mt-2 text-[11px] leading-relaxed text-vox-sub">
        Tab → пэд, ←↑↓→ = SELECT без звука, Enter/Space = AUDITION. Вспышка = velocity события (не peak сигнала); peak по пэду — отдельный индикатор,
        недоступен без telemetry-контракта DR-UI-05. Ноты 36–51 — демо-данные, в продукте берутся из kit/state.
      </p>
    </div>
  );
}

/* ═════════════════════ Keyboard ═════════════════════ */

const BLACK = [1, 3, 6, 8, 10];
const NOTE_NAMES = ["C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B"];
type Own = { ui: boolean; ext: boolean; sus: boolean };

export function VoxKeyboardDemo({ onLog }: { onLog: (m: string, tone?: "ok" | "warn" | "danger" | "accent") => void }) {
  const [octaves, setOctaves] = useState(3);
  const [vel, setVel] = useState(100);
  const [sustain, setSustain] = useState(false);
  const [, bump] = useState(0);
  const own = useRef<Record<number, Own>>({});
  const handles = useRef<Record<number, () => void>>({});
  const pointerNote = useRef<number | null>(null);
  const down = useRef(false);
  const [focusNote, setFocusNote] = useState(48);
  const velRef = useRef(vel);
  velRef.current = vel;
  const sustainRef = useRef(sustain);
  sustainRef.current = sustain;

  const sync = (note: number) => {
    const o = own.current[note];
    const on = !!o && (o.ui || o.ext || o.sus);
    if (on && !handles.current[note]) handles.current[note] = startNote(note, velRef.current);
    if (!on && handles.current[note]) {
      handles.current[note]();
      delete handles.current[note];
    }
    bump((x) => x + 1);
  };
  const setOwner = useCallback((note: number, kind: "ui" | "ext", on: boolean) => {
    const o = (own.current[note] ??= { ui: false, ext: false, sus: false });
    if (kind === "ui" && !on && sustainRef.current && o.ui) o.sus = true;
    o[kind] = on;
    if (kind === "ui" && on) o.sus = false;
    sync(note);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const panic = useCallback(() => {
    Object.keys(own.current).forEach((k) => {
      own.current[+k] = { ui: false, ext: false, sus: false };
      sync(+k);
    });
    pointerNote.current = null;
    down.current = false;
    onLog("PANIC: все ноты (UI / EXT / sustain) завершены", "warn");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onLog]);

  const releasePointer = useCallback(() => {
    if (pointerNote.current !== null) setOwner(pointerNote.current, "ui", false);
    pointerNote.current = null;
    down.current = false;
  }, [setOwner]);

  useEffect(() => {
    const up = () => releasePointer();
    const blur = () => {
      releasePointer();
    };
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    window.addEventListener("blur", blur);
    return () => {
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      window.removeEventListener("blur", blur);
    };
  }, [releasePointer]);

  useEffect(
    () => () => {
      Object.values(handles.current).forEach((r) => r());
      handles.current = {};
    },
    [],
  );

  useEffect(() => {
    if (!sustain) {
      Object.keys(own.current).forEach((k) => {
        if (own.current[+k].sus) {
          own.current[+k].sus = false;
          sync(+k);
        }
      });
    }
  }, [sustain]);

  const press = (note: number) => {
    if (pointerNote.current !== null && pointerNote.current !== note) setOwner(pointerNote.current, "ui", false);
    pointerNote.current = note;
    setOwner(note, "ui", true);
  };

  const start = 48;
  const total = octaves * 12 + 1;
  const notes = Array.from({ length: total }, (_, i) => start + i);
  const W = 38;
  const BW = 24;
  let whiteCount = 0;
  const layout = notes.map((n) => {
    const black = BLACK.includes(n % 12);
    const x = black ? whiteCount * W - BW / 2 : whiteCount * W;
    if (!black) whiteCount++;
    return { n, black, x };
  });
  const widthPx = whiteCount * W;

  const extChord = () => {
    const root = 48 + Math.floor(Math.random() * 7);
    const chord = [root, root + 4, root + 7].filter((n) => n < start + total);
    chord.forEach((n) => setOwner(n, "ext", true));
    onLog(`EXT MIDI (симуляция): chord ${chord.map((n) => NOTE_NAMES[n % 12] + (Math.floor(n / 12) - 1)).join(" ")} · владелец ≠ UI`, "accent");
    window.setTimeout(() => chord.forEach((n) => setOwner(n, "ext", false)), 1400);
  };

  const keyEl = (k: { n: number; black: boolean; x: number }) => {
    const o = own.current[k.n];
    const ui = !!o?.ui;
    const ext = !!o?.ext;
    const sus = !!o?.sus;
    const name = NOTE_NAMES[k.n % 12] + (Math.floor(k.n / 12) - 1);
    return (
      <button
        key={k.n}
        type="button"
        tabIndex={focusNote === k.n ? 0 : -1}
        aria-label={`Note ${name}${ui ? ", UI" : ""}${ext ? ", external MIDI" : ""}${sus ? ", sustained" : ""}`}
        aria-pressed={ui || ext || sus}
        onFocus={() => setFocusNote(k.n)}
        onBlur={() => {
          if (!down.current) setOwner(k.n, "ui", false);
        }}
        onPointerDown={(e) => {
          if (e.button !== 0) return;
          try {
            e.currentTarget.releasePointerCapture(e.pointerId);
          } catch {
            /* нет capture */
          }
          down.current = true;
          press(k.n);
        }}
        onPointerEnter={() => down.current && press(k.n)}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            if (!e.repeat) setOwner(k.n, "ui", true);
          } else if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
            e.preventDefault();
            const n = Math.min(start + total - 1, Math.max(start, k.n + (e.key === "ArrowRight" ? 1 : -1)));
            setFocusNote(n);
            (e.currentTarget.parentElement?.querySelector(`[data-n="${n}"]`) as HTMLElement | null)?.focus();
          } else if (e.key === "Escape") panic();
        }}
        onKeyUp={(e) => (e.key === "Enter" || e.key === " ") && setOwner(k.n, "ui", false)}
        data-n={k.n}
        className={cn(
          "absolute top-0 flex touch-none flex-col items-center justify-end border pb-1 font-mono text-[10px] transition-colors duration-[80ms]",
          k.black
            ? "z-10 rounded-b-[4px] border-black text-vox-sub"
            : "rounded-b-[6px] border-[#9ab2c5]/60 text-[#06121d]",
          k.black ? "bg-[#0a141c]" : "bg-[#e9f3fa]",
          ui && (k.black ? "!bg-[var(--product)] !text-vox-bg" : "!bg-[var(--product)]"),
          ext && !ui && (k.black ? "!bg-vox-mod !text-vox-bg" : "!bg-vox-mod"),
          sus && !ui && !ext && "!bg-vox-warn/60",
        )}
        style={{ left: k.x, width: k.black ? BW : W, height: k.black ? 96 : 150 }}
      >
        <span aria-hidden>{ui ? "●" : ext ? "◆" : sus ? "~" : ""}</span>
        {!k.black && k.n % 12 === 0 && <span aria-hidden>{name}</span>}
      </button>
    );
  };

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-3">
        <label className="flex items-center gap-2 text-[12px] text-vox-sub">
          Октавы
          <input type="range" min={1} max={5} value={octaves} onChange={(e) => (panic(), setOctaves(+e.target.value))} className="w-20 accent-[var(--product)]" />
          <span className="tnum font-mono text-vox-text">{octaves}</span>
        </label>
        <label className="flex items-center gap-2 text-[12px] text-vox-sub">
          Fixed velocity
          <input type="range" min={1} max={127} value={vel} onChange={(e) => setVel(+e.target.value)} className="w-24 accent-[var(--product)]" />
          <span className="tnum w-8 font-mono text-vox-text">{vel}</span>
        </label>
        <Btn active={sustain} onClick={() => setSustain((s) => !s)}>Sustain</Btn>
        <Btn onClick={extChord}>Симуляция EXT MIDI</Btn>
        <Btn tone="danger" onClick={panic}>Panic</Btn>
      </div>
      <div
        role="group"
        aria-label="Клавиатура"
        className="overflow-x-auto rounded-[6px] border border-vox-border bg-vox-graph p-2"
        onPointerLeave={() => down.current && releasePointer()}
      >
        <div className="relative" style={{ width: widthPx, height: 150 }}>
          {layout.filter((k) => !k.black).map(keyEl)}
          {layout.filter((k) => k.black).map(keyEl)}
        </div>
      </div>
      <p className="mt-2 text-[11px] leading-relaxed text-vox-sub">
        ● UI-нота · ◆ внешний MIDI · ~ sustain. Протяжка между клавишами завершает старую ноту и начинает новую; выход курсора, потеря фокуса и Escape/Panic не оставляют
        зависших нот. Позиция мыши не трактуется как aftertouch/MPE. Клавиатурные события обрабатываются только на сфокусированной клавише — глобальные DAW-шорткаты не перехватываются.
      </p>
    </div>
  );
}

/* ═════════════════════ StepGrid ═════════════════════ */

const LANES = [
  { name: "Kick", pad: 0 },
  { name: "Snare", pad: 2 },
  { name: "Hat", pad: 6 },
  { name: "Clap", pad: 5 },
];
const initSteps = () =>
  LANES.map((_, l) => Array.from({ length: 16 }, (_, s) => (l === 0 ? s % 4 === 0 : l === 1 ? s % 8 === 4 : l === 2 ? s % 2 === 0 : s === 12 || s === 15)));
const initVel = (): number[][] => LANES.map((_, l) => Array.from({ length: 16 }, (_, s) => (l === 2 ? (s % 4 === 2 ? 110 : 70) : 100)));

export function StepGridDemo() {
  const [steps, setSteps] = useState(initSteps);
  const [vel, setVel] = useState(initVel);
  const [lane, setLane] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [bpm, setBpm] = useState(110);
  const [head, setHead] = useState(-1);
  const sRef = useRef(steps);
  sRef.current = steps;
  const vRef = useRef(vel);
  vRef.current = vel;
  const dragVel = useRef(false);

  useEffect(() => {
    if (!playing) {
      setHead(-1);
      return;
    }
    let i = 0;
    const id = window.setInterval(
      () => {
        LANES.forEach((l, li) => sRef.current[li][i] && drumHit(l.pad, vRef.current[li][i]));
        setHead(i);
        i = (i + 1) % 16;
      },
      60000 / bpm / 4,
    );
    return () => window.clearInterval(id);
  }, [playing, bpm]);

  const setV = (s: number, e: React.PointerEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const v = Math.round(Math.min(127, Math.max(1, (1 - (e.clientY - r.top) / r.height) * 127)));
    setVel((p) => p.map((row, li) => (li === lane ? row.map((x, si) => (si === s ? v : x)) : row)));
  };

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-3">
        <Btn active={playing} onClick={() => setPlaying((p) => !p)}>{playing ? "■ Stop" : "▶ Play"}</Btn>
        <label className="flex items-center gap-2 text-[12px] text-vox-sub">
          BPM
          <input type="range" min={60} max={180} value={bpm} onChange={(e) => setBpm(+e.target.value)} className="w-24 accent-[var(--product)]" />
          <span className="tnum w-8 font-mono text-vox-text">{bpm}</span>
        </label>
        <Badge tone="neutral">playhead ≠ edit selection</Badge>
      </div>
      <div className="overflow-x-auto">
        <div className="min-w-[560px]">
          <div className="mb-1 ml-[72px] grid grid-cols-16 gap-1 font-mono text-[10px] text-vox-sub" style={{ gridTemplateColumns: "repeat(16, minmax(0,1fr))" }}>
            {Array.from({ length: 16 }, (_, s) => (
              <div key={s} className={cn("text-center", s % 4 === 0 && "font-bold text-vox-text")}>{s % 4 === 0 ? s / 4 + 1 : "·"}</div>
            ))}
          </div>
          {LANES.map((l, li) => (
            <div key={l.name} className="mb-1 flex items-center gap-2">
              <button
                type="button"
                aria-pressed={lane === li}
                onClick={() => setLane(li)}
                className={cn("h-8 w-16 rounded-[4px] border text-left px-2 text-[11px] font-medium", lane === li ? "border-[var(--product)] bg-[var(--product)]/15" : "border-vox-border text-vox-sub hover:bg-vox-raised")}
              >
                {l.name}
              </button>
              <div className="grid flex-1 gap-1" style={{ gridTemplateColumns: "repeat(16, minmax(0,1fr))" }}>
                {steps[li].map((on, s) => (
                  <button
                    key={s}
                    type="button"
                    aria-pressed={on}
                    aria-label={`${l.name} step ${s + 1} ${on ? "on" : "off"}`}
                    onClick={() => setSteps((p) => p.map((row, i) => (i === li ? row.map((x, j) => (j === s ? !x : x)) : row)))}
                    className={cn(
                      "h-8 rounded-[4px] border transition-colors duration-[80ms]",
                      on ? "border-[var(--product)] bg-[var(--product)]" : s % 4 === 0 ? "border-vox-edge bg-vox-raised" : "border-vox-border bg-vox-graph",
                      head === s && "outline outline-2 -outline-offset-2 outline-vox-accent",
                      on && vel[li][s] < 64 && "opacity-70",
                    )}
                  />
                ))}
              </div>
            </div>
          ))}
          <div className="mt-2 flex gap-2">
            <div className="w-16 pt-1 text-[10px] leading-tight text-vox-sub">Velocity<br />{LANES[lane].name}</div>
            <div className="grid h-20 flex-1 gap-1" style={{ gridTemplateColumns: "repeat(16, minmax(0,1fr))" }}>
              {vel[lane].map((v, s) => (
                <div
                  key={s}
                  className="relative cursor-ns-resize touch-none rounded-[3px] border border-vox-border bg-vox-graph"
                  onPointerDown={(e) => {
                    e.currentTarget.setPointerCapture(e.pointerId);
                    dragVel.current = true;
                    setV(s, e);
                  }}
                  onPointerMove={(e) => dragVel.current && setV(s, e)}
                  onPointerUp={() => (dragVel.current = false)}
                >
                  {steps[lane][s] ? (
                    <div className="absolute inset-x-0 bottom-0 bg-[var(--product)]/80" style={{ height: `${(v / 127) * 100}%` }} />
                  ) : (
                    <div className="hatch absolute inset-0 opacity-60" />
                  )}
                  {steps[lane][s] && <span className="tnum absolute inset-x-0 top-0 text-center font-mono text-[9px] text-vox-text">{v}</span>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <p className="mt-2 text-[11px] text-vox-sub">Демо: toggle шагов, velocity-lane под общей линейкой, playhead отдельно от редактирования. Multi-select / zoom / ratchet / microtiming — контракт DR-UI-08.</p>
    </div>
  );
}
