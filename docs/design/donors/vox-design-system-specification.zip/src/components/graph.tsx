import { useEffect, useRef, useState } from "react";
import { clamp } from "../lib/util";
import { Btn, Badge } from "./ui";
import { cn } from "../utils/cn";

interface Pt {
  t: number;
  v: number;
}

const T = 2;
const VB_W = 560;
const VB_H = 230;
const L = 44;
const R = 12;
const TOP = 14;
const BOT = 30;
const PW = VB_W - L - R;
const PH = VB_H - TOP - BOT;
const MIN_GAP = 0.01;
const MIN_N = 2;
const MAX_N = 16;

const px = (t: number) => L + (t / T) * PW;
const py = (v: number) => TOP + (1 - v) * PH;

function curvePath(pts: Pt[], smooth: boolean) {
  if (!smooth) return pts.map((p, i) => `${i ? "L" : "M"}${px(p.t).toFixed(1)} ${py(p.v).toFixed(1)}`).join(" ");
  let d = `M${px(pts[0].t).toFixed(1)} ${py(pts[0].v).toFixed(1)}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    for (let k = 1; k <= 16; k++) {
      const u = k / 16;
      const s = (1 - Math.cos(Math.PI * u)) / 2;
      d += ` L${px(a.t + (b.t - a.t) * u).toFixed(1)} ${py(a.v + (b.v - a.v) * s).toFixed(1)}`;
    }
  }
  return d;
}

export function EnvelopeEditor() {
  const [pts, setPts] = useState<Pt[]>([
    { t: 0, v: 0 },
    { t: 0.25, v: 0.9 },
    { t: 0.8, v: 0.55 },
    { t: 1.5, v: 0.35 },
    { t: T, v: 0 },
  ]);
  const [past, setPast] = useState<Pt[][]>([]);
  const [future, setFuture] = useState<Pt[][]>([]);
  const [draft, setDraft] = useState<Pt[] | null>(null);
  const [sel, setSel] = useState(1);
  const [snap, setSnap] = useState(true);
  const [smooth, setSmooth] = useState(false);
  const [msg, setMsg] = useState("");
  const svg = useRef<SVGSVGElement>(null);
  const dragIdx = useRef<number | null>(null);
  const draftRef = useRef<Pt[] | null>(null);

  const shown = draft ?? pts;

  const commit = (next: Pt[]) => {
    setPast((p) => [...p, pts]);
    setFuture([]);
    setPts(next);
  };
  const undo = () => {
    if (!past.length) return;
    setFuture((f) => [pts, ...f]);
    setPts(past[past.length - 1]);
    setPast((p) => p.slice(0, -1));
    setSel((s) => Math.min(s, past[past.length - 1].length - 1));
  };
  const redo = () => {
    if (!future.length) return;
    setPast((p) => [...p, pts]);
    setPts(future[0]);
    setFuture((f) => f.slice(1));
  };

  const toData = (e: { clientX: number; clientY: number }): Pt => {
    const r = svg.current!.getBoundingClientRect();
    const x = ((e.clientX - r.left) / r.width) * VB_W;
    const y = ((e.clientY - r.top) / r.height) * VB_H;
    let t = clamp(((x - L) / PW) * T, 0, T);
    let v = clamp(1 - (y - TOP) / PH, 0, 1);
    if (snap) {
      t = Math.round(t / 0.125) * 0.125;
      v = Math.round(v / 0.05) * 0.05;
    }
    return { t, v };
  };

  const place = (base: Pt[], i: number, p: Pt): Pt[] => {
    const lo = i === 0 ? 0 : base[i - 1].t + MIN_GAP;
    const hi = i === base.length - 1 ? T : base[i + 1].t - MIN_GAP;
    const fixedX = i === 0 || i === base.length - 1;
    return base.map((q, k) => (k === i ? { t: fixedX ? q.t : clamp(p.t, lo, hi), v: clamp(p.v, 0, 1) } : q));
  };

  useEffect(() => {
    if (!msg) return;
    const id = window.setTimeout(() => setMsg(""), 2500);
    return () => window.clearTimeout(id);
  }, [msg]);

  const remove = (i: number) => {
    if (pts.length <= MIN_N) return setMsg(`Минимум ${MIN_N} узла`);
    commit(pts.filter((_, k) => k !== i));
    setSel(Math.max(0, i - 1));
  };

  const cancelDrag = () => {
    dragIdx.current = null;
    draftRef.current = null;
    setDraft(null);
    setMsg("Escape — drag отменён, Undo-группа не создана");
  };

  const p = shown[sel] ?? shown[0];
  const ticks = [0, 0.5, 1, 1.5, 2];

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <Btn onClick={undo} disabled={!past.length}>↶ Undo</Btn>
        <Btn onClick={redo} disabled={!future.length}>↷ Redo</Btn>
        <Btn active={snap} onClick={() => setSnap((s) => !s)}>Snap {snap ? "ON" : "OFF"}</Btn>
        <Btn active={smooth} onClick={() => setSmooth((s) => !s)}>Shape: {smooth ? "smooth" : "linear"}</Btn>
        <Badge tone="neutral">{pts.length} / {MAX_N} nodes (min {MIN_N})</Badge>
        <span className="tnum ml-auto font-mono text-[12px] text-vox-sub">
          node {sel + 1}: t = {p.t.toFixed(3)} s · v = {(p.v * 100).toFixed(0)} %
        </span>
      </div>
      <svg
        ref={svg}
        viewBox={`0 0 ${VB_W} ${VB_H}`}
        className="w-full touch-none rounded-[6px] border border-vox-border bg-vox-graph"
        role="application"
        aria-label="Envelope editor. Tab — выбор узла, стрелки — перемещение, Delete — удалить, двойной клик по фону — добавить узел"
        onDoubleClick={(e) => {
          if ((e.target as Element).getAttribute("data-node")) return;
          if (pts.length >= MAX_N) return setMsg(`Максимум ${MAX_N} узлов`);
          const q = toData(e);
          if (pts.some((n) => Math.abs(n.t - q.t) < MIN_GAP)) return setMsg("Узел с таким временем уже есть (duplicate-time policy)");
          const next = [...pts, q].sort((a, b) => a.t - b.t);
          commit(next);
          setSel(next.findIndex((n) => n === q));
        }}
      >
        {/* сетка */}
        {ticks.map((t) => (
          <g key={t}>
            <line x1={px(t)} x2={px(t)} y1={TOP} y2={TOP + PH} stroke="#1d3b50" />
            <text x={px(t)} y={VB_H - 12} textAnchor="middle" fontSize={10} fill="#9ab2c5" fontFamily="monospace">{t.toFixed(1)} s</text>
          </g>
        ))}
        {[0, 0.5, 1].map((v) => (
          <g key={v}>
            <line x1={L} x2={L + PW} y1={py(v)} y2={py(v)} stroke="#1d3b50" />
            <text x={L - 6} y={py(v) + 3} textAnchor="end" fontSize={10} fill="#9ab2c5" fontFamily="monospace">{v * 100}%</text>
          </g>
        ))}
        {snap &&
          Array.from({ length: 15 }, (_, i) => (i + 1) * 0.125).map((t) => (
            <line key={t} x1={px(t)} x2={px(t)} y1={TOP + PH} y2={TOP + PH + 4} stroke="#4f7a96" />
          ))}
        <path d={`${curvePath(shown, smooth)} L${px(shown[shown.length - 1].t)} ${py(0)} L${px(shown[0].t)} ${py(0)} Z`} fill="var(--product)" opacity={0.12} />
        <path d={curvePath(shown, smooth)} fill="none" stroke="var(--product)" strokeWidth={2} />
        {shown.map((n, i) => (
          <g
            key={i}
            tabIndex={0}
            role="slider"
            aria-label={`Node ${i + 1}`}
            aria-valuetext={`t ${n.t.toFixed(3)} s, value ${(n.v * 100).toFixed(0)} percent`}
            aria-valuenow={Math.round(n.v * 100)}
            onFocus={() => setSel(i)}
            onKeyDown={(e) => {
              if (e.key === "Escape" && dragIdx.current !== null) return cancelDrag();
              const s = e.shiftKey ? 0.01 : 0.05;
              const ts = e.shiftKey ? 0.01 : 0.125;
              let dt = 0;
              let dv = 0;
              if (e.key === "ArrowUp") dv = s;
              else if (e.key === "ArrowDown") dv = -s;
              else if (e.key === "ArrowRight") dt = ts;
              else if (e.key === "ArrowLeft") dt = -ts;
              else if (e.key === "Delete" || e.key === "Backspace") {
                e.preventDefault();
                return remove(i);
              } else return;
              e.preventDefault();
              commit(place(pts, i, { t: n.t + dt, v: n.v + dv }));
            }}
            onPointerDown={(e) => {
              (e.currentTarget as SVGGElement).setPointerCapture(e.pointerId);
              (e.currentTarget as SVGGElement).focus();
              dragIdx.current = i;
              draftRef.current = pts;
              setSel(i);
            }}
            onPointerMove={(e) => {
              if (dragIdx.current === null) return;
              const next = place(pts, dragIdx.current, toData(e));
              draftRef.current = next;
              setDraft(next);
            }}
            onPointerUp={() => {
              const d = draftRef.current;
              if (dragIdx.current !== null && d && d !== pts && d.some((q, k) => q.t !== pts[k].t || q.v !== pts[k].v)) commit(d);
              dragIdx.current = null;
              draftRef.current = null;
              setDraft(null);
            }}
            onDoubleClick={(e) => {
              e.stopPropagation();
              remove(i);
            }}
            className="cursor-grab outline-none"
          >
            <circle data-node="1" cx={px(n.t)} cy={py(n.v)} r={14} fill="transparent" />
            <circle
              data-node="1"
              cx={px(n.t)}
              cy={py(n.v)}
              r={sel === i ? 7 : 5.5}
              fill={sel === i ? "var(--product)" : "#0b1925"}
              stroke="#e9f3fa"
              strokeWidth={sel === i ? 2 : 1.5}
            />
            {sel === i && <circle cx={px(n.t)} cy={py(n.v)} r={11} fill="none" stroke="#00ddf5" strokeWidth={1.5} strokeDasharray="3 3" />}
          </g>
        ))}
      </svg>
      <div className={cn("mt-2 min-h-5 text-[12px]", msg ? "text-vox-warn" : "text-vox-sub")} aria-live="polite">
        {msg || "Drag узла = превью, запись в Undo один раз по завершении; Escape во время drag — revert. Двойной клик: фон = добавить, узел = удалить."}
      </div>
    </div>
  );
}
