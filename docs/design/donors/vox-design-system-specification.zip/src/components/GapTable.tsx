import { useState } from "react";
import { Badge, Btn } from "./ui";
import type { Gap } from "../data";
import { useStored } from "../lib/util";
import { cn } from "../utils/cn";

const ST = ["Open", "In progress", "Blocked", "Ready for review"] as const;
type St = (typeof ST)[number];
const tone: Record<St, "neutral" | "warn" | "danger" | "accent"> = {
  Open: "neutral",
  "In progress": "warn",
  Blocked: "danger",
  "Ready for review": "accent",
};

export function GapTable({ gaps, storeKey }: { gaps: Gap[]; storeKey: string }) {
  const [p, setP] = useState<0 | 1 | 2>(0);
  const [track, setTrack] = useStored<Record<string, St>>(storeKey, {});
  const rows = gaps.filter((g) => !p || g.p === p);
  const count = (s: St) => gaps.filter((g) => (track[g.id] ?? "Open") === s).length;
  const cycle = (id: string) => {
    const cur = track[id] ?? "Open";
    setTrack((t) => ({ ...t, [id]: ST[(ST.indexOf(cur) + 1) % ST.length] }));
  };

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <Btn active={p === 0} onClick={() => setP(0)}>Все ({gaps.length})</Btn>
        <Btn active={p === 1} onClick={() => setP(1)}>P1 ({gaps.filter((g) => g.p === 1).length})</Btn>
        <Btn active={p === 2} onClick={() => setP(2)}>P2 ({gaps.filter((g) => g.p === 2).length})</Btn>
        <div className="ml-auto flex flex-wrap gap-1.5">
          {ST.map((s) => (
            <Badge key={s} tone={tone[s]}>{s}: {count(s)}</Badge>
          ))}
        </div>
      </div>
      <div className="overflow-x-auto rounded-[8px] border border-vox-border bg-vox-panel">
        <table className="w-full min-w-[860px] text-left text-[12px]">
          <thead className="bg-vox-raised text-vox-sub">
            <tr>
              <th className="px-3 py-2 font-medium">ID</th>
              <th className="px-3 py-2 font-medium">P</th>
              <th className="px-3 py-2 font-medium">Требование</th>
              <th className="px-3 py-2 font-medium">Что подтверждено кодом</th>
              <th className="px-3 py-2 font-medium">Обязательная поставка</th>
              <th className="px-3 py-2 font-medium">Трекер</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((g) => {
              const s = track[g.id] ?? "Open";
              return (
                <tr key={g.id} className="border-t border-vox-border align-top">
                  <td className="whitespace-nowrap px-3 py-2 font-mono font-semibold text-[var(--product)]">{g.id}</td>
                  <td className="px-3 py-2"><Badge tone={g.p === 1 ? "danger" : "warn"}>P{g.p}</Badge></td>
                  <td className="px-3 py-2 font-semibold">{g.title}</td>
                  <td className="px-3 py-2 text-vox-sub">{g.found}</td>
                  <td className="px-3 py-2">{g.deliver}</td>
                  <td className="px-3 py-2">
                    <button
                      onClick={() => cycle(g.id)}
                      title="Клик — сменить статус"
                      className={cn("whitespace-nowrap rounded-[4px] border px-2 py-1 font-mono text-[11px] hover:bg-vox-raised", s === "Open" ? "border-vox-edge text-vox-sub" : s === "In progress" ? "border-vox-warn text-vox-warn" : s === "Blocked" ? "border-vox-danger text-vox-danger" : "border-vox-accent text-vox-accent")}
                    >
                      {s}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="mt-2 text-[11px] text-vox-sub">
        Трекер — локальная пометка работы, не результат тестов. «Ready for review» ≠ PASS: закрытие требует exact-HEAD CI и доказательств.
      </p>
    </div>
  );
}
