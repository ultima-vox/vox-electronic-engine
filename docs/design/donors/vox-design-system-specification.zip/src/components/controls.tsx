import { useEffect, useRef, useState } from "react";
import { clamp } from "../lib/util";
import { cn } from "../utils/cn";

/* ───────────────────────── helpers ───────────────────────── */

export const fmtHz = (v: number) => (v >= 1000 ? `${(v / 1000).toFixed(v >= 10000 ? 1 : 2)} kHz` : `${v.toFixed(v < 100 ? 1 : 0)} Hz`);
export const fmtMs = (v: number) => (v >= 1000 ? `${(v / 1000).toFixed(2)} s` : `${v.toFixed(v < 100 ? 1 : 0)} ms`);

const pt = (cx: number, cy: number, r: number, deg: number): [number, number] => {
  const a = (deg * Math.PI) / 180;
  return [cx + r * Math.sin(a), cy - r * Math.cos(a)];
};
function arc(cx: number, cy: number, r: number, a1: number, a2: number) {
  if (Math.abs(a2 - a1) < 0.2) return "";
  const [x1, y1] = pt(cx, cy, r, a1);
  const [x2, y2] = pt(cx, cy, r, a2);
  return `M${x1.toFixed(2)} ${y1.toFixed(2)} A${r} ${r} 0 ${Math.abs(a2 - a1) > 180 ? 1 : 0} ${a2 > a1 ? 1 : 0} ${x2.toFixed(2)} ${y2.toFixed(2)}`;
}

export type CtlState = "normal" | "disabled" | "readOnly" | "unavailable" | "automated" | "error";

/* ───────────────────────── Knob ───────────────────────── */

export interface KnobProps {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  def: number;
  unit?: string;
  log?: boolean;
  bipolar?: boolean;
  size?: 36 | 48 | 64;
  state?: CtlState;
  /** модуляционный диапазон в нормализованных единицах (±), внешнее кольцо */
  mod?: number;
  fmt?: (v: number) => string;
  onGesture?: (phase: "begin" | "end") => void;
}

export function Knob({ label, value, onChange, min, max, def, unit = "", log, bipolar, size = 48, state = "normal", mod = 0, fmt, onGesture }: KnobProps) {
  const toN = (v: number) => clamp(log ? Math.log(v / min) / Math.log(max / min) : (v - min) / (max - min), 0, 1);
  const fromN = (n: number) => (log ? min * Math.pow(max / min, n) : min + n * (max - min));
  const n = toN(value);
  const drag = useRef<{ y: number; n: number } | null>(null);
  const [dragging, setDragging] = useState(false);
  const [editing, setEditing] = useState(false);
  const [txt, setTxt] = useState("");
  const [bad, setBad] = useState(false);
  const inactive = state === "disabled" || state === "readOnly" || state === "unavailable";
  const format = fmt ?? ((v: number) => `${v.toFixed(unit === "%" || unit === "st" ? 0 : 1)}${unit ? " " + unit : ""}`);

  const set = (nn: number) => onChange(fromN(clamp(nn, 0, 1)));

  const commit = () => {
    const s = txt.trim().toLowerCase().replace(",", ".");
    let num = parseFloat(s);
    if (Number.isNaN(num) || !/^-?\d*\.?\d+\s*[a-zµ%]*$/.test(s)) {
      setBad(true);
      return;
    }
    if (/k(hz)?$/.test(s)) num *= 1000;
    if (/^-?\d*\.?\d+\s*s$/.test(s) && unit === "ms") num *= 1000;
    if (num < min - 1e-9 || num > max + 1e-9) {
      setBad(true);
      return;
    }
    onChange(num);
    setBad(false);
    setEditing(false);
  };

  const S = size;
  const c = S / 2;
  const r = S / 2 - 5;
  const A0 = -135;
  const A1 = 135;
  const ang = A0 + n * 270;
  const zeroA = bipolar ? 0 : A0;
  const baseArc = arc(c, c, r, Math.min(zeroA, ang), Math.max(zeroA, ang));
  const modArc = mod ? arc(c, c, r + 3.5, A0 + clamp(n - mod, 0, 1) * 270, A0 + clamp(n + mod, 0, 1) * 270) : "";
  const [ix, iy] = pt(c, c, r - 3, ang);
  const [ox, oy] = pt(c, c, r - 12 > 4 ? r - 12 : 4, ang);
  const accent = state === "error" ? "var(--color-vox-danger)" : state === "automated" ? "var(--color-vox-ok)" : "var(--product)";

  const onKey = (e: React.KeyboardEvent) => {
    if (inactive) return;
    const fine = e.shiftKey ? 0.1 : 1;
    let d = 0;
    if (e.key === "ArrowUp" || e.key === "ArrowRight") d = 0.01 * fine;
    else if (e.key === "ArrowDown" || e.key === "ArrowLeft") d = -0.01 * fine;
    else if (e.key === "PageUp") d = 0.1;
    else if (e.key === "PageDown") d = -0.1;
    else if (e.key === "Home") return (e.preventDefault(), set(0));
    else if (e.key === "End") return (e.preventDefault(), set(1));
    else if (e.key === "Enter") {
      e.preventDefault();
      setTxt(String(+value.toFixed(2)));
      setEditing(true);
      return;
    } else return;
    e.preventDefault();
    set(n + d);
  };

  return (
    <div className={cn("group flex w-[84px] flex-col items-center gap-1 select-none", state === "disabled" && "opacity-40")}>
      <div className="relative">
        <div
          role="slider"
          tabIndex={state === "disabled" ? -1 : 0}
          aria-label={`${label}${unit ? ` (${unit})` : ""}`}
          aria-valuemin={min}
          aria-valuemax={max}
          aria-valuenow={Number(value.toFixed(3))}
          aria-valuetext={format(value)}
          aria-disabled={state === "disabled"}
          aria-readonly={state === "readOnly"}
          title="Drag ↕ · Shift = fine · двойной клик = default · Enter = ввод"
          className={cn(
            "touch-none rounded-full outline-offset-2",
            inactive ? "cursor-not-allowed" : dragging ? "cursor-grabbing" : "cursor-ns-resize",
          )}
          style={{ width: S + 10, height: S + 10, padding: 5 }}
          onKeyDown={onKey}
          onDoubleClick={() => !inactive && onChange(def)}
          onPointerDown={(e) => {
            if (inactive || e.button !== 0) return;
            (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
            drag.current = { y: e.clientY, n };
            setDragging(true);
            onGesture?.("begin");
          }}
          onPointerMove={(e) => {
            const d = drag.current;
            if (!d) return;
            d.n = clamp(d.n + (d.y - e.clientY) / (e.shiftKey ? 900 : 180), 0, 1);
            d.y = e.clientY;
            set(d.n);
          }}
          onPointerUp={() => {
            if (drag.current) onGesture?.("end");
            drag.current = null;
            setDragging(false);
          }}
          onPointerCancel={() => {
            drag.current = null;
            setDragging(false);
          }}
        >
          <svg width={S} height={S} viewBox={`0 0 ${S} ${S}`} className="overflow-visible">
            <defs>
              <radialGradient id={`kb-${S}`} cx="35%" cy="30%" r="80%">
                <stop offset="0" stopColor="#2a4256" />
                <stop offset="1" stopColor="#0d1b27" />
              </radialGradient>
            </defs>
            <path d={arc(c, c, r, A0, A1)} fill="none" stroke="#1d3b50" strokeWidth={3} strokeLinecap="round" />
            {baseArc && <path d={baseArc} fill="none" stroke={accent} strokeWidth={3} strokeLinecap="round" />}
            {modArc && <path d={modArc} fill="none" stroke="var(--color-vox-mod)" strokeWidth={2} strokeLinecap="round" strokeDasharray="1 2.5" />}
            {bipolar && <line x1={c} y1={c - r - 2} x2={c} y2={c - r + 3} stroke="#9ab2c5" strokeWidth={1} />}
            <circle cx={c} cy={c} r={r - 5 > 6 ? r - 5 : 6} fill={`url(#kb-${S})`} stroke="#4f7a96" strokeWidth={1} />
            <line x1={ox} y1={oy} x2={ix} y2={iy} stroke="#e9f3fa" strokeWidth={2} strokeLinecap="round" />
          </svg>
        </div>
        {state === "automated" && <span className="absolute -right-1 -top-1 rounded-[3px] bg-vox-ok px-1 font-mono text-[9px] font-bold text-vox-bg">A</span>}
        {mod > 0 && <span className="absolute -left-1 -top-1 rounded-[3px] bg-vox-mod px-1 font-mono text-[9px] font-bold text-vox-bg">M</span>}
        {state === "error" && <span className="absolute -right-1 -top-1 rounded-[3px] bg-vox-danger px-1 font-mono text-[9px] font-bold text-white">!</span>}
        {state === "readOnly" && <span className="absolute -right-1 -top-1 font-mono text-[10px] text-vox-sub" aria-hidden>🔒</span>}
        {state === "unavailable" && <span className="hatch absolute inset-0 rounded-full" aria-hidden />}
      </div>
      <div className="engrave text-center text-[12px] font-medium leading-tight text-vox-text">{label}</div>
      {editing ? (
        <input
          autoFocus
          value={txt}
          aria-invalid={bad}
          aria-label={`${label} — числовой ввод`}
          onChange={(e) => {
            setTxt(e.target.value);
            setBad(false);
          }}
          onKeyDown={(e) => {
            e.stopPropagation();
            if (e.key === "Enter") commit();
            if (e.key === "Escape") {
              setEditing(false);
              setBad(false);
            }
          }}
          onBlur={() => {
            setEditing(false);
            setBad(false);
          }}
          className={cn(
            "tnum w-full rounded-[4px] border bg-vox-graph px-1 text-center font-mono text-[11px] text-vox-text",
            bad ? "border-vox-danger" : "border-vox-accent",
          )}
        />
      ) : (
        <button
          type="button"
          disabled={inactive}
          onClick={() => {
            setTxt(String(+value.toFixed(2)));
            setEditing(true);
          }}
          className={cn(
            "tnum rounded-[4px] px-1 font-mono text-[12px] text-vox-sub hover:text-vox-text disabled:hover:text-vox-sub",
            S === 36 && !dragging && "opacity-0 transition-opacity duration-[140ms] group-focus-within:opacity-100 group-hover:opacity-100",
          )}
        >
          {format(value)}
        </button>
      )}
      {bad && <div className="text-[10px] text-vox-danger">вне диапазона / формат</div>}
    </div>
  );
}

/* ───────────────────────── Fader ───────────────────────── */

const UNITY = 0.75;
export function normToDb(n: number) {
  if (n <= 0) return -Infinity;
  if (n >= UNITY) return ((n - UNITY) / (1 - UNITY)) * 6;
  return -60 + 60 * Math.sqrt(n / UNITY);
}
export function dbToNorm(db: number) {
  if (db >= 6) return 1;
  if (db >= 0) return UNITY + (db / 6) * (1 - UNITY);
  if (db <= -60) return 0;
  return UNITY * Math.pow((db + 60) / 60, 2);
}
const fmtDb = (db: number) => (db === -Infinity ? "−∞" : (db > 0 ? "+" : "") + db.toFixed(1).replace("-", "−"));

export function Fader({
  label,
  value,
  onChange,
  height = 168,
  defNorm = UNITY,
  disabled,
}: {
  label: string;
  value: number;
  onChange: (n: number) => void;
  height?: number;
  defNorm?: number;
  disabled?: boolean;
}) {
  const trackRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{ y: number; n: number } | null>(null);
  const [txt, setTxt] = useState<string | null>(null);
  const db = normToDb(value);
  const capH = 22;
  const usable = height - capH;
  const capTop = (1 - value) * usable;

  const fromY = (clientY: number) => {
    const rect = trackRef.current!.getBoundingClientRect();
    return clamp(1 - (clientY - rect.top - capH / 2) / usable, 0, 1);
  };

  return (
    <div className={cn("flex flex-col items-center gap-1 select-none", disabled && "opacity-40")}>
      <div className="relative flex items-stretch" style={{ height }}>
        {/* шкала */}
        <div className="relative mr-1 w-7 text-right font-mono text-[10px] text-vox-sub" aria-hidden>
          {[6, 0, -6, -12, -24, -48].map((d) => (
            <span
              key={d}
              className={cn("tnum absolute right-0 leading-none", d === 0 && "font-bold text-vox-text")}
              style={{ top: (1 - dbToNorm(d)) * usable + capH / 2 - 5 }}
            >
              {d === 0 ? "0" : d > 0 ? `+${d}` : `−${Math.abs(d)}`}
            </span>
          ))}
        </div>
        <div
          ref={trackRef}
          role="slider"
          tabIndex={disabled ? -1 : 0}
          aria-label={`${label} fader`}
          aria-orientation="vertical"
          aria-valuemin={-60}
          aria-valuemax={6}
          aria-valuenow={db === -Infinity ? -60 : Number(db.toFixed(1))}
          aria-valuetext={`${fmtDb(db)} dB`}
          title="Drag · Shift = fine · двойной клик = unity (0 dB) · ↑↓ PgUp/PgDn"
          className={cn("relative w-10 touch-none", disabled ? "cursor-not-allowed" : "cursor-ns-resize")}
          onDoubleClick={() => !disabled && onChange(defNorm)}
          onKeyDown={(e) => {
            if (disabled) return;
            const f = e.shiftKey ? 0.1 : 1;
            const map: Record<string, number> = { ArrowUp: 0.01 * f, ArrowDown: -0.01 * f, PageUp: 0.1, PageDown: -0.1 };
            if (e.key in map) {
              e.preventDefault();
              onChange(clamp(value + map[e.key], 0, 1));
            } else if (e.key === "Home") onChange(1);
            else if (e.key === "End") onChange(0);
          }}
          onPointerDown={(e) => {
            if (disabled || e.button !== 0) return;
            e.currentTarget.setPointerCapture(e.pointerId);
            if (e.shiftKey) drag.current = { y: e.clientY, n: value };
            else {
              const n = fromY(e.clientY);
              drag.current = { y: e.clientY, n };
              onChange(n);
            }
          }}
          onPointerMove={(e) => {
            const d = drag.current;
            if (!d) return;
            if (e.shiftKey) {
              d.n = clamp(d.n + (d.y - e.clientY) / (usable * 6), 0, 1);
              d.y = e.clientY;
              onChange(d.n);
            } else {
              d.n = fromY(e.clientY);
              d.y = e.clientY;
              onChange(d.n);
            }
          }}
          onPointerUp={() => (drag.current = null)}
          onPointerCancel={() => (drag.current = null)}
        >
          {/* утопленный трек */}
          <div
            className="absolute left-1/2 w-[6px] -translate-x-1/2 rounded-full border border-black/60 bg-black shadow-[inset_0_2px_4px_rgba(0,0,0,0.9),0_1px_0_rgba(79,122,150,0.5)]"
            style={{ top: capH / 2, bottom: capH / 2 }}
          />
          {/* unity-метка */}
          <div className="absolute left-0 right-0 h-px bg-vox-sub/70" style={{ top: (1 - UNITY) * usable + capH / 2 }} />
          {/* колпачок */}
          <div
            className="absolute left-0 right-0 rounded-[4px] border border-vox-edge bg-gradient-to-b from-[#34526a] to-[#16293a] shadow-[0_2px_4px_rgba(0,0,0,0.7)]"
            style={{ top: capTop, height: capH }}
          >
            <div className="absolute left-1 right-1 top-1/2 h-[2px] -translate-y-1/2 bg-[var(--product)]" />
          </div>
        </div>
      </div>
      <input
        aria-label={`${label} — значение dB`}
        value={txt ?? fmtDb(db)}
        disabled={disabled}
        onFocus={(e) => {
          setTxt(db === -Infinity ? "-inf" : db.toFixed(1));
          e.currentTarget.select();
        }}
        onChange={(e) => setTxt(e.target.value)}
        onKeyDown={(e) => {
          e.stopPropagation();
          if (e.key === "Enter") {
            const s = (txt ?? "").trim().toLowerCase().replace("−", "-").replace(",", ".");
            if (/^-?inf/.test(s)) onChange(0);
            else {
              const v = parseFloat(s);
              if (!Number.isNaN(v)) onChange(dbToNorm(clamp(v, -60, 6)));
            }
            setTxt(null);
            (e.target as HTMLInputElement).blur();
          }
          if (e.key === "Escape") {
            setTxt(null);
            (e.target as HTMLInputElement).blur();
          }
        }}
        onBlur={() => setTxt(null)}
        className="tnum w-14 rounded-[4px] border border-vox-edge bg-vox-graph px-1 py-0.5 text-center font-mono text-[12px] text-vox-text"
      />
      <div className="engrave text-[12px] font-medium text-vox-text">{label}</div>
    </div>
  );
}

/* ───────────────────────── Meter ───────────────────────── */

const M_MIN = -60;
const M_MAX = 6;
const mPos = (db: number) => clamp((db - M_MIN) / (M_MAX - M_MIN), 0, 1);

export function useMeter(peak: number | null) {
  const [hold, setHold] = useState(-Infinity);
  const [over, setOver] = useState(false);
  const last = useRef(0);
  useEffect(() => {
    if (peak === null) return;
    const now = performance.now();
    if (peak >= hold || now - last.current > 1200) {
      setHold((h) => (peak >= h ? peak : Math.max(peak, h - 3)));
      if (peak >= hold) last.current = now;
    }
    if (peak > 0) setOver(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [peak]);
  return { hold, over, resetOver: () => setOver(false), resetHold: () => setHold(-Infinity) };
}

export function Meter({ peak, height = 168, label }: { peak: number | null; height?: number; label: string }) {
  const m = useMeter(peak);
  const noData = peak === null;
  const stops = `linear-gradient(to top, var(--color-vox-accent) 0 ${mPos(-6) * 100}%, var(--color-vox-warn) ${mPos(-6) * 100}% ${mPos(0) * 100}%, var(--color-vox-danger) ${mPos(0) * 100}% 100%)`;
  return (
    <div className="flex flex-col items-center gap-1">
      <button
        type="button"
        onClick={m.resetOver}
        title="OVER: латч для ДЕМО-значения ≥ 0 dBFS (не post-host clip). Клик — сброс"
        className={cn(
          "w-8 rounded-[3px] border font-mono text-[9px] font-bold leading-4",
          m.over ? "border-vox-danger bg-vox-danger text-white" : "border-vox-edge text-vox-sub",
        )}
      >
        OVER
      </button>
      <div
        role="meter"
        aria-label={`${label} peak`}
        aria-valuemin={M_MIN}
        aria-valuemax={M_MAX}
        aria-valuenow={noData ? undefined : Number(peak.toFixed(1))}
        aria-valuetext={noData ? "no data" : `${peak.toFixed(1)} dBFS`}
        className="relative w-3 overflow-hidden rounded-[2px] border border-vox-edge bg-vox-graph"
        style={{ height }}
      >
        {noData ? (
          <div className="hatch absolute inset-0" />
        ) : (
          <>
            <div className="absolute inset-0" style={{ background: stops }} />
            <div className="absolute inset-x-0 top-0 bg-vox-graph" style={{ height: `${(1 - mPos(peak)) * 100}%` }} />
            {m.hold > M_MIN && <div className="absolute inset-x-0 h-[2px] bg-vox-text" style={{ bottom: `${mPos(m.hold) * 100}%` }} />}
          </>
        )}
        <div className="absolute inset-x-0 h-px bg-black/70" style={{ bottom: `${mPos(0) * 100}%` }} />
      </div>
      <div className="tnum h-4 font-mono text-[10px] text-vox-sub">{noData ? "no data" : peak.toFixed(1).replace("-", "−")}</div>
    </div>
  );
}

/* ───────────────────────── XY Pad ───────────────────────── */

export function XYPad({
  x,
  y,
  onChange,
  modX = 0,
  modY = 0,
  size = 220,
}: {
  x: number;
  y: number;
  onChange: (x: number, y: number) => void;
  modX?: number;
  modY?: number;
  size?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [drag, setDrag] = useState(false);
  const upd = (e: React.PointerEvent) => {
    const r = ref.current!.getBoundingClientRect();
    onChange(clamp((e.clientX - r.left) / r.width, 0, 1), clamp(1 - (e.clientY - r.top) / r.height, 0, 1));
  };
  const rx = clamp(x - modX, 0, 1);
  const rw = clamp(x + modX, 0, 1) - rx;
  const ry = clamp(y - modY, 0, 1);
  const rh = clamp(y + modY, 0, 1) - ry;
  return (
    <div
      ref={ref}
      role="application"
      tabIndex={0}
      aria-label={`XY pad: X ${(x * 100).toFixed(0)} %, Y ${(y * 100).toFixed(0)} %. Стрелки — перемещение, Shift — точно`}
      className={cn("relative touch-none rounded-[6px] border border-vox-edge bg-vox-graph", drag ? "cursor-grabbing" : "cursor-crosshair")}
      style={{ width: size, height: size }}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        setDrag(true);
        upd(e);
      }}
      onPointerMove={(e) => drag && upd(e)}
      onPointerUp={() => setDrag(false)}
      onKeyDown={(e) => {
        const s = e.shiftKey ? 0.002 : 0.02;
        const dx = e.key === "ArrowRight" ? s : e.key === "ArrowLeft" ? -s : 0;
        const dy = e.key === "ArrowUp" ? s : e.key === "ArrowDown" ? -s : 0;
        if (dx || dy) {
          e.preventDefault();
          onChange(clamp(x + dx, 0, 1), clamp(y + dy, 0, 1));
        }
      }}
    >
      {[0.25, 0.5, 0.75].map((g) => (
        <div key={g}>
          <div className="absolute inset-y-0 w-px bg-vox-border" style={{ left: `${g * 100}%` }} />
          <div className="absolute inset-x-0 h-px bg-vox-border" style={{ top: `${g * 100}%` }} />
        </div>
      ))}
      {(modX > 0 || modY > 0) && (
        <div
          className="absolute rounded-[3px] border border-dashed border-vox-mod bg-vox-mod/10"
          style={{ left: `${rx * 100}%`, width: `${rw * 100}%`, bottom: `${ry * 100}%`, height: `${rh * 100}%` }}
        />
      )}
      <div className="absolute inset-y-0 w-px bg-[var(--product)]/50" style={{ left: `${x * 100}%` }} />
      <div className="absolute inset-x-0 h-px bg-[var(--product)]/50" style={{ bottom: `${y * 100}%` }} />
      <div
        className="absolute h-4 w-4 -translate-x-1/2 translate-y-1/2 rounded-full border-2 border-vox-text bg-[var(--product)] shadow-[0_0_0_3px_rgba(0,0,0,0.5)]"
        style={{ left: `${x * 100}%`, bottom: `${y * 100}%` }}
      />
    </div>
  );
}
